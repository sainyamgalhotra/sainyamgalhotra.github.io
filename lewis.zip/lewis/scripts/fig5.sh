python drug_local_negative-test.py
mv newplots/drugs_local_negative_related.pdf newplots/5a.pdf
python drug_local_positive-test.py
mv newplots/drug_local_positive_related.pdf newplots/5b.pdf
