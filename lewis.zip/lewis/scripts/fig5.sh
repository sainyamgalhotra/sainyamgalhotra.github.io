python drug_local_negative.py
mv newplots/drugs_local_negative_related.pdf newplots/5a.pdf
python drug_local_positive.py
mv newplots/drug_local_positive_related.pdf newplots/5b.pdf
