import datasethelper,lewishelper
import copy
import pandas as pd
import xgboost


import sys

modeltype=sys.argv[1]
#(X_train,y_train,df,pred,clf)=datasethelper.process_german("adaboost")
#(X_train,y_train,df,pred,clf)=datasethelper.process_german("xgboost")
#(X_train,y_train,df,pred,clf)=datasethelper.process_german("randomforest")
(X_train,y_train,df,pred,clf)=datasethelper.process_german(modeltype)


df['credit']=pred

featlst=list(df.columns)
featlst.remove('credit')

def get_majority(dic1,s1,s2,feat):
    score=[0,0,0]
    if feat in dic1.keys():
        score=dic1[feat]
        
    i=0
    while i<3:
        score[i]=max(score[i],s1[i])
        score[i]=max(score[i],s2[i])
        i+=1
    dic1[feat]=score
    return dic1

score_dic={}
for feat in featlst:
    #print (feat)
    uniqval=list(set(list(df[feat])))
    if feat=='age' or feat=='sex':
        i=0
        while i<len(uniqval):
            j=i+1
            while j<len(uniqval):
                score1=lewishelper.get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],[],'credit')
                score2=lewishelper.get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],[],'credit')
                score_dic=get_majority(score_dic,score1,score2,feat)
                j+=1
            i+=1
    else:
        i=0
        while i<len(uniqval):
            j=i+1
            while j<len(uniqval):
                score1=lewishelper.get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],['age','sex'],'credit')
                score2=lewishelper.get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],['age','sex'],'credit')
                score_dic=get_majority(score_dic,score1,score2,feat)
                j+=1
            i+=1
    
#print (score_dic)

n_score={}
s_score={}
sn_score={}
for feat in score_dic.keys():
    n_score[feat]=score_dic[feat][0]
    s_score[feat]=score_dic[feat][1]
    sn_score[feat]=score_dic[feat][2]
    #print (feat,n_score[feat],s_score[feat],sn_score[feat])

# In[269]:


sorted_s = sorted(s_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_n = sorted(n_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_sn = sorted(sn_score.items(), key=lambda kv: kv[1],reverse=True)

slst=[]
nlst=[]
snlst=[]
svallst=[]
nvallst=[]
snvallst=[]

i=0
for (x,y) in sorted_s:
    slst.append(x)
    svallst.append(y)
    nlst.append(sorted_n[i][0])
    nvallst.append(sorted_n[i][1])
    snlst.append(sorted_sn[i][0])
    snvallst.append(sorted_sn[i][1])
    i+=1

sn=snvallst
n=nvallst
s=svallst
snname=snlst
nname=nlst
sname=slst


#print ("SN")
#print (snlst)
#print (snvallst)
# In[ ]:

#print ("N")
#print (nlst)
#print (nvallst)

#print ("S")
#print (slst)
#print(svallst)



import pandas as pd
from functools import reduce

sn = pd.DataFrame(list(zip(sn, snname)), columns=['sn', 'name'])
n = pd.DataFrame(list(zip(n, nname)), columns=['n', 'name'])
s = pd.DataFrame(list(zip(s, sname)), columns=['s', 'name'])

dfs = [sn, n, s]
allScores = reduce(lambda left,right: pd.merge(left,right,on='name'), dfs) #join

allScores=allScores.replace('investment_as_income_percentage','investment')


allScores = allScores.sort_values(by='sn', ascending=True)

#allScores['name'] = ["skill", "telephone", "foreign_worker", "other_debtors", "liable_for", "num_credits", "sex", "employment", "residence_since", "purpose", "install_plans", "credit_amt", "age", "investment", "savings", "housing", "property", "month", "status", "credit_hist"]
featnames = allScores['name']#["skill", "telephone", "foreign_worker", "other_debtors", "liable_for", "num_credits", "sex", "employment", "residence_since", "purpose", "install_plans", "cred_amt", "age", "invest", "savings", "housing", "property", "month", "status", "cred_hist"]

allScores = allScores.tail(9)[::-1]
featnames = featnames[-9:]

import scipy.stats as ss
nrank=ss.rankdata(allScores['n'])
srank=ss.rankdata(allScores['s'])
snrank=ss.rankdata(allScores['sn'])
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pylab as plot

fsize=20


params = {'legend.fontsize': fsize/1.4,
          'legend.handlelength': 2}
plot.rcParams.update(params)

font = {'family' : "sans serif", 'size'   : fsize}
matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rc('font', **font)

labels = allScores['name']
x = np.arange(len(labels))  # the label locations
width = 0.25  # the width of the bars

# plt.figure(figsize=(6, 10)) # in inches!

fig, ax = plt.subplots()
rects1 = ax.barh(x - width, allScores['n'], width, label='Nec', color='cornflowerblue', edgecolor='black', hatch="//")
rects2 = ax.barh(x, allScores['s'], width, label='Suf', color='gold', edgecolor='black', hatch="\\\\")
rects3 = ax.barh(x + width, allScores['sn'], width, label='NeSuf', color='forestgreen', hatch="|")

plt.gca().invert_yaxis()
# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_xlabel('Scores',labelpad=fsize/2)
ax.set_yticks(x)
ax.set_yticklabels(labels)
ax.legend()
# plt.legend(bbox_to_anchor=(.2, 1.2, 1., .102), loc=3,
#        ncol=3, borderaxespad=0., fontsize=fsize)
ax.xaxis.set_ticks_position('top')
ax.xaxis.set_label_position('top')
plt.xticks(np.arange(0, 1.5, .5))
figure = plt.gcf() # get current figure
figure.set_size_inches(5.8,8)

def autolabel(rects,rank):
    """Attach a text label above each bar in *rects*, displaying its height."""
    i=0
    for rect in rects:
        height = rect.get_width()
        val=len(labels)-int(rank[i])+1
        ax.annotate('{}'.format(val),
                    xy=(height - 0.02, rect.get_y() + 0.32),
                    xytext=(15, 0),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=fsize/1.4)
        i+=1


autolabel(rects1,nrank)
autolabel(rects2,srank)
autolabel(rects3,snrank)
ax.margins(0.07,0.05)
matplotlib.rcParams['hatch.linewidth'] = 0.3

fig.tight_layout()
plt.savefig('newplots/german_globalExplanations'+modeltype+'.pdf')
