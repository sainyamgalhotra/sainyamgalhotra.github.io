#!/usr/bin/env python
# coding: utf-8

# # Install packages

# In[215]:


import numpy as np
import pandas as pd
from collections import namedtuple, Counter

import copy
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


# In[216]:




# In[217]:






# In[261]:


df=pd.read_csv('../../compas/compas-scores-two-years.csv')

df=df[df['days_b_screening_arrest']>=-30]#.value_counts()#[df['score_text']=='N/A']
df=df[df['days_b_screening_arrest']<=30]


# In[262]:
df=df[df['race']!='Hispanic']# or df['race']=='Caucasian']
df=df[df['race']!='Other']
df=df[df['race']!='Asian']
df=df[df['race']!='Native American']




df=df[[ 'vr_charge_degree',  'r_charge_degree',
       'is_recid', 'c_charge_degree', 'priors_count', 'juv_other_count',
       'juv_misd_count', 'juv_fel_count', 'race', 'age_cat', 'sex','score_text']]
#score_text

l=list(df['race'])
cleaned=[]
for v in l:
    if v=='Caucasian':
        cleaned.append(1)
    else:
        cleaned.append(0)
        
df['race']=cleaned


l=list(df['c_charge_degree'])
cleaned=[]
for v in l:
    if v=='F':
        cleaned.append(1)
    else:
        cleaned.append(0)
        
df['c_charge_degree']=cleaned


l=list(df['score_text'])
cleaned=[]
for v in l:
    if v=='Low':
        cleaned.append(0)
    elif v=='Medium':
        cleaned.append(1)
    else:
        cleaned.append(1)
        
df['score_text']=cleaned


l=list(df['vr_charge_degree'])
cleaned=[]
for v in l:
    if v=='NaN':
        cleaned.append(0)
    elif v=='(F3)':
        cleaned.append(1)
    elif v=='(M1)':
        cleaned.append(2)
    else:
        cleaned.append(2)
df['vr_charge_degree']=cleaned

l=list(df['priors_count'])
cleaned=[]
for v in l:
    
    if v==0:
        cleaned.append(0)
    elif v<=3:
        cleaned.append(1)
    else:
        cleaned.append(2)
    
df['priors_count']=cleaned

l=list(df['juv_other_count'])
cleaned=[]
for v in l:
    if v==0:
        cleaned.append(0)
    elif v==1:
        cleaned.append(1)
    else:
        cleaned.append(1)
        

l=list(df['juv_fel_count'])
cleaned=[]
for v in l:
    if v==0:
        cleaned.append(0)
    elif v==1:
        cleaned.append(1)
    else:
        cleaned.append(1)
        
df['juv_fel_count']=cleaned

        

l=list(df['juv_misd_count'])
cleaned=[]
for v in l:
    if v==0:
        cleaned.append(0)
    elif v==1:
        cleaned.append(1)
    else:
        cleaned.append(1)
        
df['juv_misd_count']=cleaned

df['juv_fel_count']=df['juv_fel_count']+df['juv_misd_count']+df['juv_other_count']
df['juv_other_count']=[0]*df.shape[0]
df['juv_misd_count']=[0]*df.shape[0]
df=df[['vr_charge_degree', 'r_charge_degree',
       'is_recid', 'c_charge_degree', 'priors_count', 'juv_fel_count', 'race', 'age_cat', 'sex']]
l=list(df['juv_fel_count'])
cleaned=[]
for v in l:
    if v==0:
        cleaned.append(0)
    elif v==1:
        cleaned.append(1)
    else:
        cleaned.append(1)

df['juv_fel_count']=cleaned




l=list(df['r_charge_degree'])
cleaned=[]
for v in l:
    if v=='NaN':
        cleaned.append(0)
    elif v=='(F3)':
        cleaned.append(1)
    elif v=='(M1)':
        cleaned.append(2)
    else:
        cleaned.append(2)
df['r_charge_degree']=cleaned


l=list(df['sex'])
cleaned=[]
for v in l:
    if v=='Female':
        cleaned.append(0)
    else:
        cleaned.append(1)
    
df['sex']=cleaned

l=list(df['age_cat'])
cleaned=[]
for v in l:
    if v=='Greater than 45':
        cleaned.append(2)
    elif v=='25-45':
        cleaned.append(1)
    else:
        cleaned.append(0)
df['age_cat']=cleaned




y=df['is_recid']
X_train, X_test, y_train, y_test = train_test_split(df, y, test_size=0.5, random_state=1)



feat=list(df.columns)
feat.remove('is_recid')
feat.remove('vr_charge_degree')
feat.remove('r_charge_degree')
feat.remove('c_charge_degree')


clf = RandomForestClassifier(max_depth=10, random_state=0)
#clf = LogisticRegression(random_state=0)

clf.fit(X_train[feat], y_train)

pred= (clf.predict(X_test[feat]))
pred = [int(round(value)) for value in pred]

print(classification_report(y_test, pred))

#print (clf.feature_importances_,feat)
X_test['is_recid']  = pred
df=X_test


# In[263]:


df['age_cat'].value_counts()


# In[264]:


df#['vr_charge_degree'].value_counts()


# In[265]:


df[df['race']==0]['is_recid'].value_counts()


# In[266]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


#featlst=list(df.columns)
#featlst.remove('two_year_recid')
featlst=feat


# In[267]:


debug=False
def get_combination(lst,tuplelst):
    i=0
    new_tuplelst=[]
    if len(tuplelst)==0:
        l=lst[0]
        for v in l:
            new_tuplelst.append([v])
        if len(lst)>1:
            return get_combination(lst[1:],new_tuplelst)
        else:
            return new_tuplelst
    

    currlst=lst[0]
    for l in tuplelst:
        
        for v in currlst:
            newl=copy.deepcopy(l)
            newl.append(v)
            new_tuplelst.append(newl)
        
    if len(lst)>1:
        return get_combination(lst[1:],new_tuplelst)
    else:
        return new_tuplelst
      
def get_C_set(df,C):
    lst=[]
    for Cvar in C:
        lst.append(list(set(list(df[Cvar]))))
        
    combination_lst= (get_combination(lst,[]))
    
    return combination_lst

def get_scores_regression(df,z_attr,z,zprime,klst,kvallst,C,target):
    
    sample=df
    if debug:
        print ("Given k number of data points",sample.shape)
      
    if len(C)>0:
        Clst=get_C_set(df,C)
    else:
        Clst=['']
    
    
    snum=0
    nnum=0
    snnum=0

    for cval in Clst:
        print (klst,kvallst)
        if Clst[0]=='':
            Clst=[]
            
        
        #print (C,klst,z_attr)
        conditional_lst=copy.deepcopy(klst)
        conditional_lst.extend(C)
        conditional_lst.extend(z_attr)
        
        conditional_val=copy.deepcopy(kvallst)
        conditional_val.extend(cval)
        
        conditional_valzp=copy.deepcopy(conditional_val)
        conditional_val.extend(z)
        conditional_valzp.extend(zprime)
        
        
        
        #print (conditional_lst,conditional_val)
        pogivenczk=get_prob_o_regression(df,conditional_lst,conditional_val,[target],[1])
        
        pogivenczpk=get_prob_o_regression(df,conditional_lst,conditional_valzp,[target],[1])
        
        
        if len(C)>0:
            #if (len(klst)>0):
            pck=get_prob_o_regression(df,klst,kvallst,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
            #else:
            #    pck=
            
            conditional=copy.deepcopy(klst)
            conditional_val=copy.deepcopy(kvallst)
            conditional.extend(z_attr)
            conditional_val.extend(z)
            #print (cval,C)
            pcgivenzk=get_prob_o_regression(df,conditional,conditional_val,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
            
            conditional_val=copy.deepcopy(kvallst)
            conditional_val.extend(zprime)
            pcgivenzpk=get_prob_o_regression(df,conditional,conditional_val,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
        else:
            pck=1
            pcgivenzpk=1
            pcgivenzk=1
        #
        if debug:
            print ("P[o|czk]",pogivenczk)
            print ("P[o|cz'k]",pogivenczpk,pck)
        popgivenczpk=1-pogivenczpk
        snum+=pogivenczk*pcgivenzpk ##P[o|do(z),k]
        nnum+=popgivenczpk*pcgivenzk ##P[o|do(z'),k]
        snnum+=(pogivenczk-pogivenczpk)*pck ##P[o|do(z),k]-P[o|do(z'),k]
        #print(snnum,pogivenczk,pogivenczpk)
        
        
        
        if debug:
            print ("numerators",snum,nnum,snnum)
    
    if len(klst)>0:
        pogivenk=get_prob_o_regression(df,klst,kvallst,[target],[1])
    else:
        pogivenk=df[df[target]==1].shape[0]*1.0/df.shape[0]
    #print (pogivenk)
    #sample_target=get_count(sample[target])
    #pogivenk=sample_target[1]*1.0/(sample_target[1]+sample_target[2])
    
    #sample_target_z=get_count(sample_z[target])
    #pogivenzk=sample_target_z[1]*1.0/(sample_target_z[1]+sample_target_z[2])
    conditional=copy.deepcopy(klst)
    conditional.extend(z_attr)
    conditional_val=copy.deepcopy(kvallst)
    conditional_val.extend(z)
    pogivenzk=get_prob_o_regression(df,conditional,conditional_val,[target],[1])
    
    
    conditional_valzp=copy.deepcopy(kvallst)
    conditional_valzp.extend(zprime)
    #sample_target_zp=get_count(sample_zp[target])
    pogivenzpk=get_prob_o_regression(df,conditional,conditional_valzp,[target],[1])
    #sample_target_zp[2]*1.0/(sample_target_zp[1]+sample_target_zp[2])
    popgivenzpk=1-pogivenzpk
    
    #sample_z=sample[sample[z_attr]==z]#|z,k
    #sample_zp=sample[sample[z_attr]==zprime] #|z',k
    
    #pzgivenk=get_prob_o_regression(df,klst,kvallst,z_attr,z)#
    #sample_z.shape[0]*1.0/(sample_z.shape[0]+sample_zp.shape[0])
    #pzpgivenk=get_prob_o_regression(df,klst,kvallst,z_attr,zprime)#
    #pozgivenk = pogivenzk*pzgivenk
    popgivenzk=1-pogivenzk
    #popzpgivenk=popgivenzpk*pzpgivenk
    #pozpgivenk=pogivenzpk*pzpgivenk
    #popzgivenk=popgivenzk*pzgivenk
    #print (snum,pogivenzpk,popgivenzpk,"these")
    
    sn=(snnum)
    s=((snum-pogivenzpk)*1.0/popgivenzpk)
    n=((-popgivenzk+nnum)*1.0/pogivenzk)
    
    ##Lower bound calculation below
    '''
    nlb=(pozgivenk+pozpgivenk-pogivenzpk)*1.0/pozgivenk
    slb=(popzgivenk+popzpgivenk-popgivenzk)*1.0/popzpgivenk

    #newlb=(popgivenzpk-popzpgivenk-popzgivenk - popgivenzpk*(1-pzgivenk-pzpgivenk))*1.0/pozgivenk
    newlb=(-popgivenzk + popgivenzpk)*1.0/pogivenzk
    '''
    
    #sn=max(0,snnum)
    #s= max(0,(snum-pogivenk)*1.0/popzpgivenk)
    #n= max(0,(pogivenk-nnum)*1.0/pozgivenk)
    #print (pogivenzk,pogivenk)
    #Validation:
    #rhs=pozgivenk*n+(1-pogivenzpk)*(1-pzgivenk)*s
    #lhs=1#sn
    #print ("Verification",lhs,rhs)
    
    #print (pzgivenk+pzpgivenk)
    return (n,s,sn)#,nlb,slb,newlb)#,sn_ub,n_ub,s_ub)


# In[268]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import make_regression

def get_val(row,target,target_val):
    i=0
    while i<len(target):
        #print (row[target[i]],target_val[i])
        if not int(row[target[i]])==int(target_val[i]):
            return 0
        i+=1
    return 1
def get_count(lst):
    count={}
    uniq=list(set(lst))
    for v in uniq:
        count[v]=0
    for v in lst:
        count[v]+=1
    if 1 not in count.keys():
        count[1]=0
    if 2 not in count.keys():
        count[2]=0
    return count
    
def get_prob_o_regression(df,conditional,conditional_values,target,target_val):
    #print (target_val,df.size)
    
    #print (df[conditional[0]].value_counts())
    new_lst=[]
    count=0
    for index,row in df.iterrows():
        new_lst.append(get_val(row,target,target_val))
        if new_lst[-1]==1:
            count+=1
    
    if len(conditional)==0 :
        return count*1.0/df.shape[0]
    #pcgivenk=df[df[target]==1].shape[0]*1.0/df.shape[0]
    if len(list(set(new_lst)))==1:
        if new_lst[0]==1:
            return 1
        else:
            return 0
    if len(conditional)>0:
        X=df[conditional]
        #print (df[df[''==c[i]])
        #print (df[df[conditional[0]]==conditional_values[0]].shape)
        #df=df[df[conditional[0]]==conditional_values[0]]
        #c=(get_count(df['credit']))
        #return c[1]*1.0/(c[0]+c[1])
    else:
        X=df
    #conditional.sort()
    #print (conditional)
    #fsdakl
    X=X[conditional]
    #X.to_csv('t2.csv',index=False)
    #print (len(X),conditional,conditional_values)
    regr = RandomForestRegressor(random_state=0)
    #regr = LogisticRegression(random_state=1)
    regr.fit(X, new_lst)
    #print ("target is ",target,target_val,len(new_lst),new_lst)
    #print (len(conditional),regr.coef_.tolist()[0],list(regr.intercept_),conditional,conditional_values)
    #print (regr.predict_proba([conditional_values]),"ASDFDS")
    return (regr.predict([conditional_values])[0])
    #return(regr.predict_proba([conditional_values])[0][1])
    
  

    


# In[285]:


def get_majority(dic1,s1,s2,feat):
    score=[0,0,0]
    if feat in dic1.keys():
        score=dic1[feat]

    i=0
    while i<3:
        score[i]=max(score[i],s1[i])
        score[i]=max(score[i],s2[i])
        i+=1
    dic1[feat]=score
    return dic1

score_dic={}
for feat in featlst:
    print (feat)
    uniqval=list(set(list(df[feat])))
    if feat=='age_cat' or feat=='sex' or feat=='race':
        i=0
        while i<len(uniqval):
            j=i+1
            while j<len(uniqval):
                score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],[],'is_recid')
                score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],[],'is_recid')
                score_dic=get_majority(score_dic,score1,score2,feat)
                j+=1
            i+=1
    else:
        i=0
        while i<len(uniqval):
            j=i+1
            while j<len(uniqval):
                score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],['age_cat','sex','race'],'is_recid')
                score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],['age_cat','sex','race'],'is_recid')
                score_dic=get_majority(score_dic,score1,score2,feat)
                j+=1
            i+=1
    print (score_dic)
    jkl
print (score_dic)


# In[286]:



n_score={}
s_score={}
sn_score={}
for feat in score_dic.keys():
    n_score[feat]=score_dic[feat][0]
    s_score[feat]=score_dic[feat][1]
    sn_score[feat]=score_dic[feat][2]
    print (feat,n_score[feat],s_score[feat],sn_score[feat])

sorted_s = sorted(n_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_n = sorted(s_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_sn = sorted(sn_score.items(), key=lambda kv: kv[1],reverse=True)

slst=[]
nlst=[]
snlst=[]
svallst=[]
nvallst=[]
snvallst=[]

i=0
for (x,y) in sorted_s:
    slst.append(x)
    svallst.append(y)
    nlst.append(sorted_n[i][0])
    nvallst.append(sorted_n[i][1])
    snlst.append(sorted_sn[i][0])
    snvallst.append(sorted_sn[i][1])
    i+=1

print (snvallst)
print (snlst)
# In[ ]:

print (nlst)
print (nvallst)


print (slst)
print(svallst)

jfskldjskl

# In[270]:


print (get_scores_regression(df,['age_cat'],[0],[2],[],[],[],'is_recid'))


# In[282]:


print (get_scores_regression(df,['event'],[1],[0],[],[],['race','sex','age_cat'],'is_recid'))


# In[271]:


print (get_scores_regression(df,['score_text'],[1],[0],[],[],[],'is_recid'))


# In[272]:


print (get_scores_regression(df,['score_text'],[1],[0],['race'],[1],[],'is_recid'))


# In[273]:


print (get_scores_regression(df,['age_cat'],[0],[2],['race'],[0],[],'is_recid'))


# In[274]:


print (get_scores_regression(df,['age_cat'],[0],[2],['race'],[1],[],'is_recid'))


# In[275]:


print (get_scores_regression(df,['sex'],[1],[0],[],[],[],'is_recid'))


# In[276]:


df[df['sex']==1]['is_recid'].value_counts()


# In[277]:


df[df['sex']==0]['is_recid'].value_counts()


# In[278]:


print (get_scores_regression(df,['c_charge_degree'],[1],[0],['race'],[0],[],'is_recid'))


# In[279]:


print (get_scores_regression(df,['c_charge_degree'],[1],[0],['race'],[1],[],'is_recid'))


# In[280]:


print (get_scores_regression(df,['c_charge_degree'],[1],[0],['race'],[1],[],'score_text'))


# In[129]:


print (get_scores_regression(df,['c_charge_degree'],[1],[0],['race'],[0],[],'score_text'))


# In[130]:


print (get_scores_regression(df,['race'],[0],[1],[],[],[],'score_text'))


# In[132]:


print (get_scores_regression(df,['race'],[1],[1],[],[],[],'score_text'))


# In[51]:


df


# In[27]:


print (get_scores_regression(df,['status'],[3],[1],['sex'],[0],[],'credit'))


# In[28]:


print (get_scores_regression(df,['status'],[3],[1],['sex'],[1],[],'credit'))


# In[175]:


print (get_scores_regression(df,['status'],[4],[0],[],[],['age','sex'],'credit'))


# In[176]:


print (get_scores_regression(df,['credit_history','status'],[4,4],[0,0],[],[],['age','sex'],'credit'))


# In[177]:


s=df[df['status']==3]
s['status']=0
pred= (clf.predict(s[feat]))
s['credit']=pred
print(s['credit'].value_counts())


# In[178]:


def get_scores(curr,z,zprime):
#curr='housing'
    sample=df[df[curr]==zprime]
    sample=sample[sample['credit']==0]
    sample[curr]=[z]*(sample.shape[0])
    #print (sample['credit'].value_counts())
    pred= (clf.predict(sample[feat]))
    sample['credit']=(pred)
    print ("sufficiency",sample['credit'].value_counts()[1]*1.0/(sample['credit'].value_counts()[0]+sample['credit'].value_counts()[1]))
    sample=df[df[curr]==z]
    sample=sample[sample['credit']==1]
    sample[curr]=[zprime]*(sample.shape[0])
    pred= (clf.predict(sample[feat]))
    sample['credit']=(pred)
    #print (sample)
    
    print ("necessity",1-sample['credit'].value_counts()[1]*1.0/(sample['credit'].value_counts()[0]+sample['credit'].value_counts()[1]))


# In[179]:


print (get_scores_regression(df,['status'],[1],[0],[],[],['age','sex'],'credit'))

get_scores('status',1,0)


# In[180]:


df['status'].value_counts()


# In[ ]:





# In[181]:


df['housing'].value_counts()


# In[182]:


df['housing'].value_counts()


# In[183]:


print (get_scores_regression(df,['status'],[2],[0],[],[],['age','sex'],'credit'))
print (get_scores_regression(df,['status'],[2],[0],['age'],[0],['sex'],'credit'))
print (get_scores_regression(df,['status'],[2],[0],['age'],[1],['sex'],'credit'))


# In[141]:


print (get_scores_regression(df,['status'],[3],[1],['age'],[0],['sex'],'credit'))


# In[70]:


print (get_scores_regression(df,['housing'],[1],[2],[],[],['age','sex'],'credit'))
print (get_scores_regression(df,['housing'],[2],[1],['age','sex'],[0,0],[],'credit'))
print (get_scores_regression(df,['housing'],[2],[1],['age','sex'],[1,1],[],'credit'))
print (get_scores_regression(df,['housing'],[2],[1],['age','sex'],[1,0],[],'credit'))
print (get_scores_regression(df,['housing'],[2],[1],['age','sex'],[0,1],[],'credit'))


# In[10]:


print (get_scores_regression(df,['credit_history'],[4],[0],[],[],['age','sex'],'credit'))


# In[71]:


df


# In[50]:


df[df['credit_history']==3]['credit'].value_counts()


# In[51]:


df[df['credit_history']==2]['credit'].value_counts()


# In[52]:


df[df['credit_history']==0]['credit'].value_counts()


# In[154]:


print (get_scores_regression(df,['status'],[2],[0],[],[],['age','sex'],'credit'))
print (get_scores_regression(df,['status'],[2],[0],['age','sex'],[0,0],[],'credit'))
print (get_scores_regression(df,['status'],[2],[0],['age','sex'],[1,1],[],'credit'))
print (get_scores_regression(df,['status'],[2],[0],['age','sex'],[1,0],[],'credit'))
print (get_scores_regression(df,['status'],[2],[0],['age','sex'],[0,1],[],'credit'))


# In[ ]:





# In[140]:


print (get_scores_regression(df,['status'],[3],[1],['age'],[1],['sex'],'credit'))


# In[139]:


print (get_scores_regression(df,['status'],[3],[1],[],[],['age','sex'],'credit'))


# In[126]:


print (get_scores_regression(df,['credit_amount'],[0],[3],['age','sex'],[1,1],[],'credit'))


# In[129]:


print (get_scores_regression(df,['credit_amount'],[2],[0],[],[],['age','sex'],'credit'))


# In[115]:


print (get_scores_regression(df,['status'],[1],[0],[],[],[],'credit'))


# In[80]:


#Test with logistic regression and random forest regressor
#Make sure classifier is random forest in all codes


# In[81]:


print (get_scores_regression(df,['housing'],[1],[2],[],[],['age','sex'],'credit'))


# In[82]:


print (get_scores_regression(df,['housing'],[1],[0],[],[],['age','sex'],'credit'))


# In[100]:


print (get_scores_regression(df,['housing'],[0],[2],[],[],['age','sex'],'credit'))


# In[102]:


df.iloc[1]


# In[30]:


print (get_scores_regression(df,['credit_history'],[4],[2],['age','sex','purpose','property','month'],[0,0,3,1,0],[],'credit'))


# In[ ]:





# In[28]:


df.iloc[1]


# In[32]:


###LOcal explanations here
row=list(df.columns)
value_map={}
for feat in row:
    values=list(set(df[feat]))
    value_map[feat]=values




print(row)
row.remove('credit')
rowval=[]
curr=df.iloc[405]
for feat in row:
    rowval.append(curr[feat])
print (value_map)
    
featnames=copy.deepcopy(row)
maxscores=[]
for feat in featnames:
    curr_feat=feat
    ind=row.index(curr_feat)
    prevval=rowval[ind]
    rowval.pop(ind)
    row.pop(ind)
    
    
    values=value_map[feat]
    max_suff=-1
    suff_val=-1
    for val in values:
        suff=get_scores_regression(df,[curr_feat],[val],[prevval],row,rowval,[],'credit')[1]
        max_suff=max(max_suff,suff)
        if max_suff==suff:
            suff_val=val
    print (feat,max_suff,suff_val,prevval)
    maxscores.append(max_suff)
    row.append(feat)
    rowval.append(prevval)
print (featnames,maxscores)


# In[ ]:


###LOcal explanation to reduce
maxscores=[]
for feat in featnames:
    curr_feat=feat
    ind=row.index(curr_feat)
    prevval=rowval[ind]
    rowval.pop(ind)
    row.pop(ind)
    
    
    values=value_map[feat]
    max_suff=-1
    suff_val=-1
    val=min(values)
    suff=get_scores_regression(df,[curr_feat],[prevval],[val],row,rowval,[],'credit')[1]
    max_suff=max(max_suff,suff)
    if max_suff==suff:
        suff_val=val
    print (feat,max_suff,suff_val,prevval,val)
    maxscores.append(max_suff)
    row.append(feat)
    rowval.append(prevval)
print (featnames,maxscores)


# In[190]:


get_scores_regression(df,['age'],[1],[0],['sex'],[0],[],'credit')[1]


# In[191]:


get_scores_regression(df,['sex'],[1],[0],['age'],[0],[],'credit')[1]


# In[98]:


row=list(df.columns)

row.remove('credit')

rowval=list(df.iloc[405][row])

rowval.pop(row.index('credit_amount'))
row.remove('credit_amount')
rowval.pop(row.index('status'))
row.remove('status')

rowval.pop(row.index('employment'))
row.remove('employment')

print (len(row))
print (len(rowval))
get_scores_regression(df,['status','employment','credit_amount'],[3,0,4],[2,0,0],row,rowval,[],'credit')


# In[54]:


df['credit_history'].value_counts()


# In[40]:


get_scores_regression(df,['status','credit_amount'],[3,2],[2,0],row,rowval,[],'credit')


# In[ ]:


print (get_scores_regression(df,['status'],[3],[2],['age','sex','purpose','credit_history','property','month'],[0,0,3,2,1,0],[],'credit'))


# In[ ]:


print (get_scores_regression(df,['property'],[1],[0],['age','sex','purpose','credit_history'],[0,0,4,2],[],'credit'))


# In[ ]:


print (get_scores_regression(df,['credit_history'],[4],[2],['age','sex','purpose'],[0,0,4],[],'credit'))


# In[ ]:


df['investment_as_income_percentage'].value_counts()


# In[ ]:


print (get_scores_regression(df,['purpose'],[0],[2],[],[],[],'credit'))


# In[ ]:


uniqval=list(set(df['purpose']))
i=0
while i<len(uniqval):
    j=i+1
    while j<len(uniqval):
        score1=get_scores_regression(df,['purpose'],[uniqval[i]],[uniqval[j]],[],[],[],'credit')
        score2=get_scores_regression(df,['purpose'],[uniqval[j]],[uniqval[i]],[],[],[],'credit')
        print(uniqval[i],uniqval[j],score1)
        print(i,j,score2)
        j+=1
    i+=1


# In[30]:


def get_majority(dic1,s1,s2,feat):
    score=[0,0,0]
    if feat in dic1.keys():
        score=dic1[feat]
        
    i=0
    while i<3:
        score[i]=max(score[i],s1[i])
        score[i]=max(score[i],s2[i])
        i+=1
    dic1[feat]=score
    return dic1

def get_score_dic(df,feat):
    score_dic={}
    for feat in featlst:
        print (feat)
        uniqval=list(set(list(df[feat])))
        if feat=='age' or feat=='sex':
            i=0
            while i<len(uniqval):
                j=i+1
                while j<len(uniqval):
                    score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],[],'credit')
                    score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],[],'credit')
                    score_dic=get_majority(score_dic,score1,score2,feat)
                    j+=1
                i+=1
        else:
            i=0
            while i<len(uniqval):
                j=i+1
                while j<len(uniqval):
                    score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],['age','sex'],'credit')
                    score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],['age','sex'],'credit')
                    score_dic=get_majority(score_dic,score1,score2,feat)
                    j+=1
                i+=1

    print (score_dic)
    return (score_dic)


# In[ ]:





# In[63]:


print (v1,v2,get_scores_regression(df,['purpose'],[3],[2],[],[],[],'credit'))


# In[61]:


print (v1,v2,get_scores_regression(df,['purpose'],[3],[2],[],[],['age','sex'],'credit'))


# In[64]:


print (v1,v2,get_scores_regression(df,['purpose'],[3],[2],[],[],['age','sex'],'credit'))


# In[161]:


print ("Scores for  z=sex",get_scores_regression(df,['sex'],[1],[0],[],[],[],'credit'))


# In[20]:


for v1 in [0,1,2,3,4,5,6,7,8]:
    for v2 in [0,1,2,3,4,5,6,7,8]:
        if v2>v1:
            print (v1,v2,get_scores_regression(df,['purpose'],[v2],[v1],[],[],[],'credit'))


# In[21]:


for v1 in [0,1,2,3,4,5,6,7,8]:
    for v2 in [0,1,2,3,4,5,6,7,8]:
        if v2>v1:
            print (v1,v2,get_scores_regression(df,['purpose'],[v2],[v1],[],[],['age','sex'],'credit'))


# In[14]:


print ("Scores for  z=sex",get_scores_regression(df,['purpose'],[3],[0],[],[],['sex','age'],'credit'))


# In[34]:


print ("Scores for k=young, z=sex",get_scores_regression(df,['sex'],[1],[0],['age'],[0],[],'credit'))

print ("Scores for k=old, z=sex",get_scores_regression(df,['sex'],[1],[0],['age'],[1],[],'credit'))


# In[32]:


print ("Scores for Age Female",get_scores_regression(df,['age'],[1],[0],['sex'],[0],[],'credit'))

print ("Scores for Age Male",get_scores_regression(df,['age'],[1],[0],['sex'],[1],[],'credit'))


# In[37]:


print ("Scores for Status",get_scores_regression(df,['status'],[2],[1],[],[],['age','sex'],'credit'))
print ("Scores for Status",get_scores_regression(df,['status'],[3],[1],[],[],['age','sex'],'credit'))


# In[32]:


print ("Scores for Status",get_scores_regression(df,['status'],[1],[0],['age'],[0],['sex'],'credit'))
print ("Scores for Status",get_scores_regression(df,['status'],[4],[0],['age'],[0],['sex'],'credit'))


# In[33]:


print ("Scores for Status",get_scores_regression(df,['status'],[1],[0],['age'],[1],['sex'],'credit'))
print ("Scores for Status",get_scores_regression(df,['status'],[4],[0],['age'],[1],['sex'],'credit'))


# In[35]:


print ("Scores for Status",get_scores_regression(df,['status'],[2],[1],['age'],[1],['sex'],'credit'))
print ("Scores for Status",get_scores_regression(df,['status'],[2],[1],['age'],[0],['sex'],'credit'))


# In[18]:


print ("Scores for k=old, z=status",get_scores_regression(df,['status'],[1],[0],['age'],[1],['sex'],'credit'))
print ("Scores for k=young, z=status",get_scores_regression(df,['status'],[3],[2],['age'],[0],['sex'],'credit'))


# In[31]:


print ("Scores for  z=sex",get_scores_regression(df,['age'],[1],[0],[],[],[],'credit'))


# In[33]:


print ("Scores for  z=sex",get_scores_regression(df,['sex'],[1],[0],[],[],[],'credit'))


# In[139]:


df['age'].value_counts()


# In[ ]:





# # These are the experiments to get bar chart showing importance of each feature

# In[ ]:


score_dic=get_score_dic(df,feat)
n_score={}
s_score={}
sn_score={}
for feat in score_dic.keys():
    n_score[feat]=score_dic[feat][0]
    s_score[feat]=score_dic[feat][1]
    sn_score[feat]=score_dic[feat][2]
    
sorted_s = sorted(n_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_n = sorted(s_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_sn = sorted(sn_score.items(), key=lambda kv: kv[1],reverse=True)

slst=[]
nlst=[]
snlst=[]
svallst=[]
nvallst=[]
snvallst=[]
i=0
for (x,y) in sorted_s:
    slst.append(x)
    svallst.append(y)
    nlst.append(sorted_n[i][0])
    nvallst.append(sorted_n[i][1])
    snvallst.append(sorted_sn[i][0])
    snvallst.append(sorted_sn[i][1])
    print (x,svallst[-1],nvallst[-1],snvallst[-1])
    i+=1


# In[ ]:





# In[168]:


import matplotlib.pyplot as plt

plt.bar(slst, svallst, align='center')
plt.xticks(rotation=90)
#plt.xticks(range(len(klst)), list(klst))


# In[262]:



plt.bar(nlst, nvallst, align='center')
plt.xticks(rotation=90)


# In[263]:



plt.bar(snlst, snvallst, align='center')
plt.xticks(rotation=90)


# In[ ]:





# In[264]:


print ("Scores for k=young, z=sex",get_scores_regression(df,['sex'],[1],[0],[],[],[],'credit'))


# In[247]:


print ("Scores for k=young, z=sex",get_scores_regression(df,['sex'],[1],[0],['age'],[0],[],'credit'))

print ("Scores for k=old, z=sex",get_scores_regression(df,['sex'],[1],[0],['age'],[1],[],'credit'))


# In[259]:


print ("Scores for female",get_scores_regression(df,['age'],[1],[0],['sex'],[0],[],'credit'))

print ("Scores for male",get_scores_regression(df,['age'],[1],[0],['sex'],[1],[],'credit'))


# In[257]:


print ("SScore for Z=Age",get_scores_regression(df,['age'],[1],[0],[],[],[],'credit'))


# In[ ]:


print ("SScore for Z=Age",get_scores_regression(df,['sex'],[1],[0],[],[],[],'credit'))


# In[36]:


print ("Scores for k=old, z=status",get_scores_regression(df,['status'],[1],[0],['age'],[1],['sex'],'credit'))
print ("Scores for k=young, z=status",get_scores_regression(df,['status'],[1],[0],['age'],[0],['sex'],'credit'))


# In[35]:


print ("Scores for k=old, z=sex",get_scores_regression(df,['status'],[1],[0],['age'],[1],['sex'],'credit'))
print ("Scores for k=young, z=status",get_scores_regression(df,['status'],[3],[0],['age'],[1],['sex'],'credit'))


# In[37]:


print ("Scores for k=old, z=status",get_scores_regression(df,['status'],[1],[0],['age'],[1],['sex'],'credit'))
print ("Scores for k=young, z=status",get_scores_regression(df,['status'],[3],[2],['age'],[0],['sex'],'credit'))


# In[33]:



print (get_scores_regression(df,['status'],[1],[0],['age'],[0],['sex'],'credit'))
print (get_scores_regression(df,['status'],[3],[0],['age'],[0],['sex'],'credit'))


# In[29]:


print (get_scores_regression(df,['status'],[1],[0],['sex'],[0],['age'],'credit'))
print (get_scores_regression(df,['status'],[3],[0],['sex'],[0],['age'],'credit'))


# In[31]:


print (get_scores_regression(df,['status'],[1],[0],['sex'],[1],['age'],'credit'))
print (get_scores_regression(df,['status'],[3],[0],['sex'],[1],['age'],'credit'))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


#Code to calculate scores

debug=False
#Returns a list of C vals and their probability
def get_combination(lst,tuplelst):
    i=0
    new_tuplelst=[]
    if len(tuplelst)==0:
        l=lst[0]
        for v in l:
            new_tuplelst.append([v])
        if len(lst)>1:
            return get_combination(lst[1:],new_tuplelst)
        else:
            return new_tuplelst
    

    currlst=lst[0]
    for l in tuplelst:
        
        for v in currlst:
            newl=copy.deepcopy(l)
            newl.append(v)
            new_tuplelst.append(newl)
        
    if len(lst)>1:
        return get_combination(lst[1:],new_tuplelst)
    else:
        return new_tuplelst
        
    
def get_C_set(df,C):
    lst=[]
    for Cvar in C:
        lst.append(list(set(list(df[Cvar]))))
        
    combination_lst= (get_combination(lst,[]))
    
    return combination_lst

def get_prob_c(inpsample,c,C):
    sample=copy.deepcopy(inpsample)
    if not c=='':
        i=0
        while i<len(C):
            sample=sample[sample[C[i]]==c[i]]
            i+=1

    return sample.shape[0]*1.0/inpsample.shape[0]
def get_count(lst):
    count={}
    uniq=list(set(lst))
    for v in uniq:
        count[v]=0
    for v in lst:
        count[v]+=1
    if 1 not in count.keys():
        count[1]=0
    if 2 not in count.keys():
        count[2]=0
    return count
    
def get_prob(inpsample,c,C,target):
    if debug:
        print ("Getting prob for",c,inpsample.shape)
    sample=copy.deepcopy(inpsample)
    if not c=='':
        i=0
        while i<len(C):
            sample=sample[sample[C[i]]==c[i]]
            i+=1
    count=(get_count(list(sample[target])))
    #print (count)
    if sample.shape[0]==0:
        return 0
    if 2 not in count.keys():
        return 0
    if 1 not in count.keys():
        return 1
    return count[1]*1.0/(count[1]+count[2]) #P[o|czk]
    
def get_scores(df,z_attr,z,zprime,klst,C,target):
    sample=df
    for (k,kval) in klst:
        sample=sample[df[k]==kval]
    sample=sample.loc[(sample[z_attr]==z) | (sample[z_attr]==zprime)]#=z | sample[z_attr]==zprime]   
 
    if debug:
        print ("Given k number of data points",sample.shape)
    
    
    #Sample is given k
    sample_z=sample[sample[z_attr]==z]#|z,k
    sample_zp=sample[sample[z_attr]==zprime] #|z',k
    
    if debug:
        print ("Given z,k number of datapoints",sample_z.shape)
        print ("given zprime,k number of datapoints",sample_zp.shape)
    #10 have Z
    #68 have zp
    
    if len(C)>0:
        Clst=get_C_set(df,C)
    else:
        Clst=['']
    snum=0
    nnum=0
    snnum=0
    for cval in Clst:
        if debug:
            print("cval is ",cval,C)
        pogivenczk=get_prob(sample_z,cval,C,target)
        pogivenczpk=get_prob(sample_zp,cval,C,target)
        pck=get_prob_c(sample,cval,C)
        if debug:
            print ("P[o|czk]",pogivenczk)
            print ("P[o|cz'k]",pogivenczpk,pck)
        snum+=pogivenczk*pck
        nnum+=pogivenczpk*pck
        snnum+=(pogivenczk-pogivenczpk)*pck
        if debug:
            print (snum,nnum,snnum)
    
    sample_target=get_count(sample[target])
    pogivenk=sample_target[1]*1.0/(sample_target[1]+sample_target[2])
    
    sample_target_z=get_count(sample_z[target])
    pogivenzk=sample_target_z[1]*1.0/(sample_target_z[1]+sample_target_z[2])
    
    
    sample_target_zp=get_count(sample_zp[target])
    popgivenzpk=sample_target_zp[2]*1.0/(sample_target_zp[1]+sample_target_zp[2])
    pogivenzpk=1-popgivenzpk
    
    
    pzgivenk=sample_z.shape[0]*1.0/(sample_z.shape[0]+sample_zp.shape[0])
    pzpgivenk=1-pzgivenk
    pozgivenk = pogivenzk*pzgivenk
    
    popzpgivenk=popgivenzpk*pzpgivenk
    print (pogivenk,popzpgivenk,pozgivenk,"these")    
    sn=max(0,snnum)
    s= max(0,(snum-pogivenk)*1.0/popzpgivenk)
    n= max(0,(pogivenk-nnum)*1.0/pozgivenk)
    print (pogivenzk,pogivenk)
    #Validation:
    rhs=pozgivenk*n+(1-pogivenzpk)*(1-pzgivenk)*s
    lhs=sn
    print ("Verification",lhs,rhs)
    return (n,s,sn)


# In[186]:


df


# In[91]:


#print ("Scores for k=old, z=sex",get_scores_regression(df,'housing',1,0,['sex'],['0'],['age'],'credit'))


# In[94]:


print ("Scores for k=old, z=sex",get_scores_regression(df,'status',3,0,['age','sex'],['0','0'],['age'],'credit'))


# In[ ]:





# In[84]:


print ("Scores for k=old, z=sex",get_scores_regression(df,'sex',1,0,['age'],['1'],[],'credit'))

print ("Scores for k=old, z=sex",get_scores_regression(df,'sex',1,0,['age'],['0'],[],'credit'))


# In[146]:





# In[11]:


print ("Scores for k=old, z=sex",get_scores(new_df,'sex',1,0,[('age',1)],[],'credit'))
print ("Scores for k=young,z=sex",get_scores(new_df,'sex',1,0,[('age',0)],[],'credit'))


# In[12]:


#IMPORTANT
print ("Scores for k=male, z=status",get_scores(new_df,'status',1,0,[('sex',1)],['age'],'credit'))
print ("Scores for k=female,z=status",get_scores(new_df,'status',1,0,[('sex',0)],['age'],'credit'))


# In[13]:


print ("Scores for k=male, z=savings",get_scores(new_df,'savings',1,0,[('sex',1)],['age'],'credit'))
print ("Scores for k=female,z=savings",get_scores(new_df,'savings',1,0,[('sex',0)],['age'],'credit'))


# In[14]:


#Small change in savings does not help young
#Large change in saving helps
print ("Scores for k=old, z=saving",get_scores(new_df,'savings',1,0,[('age',1)],['sex'],'credit'))
print ("Scores for k=young,z=saving",get_scores(new_df,'savings',1,0,[('age',0)],['sex'],'credit'))


print ("Scores for k=old, z=saving",get_scores(new_df,'savings',2,0,[('age',1)],['sex'],'credit'))
print ("Scores for k=young,z=saving",get_scores(new_df,'savings',2,0,[('age',0)],['sex'],'credit'))


# In[57]:


#Going from 2 to 3 is not helping as much as going from 0-2

print("Scores for k=old,z=saving",get_scores(new_df,'savings',3,2,[('age',1)],['sex'],'credit'))
print("Scores for,k=young,z=saving",get_scores(new_df,'savings',3,2,[('age',0)],['sex'],'credit'))


# In[ ]:





# In[69]:


from dowhy import CausalModel
import dowhy.datasets

graph="""graph[directed 1 node[id "S" label "S"]  
                    node[id "T" label "T"]  
                    node[id "D" label "D"]  
                    node[id "C" label "C"]  
                    node[id "Y" label "Y"]   
                    edge[source "S" target "T"]
                    edge[source "S" target "D"]
                    edge[source "C" target "T"]
                    edge[source "C" target "D"]
                    edge[source "C" target "Y"]
                    edge[source "T" target "Y"]
                    edge[source "D" target "Y"]]"""

# Create a causal model from the data and given graph.
model = CausalModel(
    data=dataset_df,
    treatment="D",
    outcome="Y",
    graph=graph)#data["gml_graph"])
model.view_model()
backdoor={'T':['S','C'],'D':['S','C']}


# In[ ]:





# In[ ]:


#Old Code not needed anymore


# In[ ]:


def get_scores_ignorability(df,z_attr,z,zprime,klst,target):
    sample=df
    for (k,kval) in klst:
        sample=sample[df[k]==kval]
    option=2
    yswap=True
    if option==1:
        
        sample=sample.loc[(sample[z_attr]==z) | (sample[z_attr]==zprime)]#=z | sample[z_attr]==zprime]   
 
        #sample=sample[df[z_attr]==z or df[z_attr]==zprime]
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z_attr].value_counts().sort_index())) #z|k
        print (zz_count)
        #zzp_count=(list(sample[zprime].value_counts().sort_index())) #z|k
        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_z=sample[sample[z_attr]==z]#|z,k
        sample_zp=sample[sample[z_attr]==zprime] #|z',k
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
    
        pzgivenk = zz_count[1]*1.0/(zz_count[1]+zz_count[0])
        pzpgivenk = zz_count[0]*1.0/(zz_count[1]+zz_count[0])
        pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
        pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
   
    else:
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z_attr].value_counts().sort_index())) #z|k
        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_zp=sample[sample[z_attr]==zprime] #|z',k
        sample_z=sample[sample[z_attr]!=zprime] #|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
        
        pzpgivenk = zz_count[zprime]*1.0/(sum(zz_count))#[zprime]+zzp_count[1])
        pzgivenk=1-pzpgivenk
        
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
        pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
   
    


    
    
    
     
    pogivenk=s_count[1]*1.0/(s_count[0]+s_count[1]) ##P[o|k]
    
    if yswap:
        pogivenZk=1-pogivenZk
        pogivenZPk=1-pogivenZPk
        pogivenk=1-pogivenk
    pozgivenk= pogivenZk*pzgivenk
    pozpgivenk = pogivenZPk * pzpgivenk
   
    popzpgivenk=(1-pogivenZPk)*(pzpgivenk)
    sn=pogivenZk - pogivenZPk
    n= (pogivenk-pogivenZPk)*1.0/(pozgivenk)#Needs to be checked
    s= (pogivenZk-pogivenk)*1.0/(popzpgivenk)
    
    #Validation:
    rhs=pozgivenk*n+(1-pogivenZPk)*(1-pzgivenk)*s
    lhs=sn
    print (lhs,rhs)
    return (n,s,sn)
    


# In[ ]:


get_scores_ignorability(new_df,'status',2,0,[('purpose',3),('age',0)],'credit')
get_scores_ignorability(new_df,'status',2,0,[('purpose',3),('age',1)],'credit')
get_scores_ignorability(new_df,'status',2,0,[('purpose',3)],'credit')
get_scores_ignorability(new_df,'sex',1,0,[('age',1)],'credit')
get_scores_ignorability(new_df,'sex',1,0,[('age',0)],'credit')


# In[386]:



def get_scores_ignorability(df,z,zprime,k,kval,target):
    sample=df[df[k]==kval]
    option=2
    yswap=True
    if option==1:
        sample=sample[df[z]+df[zprime]==1]
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z].value_counts().sort_index())) #z|k
        zzp_count=(list(sample[zprime].value_counts().sort_index())) #z|k

        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_z=sample[sample[z]==1.0]#|z,k
        sample_zp=sample[sample[zprime]==1.0] #|z',k
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
    
        pzgivenk = zz_count[1]*1.0/(zz_count[0]+zz_count[1])
        pzpgivenk = zzp_count[1]*1.0/(zzp_count[0]+zzp_count[1])

    else:
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z].value_counts().sort_index())) #z|k
        zzp_count=(list(sample[zprime].value_counts().sort_index())) #z|k
        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_z=sample[sample[zprime]==0.0]#|z,k
        sample_zp=sample[sample[zprime]==1.0] #|z',k
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
    
        pzpgivenk = zzp_count[1]*1.0/(zzp_count[0]+zzp_count[1])
        pzgivenk=1-pzpgivenk
    


    
    
    
    pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
    pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
     
    pogivenk=s_count[1]*1.0/(s_count[0]+s_count[1]) ##P[o|k]
    
    if yswap:
        pogivenZk=1-pogivenZk
        pogivenZPk=1-pogivenZPk
        pogivenk=1-pogivenk
    pozgivenk= pogivenZk*pzgivenk
    pozpgivenk = pogivenZPk * pzpgivenk
   
    popzpgivenk=(1-pogivenZPk)*(pzpgivenk)
    sn=pogivenZk - pogivenZPk
    n= (pogivenk-pogivenZPk)*1.0/(pozgivenk)#Needs to be checked
    s= (pogivenZk-pogivenk)*1.0/(popzpgivenk)
    
    #Validation:
    rhs=pozgivenk*n+(1-pogivenZPk)*(1-pzgivenk)*s
    lhs=sn
    print (lhs,rhs)
    return (n,s,sn)
    


# In[387]:


get_scores_ignorability(orig_df,'status=A13','status=A11','purpose=A42',1.0,'credit')


# In[361]:


def get_scores_ignorability_single(df,z,k,kval,target):

    yswap=True
    sample=df[df[k]==kval]

    s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
    zz_count=(list(sample[z].value_counts().sort_index())) #z|k
    sample_z=sample[sample[z]==1.0]#|z,k
    sample_zp=sample[sample[z]==0.0] #|z',k
 
    z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
    zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
   
    #print (z_count,sample_z[target].value_counts())
    pzgivenk = zz_count[1]*1.0/(zz_count[0]+zz_count[1])
    pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
    pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
     
    pogivenk=s_count[1]*1.0/(s_count[0]+s_count[1]) ##P[o|k]
    
    if yswap:
        pogivenZk=1-pogivenZk
        pogivenZPk=1-pogivenZPk
        pogivenk=1-pogivenk
    pozgivenk= pogivenZk*pzgivenk
    pozpgivenk = pogivenk-pozgivenk
    popzpgivenk=(1-pogivenZPk)*(1-pzgivenk)
    sn=pogivenZk - pogivenZPk
    n= (pogivenk-pogivenZPk)*1.0/(pozgivenk)#Needs to be checked
    s= (pogivenZk-pogivenk)*1.0/(popzpgivenk)
    
    
    
    #Validation:
    rhs=pozgivenk*n+(1-pogivenZPk)*(1-pzgivenk)*s
    lhs=sn
    print (lhs,rhs)
    return (n,s,sn)
    


# In[ ]:





# In[362]:


get_scores_ignorability_single(dataset_df,'sex','age',1.0,'credit')


# In[246]:


get_scores_ignorability_single(dataset_df,'sex','age',0.0,'credit')


# In[120]:


#Causal Graph for German dataset
# A,G->E
#A,G,E->I
#I->S
#A,G->L
#A,L,G->D
dataset_df[['age','sex','purpose=A46']]


# In[55]:


def get_scores_ignorability(df,v_attr,vprime,k,kthres,target):
    sample=df[df[k]==kthres]
    
    s_count=(list(sample[target].value_counts()))
    sample_v=sample[sample[v_attr]==1.0]
    sample_vp=sample[sample[vprime]==1.0]
    sample_count= (list(sample_v[target].value_counts()))
    samplevp_count= (list(sample_vp[target].value_counts()))
    
    po1v = sample_count[1]*1.0/(sample_count[1]+sample_count[0])
    po0vp= samplevp_count[1]*1.0/(samplevp_count[0]+ samplevp_count[1])
    
    ps=s_count[1]*1.0/(s_count[0]+s_count[1])
    
    
    sn=po1v - po0vp
    n= (ps-po0vp)*1.0/(po1v)#Needs to be checked
    s= (po1v-ps)*1.0/(1-po0vp)
    return (n,s,sn)
    


# In[58]:


def get_scores_ignorability_single(df,v_attr,k,kthres,target):
    if 'no' in k:
        sample=df
    else:
        sample=df[df[k]==kthres]
    
    s_count=(list(sample[target].value_counts()))
    sample_v=sample[sample[v_attr]==0.0]
    sample_vp=sample[sample[v_attr]==1.0]
    sample_count= (list(sample_v[target].value_counts()))
    samplevp_count= (list(sample_vp[target].value_counts()))
    
    po1v = sample_count[1]*1.0/(sample_count[1]+sample_count[0])
    po0vp= samplevp_count[1]*1.0/(samplevp_count[0]+ samplevp_count[1])
    
    ps=s_count[1]*1.0/(s_count[0]+s_count[1])
    
    
    sn=po1v - po0vp
    n= (ps-po0vp)*1.0/(po1v)#Needs to be checked
    s= (po1v-ps)*1.0/(1-po0vp)
    return (n,s,sn)
    


# In[59]:


get_scores_ignorability(dataset_df,'status=A11','status=A13','purpose=A42',1.0,'credit')


# In[60]:


get_scores_ignorability(dataset_df,'status=A11','status=A14','purpose=A42',1.0,'credit')


# In[61]:


get_scores_ignorability(dataset_df,'status=A12','status=A14','purpose=A42',1.0,'credit')


# In[62]:


get_scores_ignorability(dataset_df,'status=A12','status=A13','purpose=A42',1.0,'credit')


# In[63]:


get_scores_ignorability(dataset_df,'status=A11','status=A12','purpose=A42',1.0,'credit')


# In[64]:


get_scores_ignorability_single(dataset_df,'sex','purpose=A41',1.0,'credit')


# In[65]:


get_scores_ignorability_single(dataset_df,'sex','purpose=A42',1.0,'credit')


# In[56]:


get_scores_ignorability_single(dataset_df,'sex','no',1.0,'credit')


# In[59]:


get_scores_ignorability_single(dataset_df,'sex','property=A121',1.0,'credit')


# In[60]:


get_scores_ignorability_single(dataset_df,'sex','age',1.0,'credit')


# In[61]:


get_scores_ignorability_single(dataset_df,'sex','age',0.0,'credit')


# In[ ]:


#Age and gender


# In[10]:


#Causal Graph for German dataset
# A,G->E
#A,G,E->I
#I->S
#A,G->L
#A,L,G->D
graph="""graph[directed 1 node[id "A" label "A"]  
                    node[id "G" label "G"]  
                    node[id "E" label "E"]  
                    node[id "I" label "I"]  
                    node[id "S" label "S"]  
                    node[id "L" label "L"]  
                    node[id "D" label "D"]  
                    edge[source "A" target "E"]
                    edge[source "G" target "E"]
                    edge[source "A" target "I"]
                    edge[source "G" target "I"]
                    edge[source "E" target "I"]
                    edge[source "I" target "S"]
                    edge[source "A" target "L"]
                    edge[source "G" target "L"]
                    edge[source "A" target "D"]
                    edge[source "L" target "D"]
                    edge[source "G" target "D"]
                    edge[source "E" target "S"]]"""


graph="""graph[directed 1 node[id "A" label "A"]  
                    node[id "G" label "G"]  
                    node[id "E" label "E"]  
                    node[id "I" label "I"]  
                    node[id "S" label "S"]  
                    node[id "L" label "L"]  
                    node[id "D" label "D"]  
                    edge[source "A" target "E"]
                    edge[source "A" target "I"]
                    edge[source "I" target "S"]
                    edge[source "E" target "S"]]"""


# In[11]:


from dowhy import CausalModel
import dowhy.datasets

# Create a causal model from the data and given graph.
model = CausalModel(
    data=dataset_df,
    treatment="E",
    outcome="S",
    graph=graph)#data["gml_graph"])

# Identify causal effect and return target estimands
identified_estimand = model.identify_effect()
print(identified_estimand)


# In[12]:


model.view_model()


# In[13]:


data = dowhy.datasets.linear_dataset(
    beta=10,
    num_common_causes=5,
    num_instruments=2,
    num_samples=10000,
    treatment_is_binary=True)


# In[14]:


print(data["treatment_name"])


# In[15]:


model = CausalModel(
    data=data["df"],
    treatment=data["treatment_name"],
    outcome=data["outcome_name"],
    graph=data["gml_graph"])

# Identify causal effect and return target estimands
identified_estimand = model.identify_effect()


# In[16]:


print(identified_estimand)


# In[ ]:


#Causal Graph for German dataset
# A,G->E
#A,G,E->I
#I->S
#A,G->L
#A,L,G->D


# In[ ]:


#Todo:
#Apply regression on each edge
# For a given intervention calculate the scores


# In[ ]:


#Compare with shapley value and other options!


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[36]:


sample_v=sample[sample['status=A13']==1.0]
sample_vp=sample[sample['status=A13']==0.0]


# In[21]:


print (sample_v.credit.hist())


# In[80]:


print (sample_vp.credit.hist())


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[52]:


train_df=get_data(1000)
test_df=get_data(1000)
val_df=get_data(1000)
train_df_selection=train_df[train_df.X2<0.5]
val_df_selection=train_df[val_df.X2<0.5]
privileged_groups = [{'S': 1}]
unprivileged_groups = [{'S': 0}]
bld_te = BinaryLabelDataset(df=test_df, label_names=['Y'],protected_attribute_names=['S'])


# In[53]:


#print (train_df_selection.Y.value_counts())
considered_feat=['X1','X2']


# In[54]:


def train_and_print_metric(df,considered_feat,target,test_df,test_bld,unprivileged_groups,privileged_groups):
    df_considered=df[considered_feat]
    test_df_considered=test_df[considered_feat]
    model = LogisticRegression(random_state=10).fit(df_considered, target)
    y_pred=model.predict(test_df_considered)

    dataset_pred = test_bld.copy()
    dataset_pred.labels=y_pred
    metric_selection = ClassificationMetric(
                bld_te, dataset_pred,
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups)

    print ("Results")
    print("Odds difference",metric_selection.average_odds_difference())
    print("Disparate impact",metric_selection.disparate_impact())
    print(metric_selection.statistical_parity_difference())
    print(metric_selection.equal_opportunity_difference())
    print(metric_selection.theil_index())
    print ("Accuracy",metric_selection.accuracy())


# In[55]:


print ("Results on complete dataset")
train_and_print_metric(train_df,considered_feat,train_df['Y'],test_df,bld_te,unprivileged_groups,privileged_groups)


# In[56]:


print ("Results on biased dataset, selection variable is X2")
train_and_print_metric(train_df_selection,considered_feat,train_df_selection['Y'],test_df,bld_te,unprivileged_groups,privileged_groups)


# In[57]:


print ("Trying reweighting on the biased dataset")
RW = Reweighing(unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups)

bld_trs = BinaryLabelDataset(df=train_df_selection, label_names=['Y'],protected_attribute_names=['S'])
bld_te = BinaryLabelDataset(df=test_df, label_names=['Y'],protected_attribute_names=['S'])

dataset_transf_train = RW.fit_transform(bld_trs)

model = LogisticRegression(random_state=10).fit(dataset_transf_train.features, dataset_transf_train.labels.ravel())
test_df_new=test_df.drop(columns=['Y'])
y_pred=model.predict(test_df_new)

dataset_pred = bld_te.copy()
dataset_pred.labels=y_pred
metric_selection = ClassificationMetric(
                bld_te, dataset_pred,
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups)

print ("Reweighting Results")
print("Odds difference",metric_selection.average_odds_difference())
print("Disparate impact",metric_selection.disparate_impact())
print(metric_selection.statistical_parity_difference())
print(metric_selection.equal_opportunity_difference())
print(metric_selection.theil_index())
print ("Accuracy",metric_selection.accuracy())


# In[58]:


from aif360.algorithms.postprocessing import EqOddsPostprocessing


df_considered=train_df_selection[considered_feat]

val_df_considered=val_df_selection[considered_feat]
test_df_considered=test_df[considered_feat]
bld_val = BinaryLabelDataset(df=val_df_selection, label_names=['Y'],protected_attribute_names=['S'])


model = LogisticRegression(random_state=10).fit(df_considered, train_df_selection['Y'])
val_pred_label=model.predict(val_df_considered)
y_pred=model.predict(test_df_considered)

val_pred = bld_val.copy()
val_pred.labels=val_pred_label
bld_ten=BinaryLabelDataset(df=test_df,label_names=['Y'],protected_attribute_names=['S'])

dataset_pred = bld_ten.copy()
dataset_pred.labels=y_pred.reshape((-1, 1))

eqo = EqOddsPostprocessing(unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups, seed=1234567)

pred_eqo = eqo.fit(bld_val, val_pred).predict(dataset_pred)

cm_eqo = ClassificationMetric(bld_te, pred_eqo,
            unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups)
    
print ("Post processing Equalized odds postprocessing")
print("Odds difference",cm_eqo.average_odds_difference())
print("Disparate impact",cm_eqo.disparate_impact())
print(cm_eqo.statistical_parity_difference())
print(cm_eqo.equal_opportunity_difference())
print(cm_eqo.theil_index())
print ("Accuracy",cm_eqo.accuracy())


# In[59]:


from aif360.algorithms.postprocessing import CalibratedEqOddsPostprocessing


df_considered=train_df_selection[considered_feat]

val_df_considered=val_df_selection[considered_feat]
test_df_considered=test_df[considered_feat]

bld_val = BinaryLabelDataset(df=val_df_selection, label_names=['Y'],protected_attribute_names=['S'])


model = LogisticRegression(random_state=10).fit(df_considered, train_df_selection['Y'])
val_pred_label=model.predict(val_df_considered)
val_pred_scores=model.predict_proba(val_df_considered)

y_pred=model.predict(test_df_considered)

val_pred = bld_val.copy()

val_pred.labels=val_pred_label
val_pred.scores=val_pred_scores[:, 1]

bld_ten=BinaryLabelDataset(df=test_df,label_names=['Y'],protected_attribute_names=['S'])

dataset_pred = bld_ten.copy()
dataset_pred.labels=y_pred.reshape((-1, 1))

dataset_pred.scores=model.predict_proba(test_df_considered)[:,1]


eqo = CalibratedEqOddsPostprocessing(unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups, seed=1234567,cost_constraint='fpr')

pred_eqo = eqo.fit(bld_val, val_pred).predict(dataset_pred)



cm_eqo = ClassificationMetric(bld_ten, pred_eqo,
            unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups)
    
print ("Post processing Equalized odds postprocessing")
print("Odds difference",cm_eqo.average_odds_difference())
print("Disparate impact",cm_eqo.disparate_impact())
print(cm_eqo.statistical_parity_difference())
print(cm_eqo.equal_opportunity_difference())
print(cm_eqo.theil_index())
print ("Accuracy",cm_eqo.accuracy())


# In[ ]:





# In[62]:


train_df.to_csv('train.csv',index=False)
test_df.to_csv('test.csv',index=False)
train_df_selection.to_csv('train_selection.csv',index=False)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




