#!/usr/bin/env python
# coding: utf-8

# # Install packages

# In[1]:


import numpy as np
import pandas as pd
from collections import namedtuple, Counter

import copy
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


# In[2]:
from sklearn.utils import resample

df=pd.read_csv('adult/train.txt',delimiter=' ')
df

backdoor={'Age':[],'sex':[],'country':[],'marital':['country','Age'],'edu':['Age','sex','marital'],
          'class':['Age','sex','marital'],'occupation':['Age','sex','marital'],
          'hours':['Age','sex','marital']}
#backdoor={'Age':[],'sex':[],'country':[],'marital':['country','Age'],'edu':['Age','sex','marital','country'],
          #'class':['Age','sex','marital','country','edu'],'occupation':['Age','sex','marital','country','edu'],
          #'hours':['Age','sex','marital','country','edu']}





y_train=df['target']

col=list(df.columns)
col.remove('target')
col.remove('Unnamed: 15')

col=list(backdoor.keys())
df['sex']=1-df['sex']



featlst=list(df.columns)
featlst.remove('target')


for feat in col:
    highest=max(df[feat])
    lowest=min(df[feat])
    if len(list(set(df[feat])))>4:
        print (feat,len(list(set(df[feat]))))
    l=df[feat]
    if feat=='country':
        proc=[]
        for v in l:
            if v==0:
                proc.append(v)
            elif v<=4:
                proc.append(2)
            elif v<=10:
                proc.append(3)
            else:
                proc.append(4)
        df[feat]=proc
    elif feat=='Age':
        proc=[]
        for v in l:
            if v<=30:
                proc.append(1)
            elif v<=40:
                proc.append(2)
            elif v<=50:
                proc.append(3)
            else:
                proc.append(4)
        df[feat]=proc
    elif feat=='marital':
        proc=[]
        for v in l:
            if v<2:
                proc.append(v)
            elif v<=3:
                proc.append(3)
            else:
                proc.append(5)
        df[feat]=proc
    elif feat=='edu':
        proc=[]
        for v in l:
            if v<=1:
                proc.append(v)
            elif v<=4:
                proc.append(2)
            elif v==5:
                proc.append(5)
            else:
                proc.append(6)
        df[feat]=proc
    elif feat=='class':
        proc=[]
        for v in l:
            if v<=2:
                proc.append(v)
            else:
                proc.append(6)
        df[feat]=proc
    elif feat=='occupation':
        proc=[]
        for v in l:
            if v<=2:
                proc.append(1)
            elif v<=5:
                proc.append(v)
            elif v<=8:
                proc.append(8)
            else:
                proc.append(9)
        df[feat]=proc
    elif feat=='hours':
        proc=[]
        for v in l:
            if v<=25:
                proc.append(1)
            elif v<=41:
                proc.append(2)
            elif v<=55:
                proc.append(8)
            else:
                proc.append(9)
        df[feat]=proc
        
        
    #or feat=='Age' or feat=='edunum'or feat=='captain' or feat=='capos' or feat=='hours' or feat=='fnlwgt':
    
    #range_lst=pd.cut(l,4,labels=[0,1,2,3])
    #df[feat]=(pd.cut(l,4,labels=[0,1,2,3]))




X_train=df[col]

X_test=pd.read_csv('adult/test.txt',delimiter=' ')
y_test=X_test['target']
X_test=X_test[col]
X_test['sex']=1-X_test['sex']


for feat in col:
    if len(list(set(X_test[feat])))>4:
        print (feat,len(list(set(X_test[feat]))))
    l=X_test[feat]
    if feat=='country':
        proc=[]
        for v in l:
            if v==0:
                proc.append(v)
            elif v<=4:
                proc.append(2)
            elif v<=10:
                proc.append(3)
            else:
                proc.append(4)
        X_test[feat]=proc
    elif feat=='Age':
        proc=[]
        for v in l:
            if v<=30:
                proc.append(1)
            elif v<=40:
                proc.append(2)
            elif v<=50:
                proc.append(3)
            else:
                proc.append(4)
        X_test[feat]=proc
    elif feat=='marital':
        proc=[]
        for v in l:
            if v<2:
                proc.append(v)
            elif v<=3:
                proc.append(3)
            else:
                proc.append(5)
        X_test[feat]=proc
    elif feat=='edu':
        proc=[]
        for v in l:
            if v<=1:
                proc.append(v)
            elif v<=4:
                proc.append(2)
            elif v==5:
                proc.append(5)
            else:
                proc.append(6)
        X_test[feat]=proc
    elif feat=='class':
        proc=[]
        for v in l:
            if v<=2:
                proc.append(v)
            else:
                proc.append(6)
        X_test[feat]=proc
    elif feat=='occupation':
        proc=[]
        for v in l:
            if v<=2:
                proc.append(1)
            elif v<=5:
                proc.append(v)
            elif v<=8:
                proc.append(8)
            else:
                proc.append(9)
        X_test[feat]=proc
    elif feat=='hours':
        proc=[]
        for v in l:
            if v<=25:
                proc.append(1)
            elif v<=41:
                proc.append(2)
            elif v<=55:
                proc.append(8)
            else:
                proc.append(9)
        X_test[feat]=proc
  
        
        
#clf = RandomForestClassifier(max_depth=10, random_state=0)

#clf.fit(X_train, y_train)


clf = RandomForestClassifier(max_depth=10, random_state=0)

clf.fit(X_train, y_train)

pred= (clf.predict(X_test))
pred = [int(round(value)) for value in pred]

print(classification_report(y_test, pred))

print (clf.feature_importances_)


#print(classification_report(y_test, clf.predict(X_test)))

X_test['target']=pred#clf.predict(X_test)
df=X_test





df.to_csv('adult/adult_test_predicted.csv',index=False)


# In[ ]:







debug=False
def get_combination(lst,tuplelst):
    i=0
    new_tuplelst=[]
    if len(tuplelst)==0:
        l=lst[0]
        for v in l:
            new_tuplelst.append([v])
        if len(lst)>1:
            return get_combination(lst[1:],new_tuplelst)
        else:
            return new_tuplelst
    

    currlst=lst[0]
    for l in tuplelst:
        
        for v in currlst:
            newl=copy.deepcopy(l)
            newl.append(v)
            new_tuplelst.append(newl)
        
    if len(lst)>1:
        return get_combination(lst[1:],new_tuplelst)
    else:
        return new_tuplelst
      
def get_C_set(df,C):
    lst=[]
    for Cvar in C:
        lst.append(list(set(list(df[Cvar]))))
        
    combination_lst= (get_combination(lst,[]))
    
    return combination_lst

def get_scores_regression(df,z_attr,z,zprime,klst,kvallst,C,target):


    for v in klst:
        if v in C:
            C.remove(v)
        
    sample=df
    if debug:
        print ("Given k number of data points",sample.shape)
      
    if len(C)>0:
        Clst=get_C_set(df,C)
    else:
        Clst=['']
    
    
    snum=0
    nnum=0
    snnum=0

    for cval in Clst:
        print("cval is ",cval,C)
        if Clst[0]=='':
            Clst=[]
            
        
        
        conditional_lst=copy.deepcopy(klst)
        conditional_lst.extend(C)
        conditional_lst.extend(z_attr)
        
        conditional_val=copy.deepcopy(kvallst)
        conditional_val.extend(cval)
        
        conditional_valzp=copy.deepcopy(conditional_val)
        conditional_val.extend(z)
        conditional_valzp.extend(zprime)
        
        
        
        #print (conditional_lst,conditional_val)
        pogivenczk=get_prob_o_regression(df,conditional_lst,conditional_val,[target],[1])
        
        pogivenczpk=get_prob_o_regression(df,conditional_lst,conditional_valzp,[target],[1])
        
        
        if len(C)>0:
            #if (len(klst)>0):
            pck=get_prob_o_regression(df,klst,kvallst,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
            #else:
            #    pck=
            
            conditional=copy.deepcopy(klst)
            conditional_val=copy.deepcopy(kvallst)
            conditional.extend(z_attr)
            conditional_val.extend(z)
            #print (cval,C)
            pcgivenzk=get_prob_o_regression(df,conditional,conditional_val,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
            
            conditional_val=copy.deepcopy(kvallst)
            conditional_val.extend(zprime)
            pcgivenzpk=get_prob_o_regression(df,conditional,conditional_val,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
        else:
            pck=1
            pcgivenzpk=1
            pcgivenzk=1
        #
        if debug:
            print ("P[o|czk]",pogivenczk)
            print ("P[o|cz'k]",pogivenczpk,pck)
        popgivenczpk=1-pogivenczpk
        snum+=pogivenczk*pcgivenzpk ##P[o|do(z),k]
        nnum+=popgivenczpk*pcgivenzk ##P[o|do(z'),k]
        snnum+=(pogivenczk-pogivenczpk)*pck ##P[o|do(z),k]-P[o|do(z'),k]
        #print(snnum,pogivenczk,pogivenczpk)
        
        
        
        if debug:
            print ("numerators",snum,nnum,snnum)
    
    if len(klst)>0:
        pogivenk=get_prob_o_regression(df,klst,kvallst,[target],[1])
    else:
        pogivenk=df[df[target]==1].shape[0]*1.0/df.shape[0]
    #print (pogivenk)
    #sample_target=get_count(sample[target])
    #pogivenk=sample_target[1]*1.0/(sample_target[1]+sample_target[2])
    
    #sample_target_z=get_count(sample_z[target])
    #pogivenzk=sample_target_z[1]*1.0/(sample_target_z[1]+sample_target_z[2])
    conditional=copy.deepcopy(klst)
    conditional.extend(z_attr)
    conditional_val=copy.deepcopy(kvallst)
    conditional_val.extend(z)
    pogivenzk=get_prob_o_regression(df,conditional,conditional_val,[target],[1])
    
    
    conditional_valzp=copy.deepcopy(kvallst)
    conditional_valzp.extend(zprime)
    #sample_target_zp=get_count(sample_zp[target])
    pogivenzpk=get_prob_o_regression(df,conditional,conditional_valzp,[target],[1])
    #sample_target_zp[2]*1.0/(sample_target_zp[1]+sample_target_zp[2])
    popgivenzpk=1-pogivenzpk
    
    #sample_z=sample[sample[z_attr]==z]#|z,k
    #sample_zp=sample[sample[z_attr]==zprime] #|z',k
    
    #pzgivenk=get_prob_o_regression(df,klst,kvallst,z_attr,z)#
    #sample_z.shape[0]*1.0/(sample_z.shape[0]+sample_zp.shape[0])
    #pzpgivenk=get_prob_o_regression(df,klst,kvallst,z_attr,zprime)#
    #pozgivenk = pogivenzk*pzgivenk
    popgivenzk=1-pogivenzk
    #popzpgivenk=popgivenzpk*pzpgivenk
    #pozpgivenk=pogivenzpk*pzpgivenk
    #popzgivenk=popgivenzk*pzgivenk
    #print (pogivenk,popzpgivenk,pozgivenk,"these")
    
    sn=(snnum)
    s=((snum-pogivenzpk)*1.0/popgivenzpk)
    if nnum-popgivenzk==0:
        n=0
    else:
        n=((-popgivenzk+nnum)*1.0/pogivenzk)
    
    ##Lower bound calculation below
    '''
    nlb=(pozgivenk+pozpgivenk-pogivenzpk)*1.0/pozgivenk
    slb=(popzgivenk+popzpgivenk-popgivenzk)*1.0/popzpgivenk

    #newlb=(popgivenzpk-popzpgivenk-popzgivenk - popgivenzpk*(1-pzgivenk-pzpgivenk))*1.0/pozgivenk
    newlb=(-popgivenzk + popgivenzpk)*1.0/pogivenzk
    '''
    
    #sn=max(0,snnum)
    #s= max(0,(snum-pogivenk)*1.0/popzpgivenk)
    #n= max(0,(pogivenk-nnum)*1.0/pozgivenk)
    #print (pogivenzk,pogivenk)
    #Validation:
    #rhs=pozgivenk*n+(1-pogivenzpk)*(1-pzgivenk)*s
    #lhs=1#sn
    #print ("Verification",lhs,rhs)
    
    #print (pzgivenk+pzpgivenk)
    return (n,s,sn)#,nlb,slb,newlb)#,sn_ub,n_ub,s_ub)


# In[9]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import make_regression

def get_val(row,target,target_val):
    i=0
    while i<len(target):
        #print (row[target[i]],target_val[i])
        if not int(row[target[i]])==int(target_val[i]):
            return 0
        i+=1
    return 1

def get_prob_o_regression(df,conditional,conditional_values,target,target_val):
    #print (target_val,df.size)
    new_lst=[]
    count=0
    for index,row in df.iterrows():
        new_lst.append(get_val(row,target,target_val))
        if new_lst[-1]==1:
            count+=1
    
    if len(conditional)==0:
        return count*1.0/df.shape[0]
    #pcgivenk=df[df[target]==1].shape[0]*1.0/df.shape[0]
    if len(list(set(new_lst)))==1:
        if new_lst[0]==1:
            return 1
        else:
            return 0
    if len(conditional)>0:
        X=df[conditional]
    else:
        X=df
    #print (len(X),conditional,conditional_values)
    regr = RandomForestRegressor(random_state=0)
    #regr = LogisticRegression(random_state=0)
    regr.fit(X, new_lst)
    #print (regr.coef_.tolist())
    return (regr.predict([conditional_values])[0])
    #print (regr.predict_proba([conditional_values]),"ASDFDS")
    #return(regr.predict_proba([conditional_values])[0][1])
  

    


# In[10]:


df.columns


# In[ ]:


def get_majority(dic1,s1,s2,feat):
    score=[0,0,0]
    if feat in dic1.keys():
        score=dic1[feat]

    i=0
    while i<3:
        score[i]=max(score[i],s1[i])
        score[i]=max(score[i],s2[i])
        i+=1
    dic1[feat]=score
    return dic1
score_dic={}
featlst=['Age','sex','country','marital','edu','class','occupation','hours']
for feat in featlst:
    fout=open('outputlatestfinalsome1','a')
    print (feat)
    uniqval=list(set(list(df[feat])))
    i=0
    while i<len(uniqval):
        print(i)
        j=i+1
        while j<len(uniqval):
            score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],backdoor[feat],'target')
            score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],backdoor[feat],'target')
            score_dic=get_majority(score_dic,score1,score2,feat)
            print (uniqval[i],uniqval[j],score1,score2)
            print("DFSDAFDSAFSD")
            j+=1
        i+=1
    fout.write(feat+"  "+str(score_dic[feat][0])+" "+str(score_dic[feat][1])+" "+str(score_dic[feat][2])+"\n")
    print(feat+"  "+str(score_dic[feat][0])+" "+str(score_dic[feat][1])+" "+str(score_dic[feat][2])+"\n")
    fout.close()
print (score_dic)


# In[17]:

n_score={}
s_score={}
sn_score={}
for feat in score_dic.keys():
    n_score[feat]=score_dic[feat][0]
    s_score[feat]=score_dic[feat][1]
    sn_score[feat]=score_dic[feat][2]
    print (feat,n_score[feat],s_score[feat],sn_score[feat])


jfkls

get_scores_regression(df,['sex'],[1],[0],[],[],[],'target')


# In[16]:


df['sex'].value_counts()


# In[ ]:


set(df['Age'])


# In[32]:


print (get_scores_regression(df,['sex'],[1],[0],['race'],[0],[],'target'))

print (get_scores_regression(df,['sex'],[1],[0],['race'],[1],[],'target'))


# In[29]:


print (get_scores_regression(df,['class'],[2],[0],['race'],[0],[],'target'))

print (get_scores_regression(df,['class'],[1],[0],['race'],[1],[],'target'))


# In[62]:


#print (get_scores_regression(df,['sex'],[1],[0],['marital'],[0],['race'],'target'))
#print (get_scores_regression(df,['sex'],[1],[0],['marital'],[0],[],'target'))
#print (get_scores_regression(df,['sex'],[1],[0],['marital'],[1],[],'target'))


# In[ ]:





# In[64]:


print (get_scores_regression(df,['marital'],[1],[0],['sex'],[0],[],'target'))
print (get_scores_regression(df,['marital'],[1],[0],['sex'],[1],[],'target'))


# In[83]:


print (get_scores_regression(df,['marital'],[2],[0],['sex'],[0],[],'target'))
print (get_scores_regression(df,['marital'],[2],[0],['sex'],[1],[],'target'))


# In[74]:


print (get_scores_regression(df,['race'],[0],[1],['sex'],[0],[],'target'))
print (get_scores_regression(df,['race'],[0],[1],['sex'],[1],[],'target'))


# In[75]:


#race: {'White': 0, 'Black': 1, 'Asian-Pac-Islander': 2, 'Amer-Indian-Eskimo': 3, 'Other': 4}
print (get_scores_regression(df,['race'],[1],[3],['sex'],[0],[],'target'))
print (get_scores_regression(df,['race'],[1],[3],['sex'],[1],[],'target'))


# In[ ]:


#{1: {'State-gov': 0, 'Self-emp-not-inc': 1, 'Private': 2, 'Federal-gov': 3, 'Local-gov': 4, '?': 5,
#'Self-emp-inc': 6, 'Without-pay': 7, 'Never-worked': 8}, 
#3: {'Bachelors': 0, 'HS-grad': 1, '11th': 2, 'Masters': 3, '9th': 4, 
#'Some-college': 5, 'Assoc-acdm': 6, 'Assoc-voc': 7, '7th-8th': 8, 'Doctorate': 9, 'Prof-school': 10, '5th-6th': 11, '10th': 12, '1st-4th': 13, 'Preschool': 14, '12th': 15}, 
#5: {'Never-married': 0, 'Married-civ-spouse': 1, 'Divorced': 2, 'Married-spouse-absent': 3, 'Separated': 4, 'Married-AF-spouse': 5, 'Widowed': 6}, 
#6: {'Adm-clerical': 0, 'Exec-managerial': 1, 'Handlers-cleaners': 2, 'Prof-specialty': 3, 'Other-service': 4, 'Sales': 5, 'Craft-repair': 6, 'Transport-moving': 7, 'Farming-fishing': 8, 'Machine-op-inspct': 9, 'Tech-support': 10, '?': 11, 'Protective-serv': 12, 'Armed-Forces': 13, 'Priv-house-serv': 14},
#7: {'Not-in-family': 0, 'Husband': 1, 'Wife': 2, 'Own-child': 3, 'Unmarried': 4, 'Other-relative': 5}, 
#8: {'White': 0, 'Black': 1, 'Asian-Pac-Islander': 2, 'Amer-Indian-Eskimo': 3, 'Other': 4}, 
#9: {'Male': 0, 'Female': 1}, #Before changing
#13: {'United-States': 0, 'Cuba': 1, 'Jamaica': 2, 'India': 3, '?': 4, 'Mexico': 5, 'South': 6, 'Puerto-Rico': 7, 'Honduras': 8, 'England': 9, 'Canada': 10, 'Germany': 11, 'Iran': 12, 'Philippines': 13, 'Italy': 14, 'Poland': 15, 'Columbia': 16, 'Cambodia': 17, 'Thailand': 18, 'Ecuador': 19, 'Laos': 20, 'Taiwan': 21, 'Haiti': 22, 'Portugal': 23, 'Dominican-Republic': 24, 'El-Salvador': 25, 'France': 26, 'Guatemala': 27, 'China': 28, 'Japan': 29, 'Yugoslavia': 30, 'Peru': 31, 'Outlying-US(Guam-USVI-etc)': 32, 'Scotland': 33, 'Trinadad&Tobago': 34, 'Greece': 35, 'Nicaragua': 36, 'Vietnam': 37, 'Hong': 38, 'Ireland': 39, 'Hungary': 40, 'Holand-Netherlands': 41}, 14: {'<=50K': 0, '>50K': 1}, 0: {'|1x3 Cross validator': 0, '': 1}}


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[37]:


print ("Scores for k=old, z=status",get_scores_regression(df,['status'],[1],[0],['age'],[1],['sex'],'credit'))
print ("Scores for k=young, z=status",get_scores_regression(df,['status'],[3],[2],['age'],[0],['sex'],'credit'))


# In[33]:



print (get_scores_regression(df,['status'],[1],[0],['age'],[0],['sex'],'credit'))
print (get_scores_regression(df,['status'],[3],[0],['age'],[0],['sex'],'credit'))


# In[29]:


print (get_scores_regression(df,['status'],[1],[0],['sex'],[0],['age'],'credit'))
print (get_scores_regression(df,['status'],[3],[0],['sex'],[0],['age'],'credit'))


# In[31]:


print (get_scores_regression(df,['status'],[1],[0],['sex'],[1],['age'],'credit'))
print (get_scores_regression(df,['status'],[3],[0],['sex'],[1],['age'],'credit'))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:


#Code to calculate scores

debug=False
#Returns a list of C vals and their probability
def get_combination(lst,tuplelst):
    i=0
    new_tuplelst=[]
    if len(tuplelst)==0:
        l=lst[0]
        for v in l:
            new_tuplelst.append([v])
        if len(lst)>1:
            return get_combination(lst[1:],new_tuplelst)
        else:
            return new_tuplelst
    

    currlst=lst[0]
    for l in tuplelst:
        
        for v in currlst:
            newl=copy.deepcopy(l)
            newl.append(v)
            new_tuplelst.append(newl)
        
    if len(lst)>1:
        return get_combination(lst[1:],new_tuplelst)
    else:
        return new_tuplelst
        
    
def get_C_set(df,C):
    lst=[]
    for Cvar in C:
        lst.append(list(set(list(df[Cvar]))))
        
    combination_lst= (get_combination(lst,[]))
    
    return combination_lst

def get_prob_c(inpsample,c,C):
    sample=copy.deepcopy(inpsample)
    if not c=='':
        i=0
        while i<len(C):
            sample=sample[sample[C[i]]==c[i]]
            i+=1

    return sample.shape[0]*1.0/inpsample.shape[0]
def get_count(lst):
    count={}
    uniq=list(set(lst))
    for v in uniq:
        count[v]=0
    for v in lst:
        count[v]+=1
    if 1 not in count.keys():
        count[1]=0
    if 2 not in count.keys():
        count[2]=0
    return count
    
def get_prob(inpsample,c,C,target):
    if debug:
        print ("Getting prob for",c,inpsample.shape)
    sample=copy.deepcopy(inpsample)
    if not c=='':
        i=0
        while i<len(C):
            sample=sample[sample[C[i]]==c[i]]
            i+=1
    count=(get_count(list(sample[target])))
    #print (count)
    if sample.shape[0]==0:
        return 0
    if 2 not in count.keys():
        return 0
    if 1 not in count.keys():
        return 1
    return count[1]*1.0/(count[1]+count[2]) #P[o|czk]
    
def get_scores(df,z_attr,z,zprime,klst,C,target):
    sample=df
    for (k,kval) in klst:
        sample=sample[df[k]==kval]
    sample=sample.loc[(sample[z_attr]==z) | (sample[z_attr]==zprime)]#=z | sample[z_attr]==zprime]   
 
    if debug:
        print ("Given k number of data points",sample.shape)
    
    
    #Sample is given k
    sample_z=sample[sample[z_attr]==z]#|z,k
    sample_zp=sample[sample[z_attr]==zprime] #|z',k
    
    if debug:
        print ("Given z,k number of datapoints",sample_z.shape)
        print ("given zprime,k number of datapoints",sample_zp.shape)
    #10 have Z
    #68 have zp
    
    if len(C)>0:
        Clst=get_C_set(df,C)
    else:
        Clst=['']
    snum=0
    nnum=0
    snnum=0
    for cval in Clst:
        if debug:
            print("cval is ",cval,C)
        pogivenczk=get_prob(sample_z,cval,C,target)
        pogivenczpk=get_prob(sample_zp,cval,C,target)
        pck=get_prob_c(sample,cval,C)
        if debug:
            print ("P[o|czk]",pogivenczk)
            print ("P[o|cz'k]",pogivenczpk,pck)
        snum+=pogivenczk*pck
        nnum+=pogivenczpk*pck
        snnum+=(pogivenczk-pogivenczpk)*pck
        if debug:
            print (snum,nnum,snnum)
    
    sample_target=get_count(sample[target])
    pogivenk=sample_target[1]*1.0/(sample_target[1]+sample_target[2])
    
    sample_target_z=get_count(sample_z[target])
    pogivenzk=sample_target_z[1]*1.0/(sample_target_z[1]+sample_target_z[2])
    
    
    sample_target_zp=get_count(sample_zp[target])
    popgivenzpk=sample_target_zp[2]*1.0/(sample_target_zp[1]+sample_target_zp[2])
    pogivenzpk=1-popgivenzpk
    
    
    pzgivenk=sample_z.shape[0]*1.0/(sample_z.shape[0]+sample_zp.shape[0])
    pzpgivenk=1-pzgivenk
    pozgivenk = pogivenzk*pzgivenk
    
    popzpgivenk=popgivenzpk*pzpgivenk
    print (pogivenk,popzpgivenk,pozgivenk,"these")    
    sn=max(0,snnum)
    s= max(0,(snum-pogivenk)*1.0/popzpgivenk)
    n= max(0,(pogivenk-nnum)*1.0/pozgivenk)
    print (pogivenzk,pogivenk)
    #Validation:
    rhs=pozgivenk*n+(1-pogivenzpk)*(1-pzgivenk)*s
    lhs=sn
    print ("Verification",lhs,rhs)
    return (n,s,sn)


# In[186]:


df


# In[91]:


#print ("Scores for k=old, z=sex",get_scores_regression(df,'housing',1,0,['sex'],['0'],['age'],'credit'))


# In[94]:


print ("Scores for k=old, z=sex",get_scores_regression(df,'status',3,0,['age','sex'],['0','0'],['age'],'credit'))


# In[ ]:





# In[84]:


print ("Scores for k=old, z=sex",get_scores_regression(df,'sex',1,0,['age'],['1'],[],'credit'))

print ("Scores for k=old, z=sex",get_scores_regression(df,'sex',1,0,['age'],['0'],[],'credit'))


# In[146]:





# In[11]:


print ("Scores for k=old, z=sex",get_scores(new_df,'sex',1,0,[('age',1)],[],'credit'))
print ("Scores for k=young,z=sex",get_scores(new_df,'sex',1,0,[('age',0)],[],'credit'))


# In[12]:


#IMPORTANT
print ("Scores for k=male, z=status",get_scores(new_df,'status',1,0,[('sex',1)],['age'],'credit'))
print ("Scores for k=female,z=status",get_scores(new_df,'status',1,0,[('sex',0)],['age'],'credit'))


# In[13]:


print ("Scores for k=male, z=savings",get_scores(new_df,'savings',1,0,[('sex',1)],['age'],'credit'))
print ("Scores for k=female,z=savings",get_scores(new_df,'savings',1,0,[('sex',0)],['age'],'credit'))


# In[14]:


#Small change in savings does not help young
#Large change in saving helps
print ("Scores for k=old, z=saving",get_scores(new_df,'savings',1,0,[('age',1)],['sex'],'credit'))
print ("Scores for k=young,z=saving",get_scores(new_df,'savings',1,0,[('age',0)],['sex'],'credit'))


print ("Scores for k=old, z=saving",get_scores(new_df,'savings',2,0,[('age',1)],['sex'],'credit'))
print ("Scores for k=young,z=saving",get_scores(new_df,'savings',2,0,[('age',0)],['sex'],'credit'))


# In[57]:


#Going from 2 to 3 is not helping as much as going from 0-2

print("Scores for k=old,z=saving",get_scores(new_df,'savings',3,2,[('age',1)],['sex'],'credit'))
print("Scores for,k=young,z=saving",get_scores(new_df,'savings',3,2,[('age',0)],['sex'],'credit'))


# In[ ]:





# In[69]:


from dowhy import CausalModel
import dowhy.datasets

graph="""graph[directed 1 node[id "S" label "S"]  
                    node[id "T" label "T"]  
                    node[id "D" label "D"]  
                    node[id "C" label "C"]  
                    node[id "Y" label "Y"]   
                    edge[source "S" target "T"]
                    edge[source "S" target "D"]
                    edge[source "C" target "T"]
                    edge[source "C" target "D"]
                    edge[source "C" target "Y"]
                    edge[source "T" target "Y"]
                    edge[source "D" target "Y"]]"""

# Create a causal model from the data and given graph.
model = CausalModel(
    data=dataset_df,
    treatment="D",
    outcome="Y",
    graph=graph)#data["gml_graph"])
model.view_model()
backdoor={'T':['S','C'],'D':['S','C']}


# In[ ]:





# In[ ]:


#Old Code not needed anymore


# In[ ]:


def get_scores_ignorability(df,z_attr,z,zprime,klst,target):
    sample=df
    for (k,kval) in klst:
        sample=sample[df[k]==kval]
    option=2
    yswap=True
    if option==1:
        
        sample=sample.loc[(sample[z_attr]==z) | (sample[z_attr]==zprime)]#=z | sample[z_attr]==zprime]   
 
        #sample=sample[df[z_attr]==z or df[z_attr]==zprime]
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z_attr].value_counts().sort_index())) #z|k
        print (zz_count)
        #zzp_count=(list(sample[zprime].value_counts().sort_index())) #z|k
        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_z=sample[sample[z_attr]==z]#|z,k
        sample_zp=sample[sample[z_attr]==zprime] #|z',k
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
    
        pzgivenk = zz_count[1]*1.0/(zz_count[1]+zz_count[0])
        pzpgivenk = zz_count[0]*1.0/(zz_count[1]+zz_count[0])
        pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
        pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
   
    else:
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z_attr].value_counts().sort_index())) #z|k
        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_zp=sample[sample[z_attr]==zprime] #|z',k
        sample_z=sample[sample[z_attr]!=zprime] #|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
        
        pzpgivenk = zz_count[zprime]*1.0/(sum(zz_count))#[zprime]+zzp_count[1])
        pzgivenk=1-pzpgivenk
        
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
        pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
   
    


    
    
    
     
    pogivenk=s_count[1]*1.0/(s_count[0]+s_count[1]) ##P[o|k]
    
    if yswap:
        pogivenZk=1-pogivenZk
        pogivenZPk=1-pogivenZPk
        pogivenk=1-pogivenk
    pozgivenk= pogivenZk*pzgivenk
    pozpgivenk = pogivenZPk * pzpgivenk
   
    popzpgivenk=(1-pogivenZPk)*(pzpgivenk)
    sn=pogivenZk - pogivenZPk
    n= (pogivenk-pogivenZPk)*1.0/(pozgivenk)#Needs to be checked
    s= (pogivenZk-pogivenk)*1.0/(popzpgivenk)
    
    #Validation:
    rhs=pozgivenk*n+(1-pogivenZPk)*(1-pzgivenk)*s
    lhs=sn
    print (lhs,rhs)
    return (n,s,sn)
    


# In[ ]:


get_scores_ignorability(new_df,'status',2,0,[('purpose',3),('age',0)],'credit')
get_scores_ignorability(new_df,'status',2,0,[('purpose',3),('age',1)],'credit')
get_scores_ignorability(new_df,'status',2,0,[('purpose',3)],'credit')
get_scores_ignorability(new_df,'sex',1,0,[('age',1)],'credit')
get_scores_ignorability(new_df,'sex',1,0,[('age',0)],'credit')


# In[386]:



def get_scores_ignorability(df,z,zprime,k,kval,target):
    sample=df[df[k]==kval]
    option=2
    yswap=True
    if option==1:
        sample=sample[df[z]+df[zprime]==1]
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z].value_counts().sort_index())) #z|k
        zzp_count=(list(sample[zprime].value_counts().sort_index())) #z|k

        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_z=sample[sample[z]==1.0]#|z,k
        sample_zp=sample[sample[zprime]==1.0] #|z',k
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
    
        pzgivenk = zz_count[1]*1.0/(zz_count[0]+zz_count[1])
        pzpgivenk = zzp_count[1]*1.0/(zzp_count[0]+zzp_count[1])

    else:
        s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
        zz_count=(list(sample[z].value_counts().sort_index())) #z|k
        zzp_count=(list(sample[zprime].value_counts().sort_index())) #z|k
        #print (sample[z].value_counts().sort_index(),sample[zprime].value_counts().sort_index())
        sample_z=sample[sample[zprime]==0.0]#|z,k
        sample_zp=sample[sample[zprime]==1.0] #|z',k
        z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
        zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
    
        pzpgivenk = zzp_count[1]*1.0/(zzp_count[0]+zzp_count[1])
        pzgivenk=1-pzpgivenk
    


    
    
    
    pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
    pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
     
    pogivenk=s_count[1]*1.0/(s_count[0]+s_count[1]) ##P[o|k]
    
    if yswap:
        pogivenZk=1-pogivenZk
        pogivenZPk=1-pogivenZPk
        pogivenk=1-pogivenk
    pozgivenk= pogivenZk*pzgivenk
    pozpgivenk = pogivenZPk * pzpgivenk
   
    popzpgivenk=(1-pogivenZPk)*(pzpgivenk)
    sn=pogivenZk - pogivenZPk
    n= (pogivenk-pogivenZPk)*1.0/(pozgivenk)#Needs to be checked
    s= (pogivenZk-pogivenk)*1.0/(popzpgivenk)
    
    #Validation:
    rhs=pozgivenk*n+(1-pogivenZPk)*(1-pzgivenk)*s
    lhs=sn
    print (lhs,rhs)
    return (n,s,sn)
    


# In[387]:


get_scores_ignorability(orig_df,'status=A13','status=A11','purpose=A42',1.0,'credit')


# In[361]:


def get_scores_ignorability_single(df,z,k,kval,target):

    yswap=True
    sample=df[df[k]==kval]

    s_count=(list(sample[target].value_counts().sort_index())) #Gives P[o|k]
    zz_count=(list(sample[z].value_counts().sort_index())) #z|k
    sample_z=sample[sample[z]==1.0]#|z,k
    sample_zp=sample[sample[z]==0.0] #|z',k
 
    z_count= (list(sample_z[target].value_counts().sort_index())) ##o|z,k
    zp_count= (list(sample_zp[target].value_counts().sort_index()))#o|z',k
   
    #print (z_count,sample_z[target].value_counts())
    pzgivenk = zz_count[1]*1.0/(zz_count[0]+zz_count[1])
    pogivenZk = z_count[1]*1.0/(z_count[1]+z_count[0])#P[o|z,k]
    pogivenZPk= zp_count[1]*1.0/(zp_count[0]+ zp_count[1])#P[o|z',k]
     
    pogivenk=s_count[1]*1.0/(s_count[0]+s_count[1]) ##P[o|k]
    
    if yswap:
        pogivenZk=1-pogivenZk
        pogivenZPk=1-pogivenZPk
        pogivenk=1-pogivenk
    pozgivenk= pogivenZk*pzgivenk
    pozpgivenk = pogivenk-pozgivenk
    popzpgivenk=(1-pogivenZPk)*(1-pzgivenk)
    sn=pogivenZk - pogivenZPk
    n= (pogivenk-pogivenZPk)*1.0/(pozgivenk)#Needs to be checked
    s= (pogivenZk-pogivenk)*1.0/(popzpgivenk)
    
    
    
    #Validation:
    rhs=pozgivenk*n+(1-pogivenZPk)*(1-pzgivenk)*s
    lhs=sn
    print (lhs,rhs)
    return (n,s,sn)
    


# In[ ]:





# In[362]:


get_scores_ignorability_single(dataset_df,'sex','age',1.0,'credit')


# In[246]:


get_scores_ignorability_single(dataset_df,'sex','age',0.0,'credit')


# In[120]:


#Causal Graph for German dataset
# A,G->E
#A,G,E->I
#I->S
#A,G->L
#A,L,G->D
dataset_df[['age','sex','purpose=A46']]


# In[55]:


def get_scores_ignorability(df,v_attr,vprime,k,kthres,target):
    sample=df[df[k]==kthres]
    
    s_count=(list(sample[target].value_counts()))
    sample_v=sample[sample[v_attr]==1.0]
    sample_vp=sample[sample[vprime]==1.0]
    sample_count= (list(sample_v[target].value_counts()))
    samplevp_count= (list(sample_vp[target].value_counts()))
    
    po1v = sample_count[1]*1.0/(sample_count[1]+sample_count[0])
    po0vp= samplevp_count[1]*1.0/(samplevp_count[0]+ samplevp_count[1])
    
    ps=s_count[1]*1.0/(s_count[0]+s_count[1])
    
    
    sn=po1v - po0vp
    n= (ps-po0vp)*1.0/(po1v)#Needs to be checked
    s= (po1v-ps)*1.0/(1-po0vp)
    return (n,s,sn)
    


# In[58]:


def get_scores_ignorability_single(df,v_attr,k,kthres,target):
    if 'no' in k:
        sample=df
    else:
        sample=df[df[k]==kthres]
    
    s_count=(list(sample[target].value_counts()))
    sample_v=sample[sample[v_attr]==0.0]
    sample_vp=sample[sample[v_attr]==1.0]
    sample_count= (list(sample_v[target].value_counts()))
    samplevp_count= (list(sample_vp[target].value_counts()))
    
    po1v = sample_count[1]*1.0/(sample_count[1]+sample_count[0])
    po0vp= samplevp_count[1]*1.0/(samplevp_count[0]+ samplevp_count[1])
    
    ps=s_count[1]*1.0/(s_count[0]+s_count[1])
    
    
    sn=po1v - po0vp
    n= (ps-po0vp)*1.0/(po1v)#Needs to be checked
    s= (po1v-ps)*1.0/(1-po0vp)
    return (n,s,sn)
    


# In[59]:


get_scores_ignorability(dataset_df,'status=A11','status=A13','purpose=A42',1.0,'credit')


# In[60]:


get_scores_ignorability(dataset_df,'status=A11','status=A14','purpose=A42',1.0,'credit')


# In[61]:


get_scores_ignorability(dataset_df,'status=A12','status=A14','purpose=A42',1.0,'credit')


# In[62]:


get_scores_ignorability(dataset_df,'status=A12','status=A13','purpose=A42',1.0,'credit')


# In[63]:


get_scores_ignorability(dataset_df,'status=A11','status=A12','purpose=A42',1.0,'credit')


# In[64]:


get_scores_ignorability_single(dataset_df,'sex','purpose=A41',1.0,'credit')


# In[65]:


get_scores_ignorability_single(dataset_df,'sex','purpose=A42',1.0,'credit')


# In[56]:


get_scores_ignorability_single(dataset_df,'sex','no',1.0,'credit')


# In[59]:


get_scores_ignorability_single(dataset_df,'sex','property=A121',1.0,'credit')


# In[60]:


get_scores_ignorability_single(dataset_df,'sex','age',1.0,'credit')


# In[61]:


get_scores_ignorability_single(dataset_df,'sex','age',0.0,'credit')


# In[ ]:


#Age and gender


# In[10]:


#Causal Graph for German dataset
# A,G->E
#A,G,E->I
#I->S
#A,G->L
#A,L,G->D
graph="""graph[directed 1 node[id "A" label "A"]  
                    node[id "G" label "G"]  
                    node[id "E" label "E"]  
                    node[id "I" label "I"]  
                    node[id "S" label "S"]  
                    node[id "L" label "L"]  
                    node[id "D" label "D"]  
                    edge[source "A" target "E"]
                    edge[source "G" target "E"]
                    edge[source "A" target "I"]
                    edge[source "G" target "I"]
                    edge[source "E" target "I"]
                    edge[source "I" target "S"]
                    edge[source "A" target "L"]
                    edge[source "G" target "L"]
                    edge[source "A" target "D"]
                    edge[source "L" target "D"]
                    edge[source "G" target "D"]
                    edge[source "E" target "S"]]"""


graph="""graph[directed 1 node[id "A" label "A"]  
                    node[id "G" label "G"]  
                    node[id "E" label "E"]  
                    node[id "I" label "I"]  
                    node[id "S" label "S"]  
                    node[id "L" label "L"]  
                    node[id "D" label "D"]  
                    edge[source "A" target "E"]
                    edge[source "A" target "I"]
                    edge[source "I" target "S"]
                    edge[source "E" target "S"]]"""


# In[11]:


from dowhy import CausalModel
import dowhy.datasets

# Create a causal model from the data and given graph.
model = CausalModel(
    data=dataset_df,
    treatment="E",
    outcome="S",
    graph=graph)#data["gml_graph"])

# Identify causal effect and return target estimands
identified_estimand = model.identify_effect()
print(identified_estimand)


# In[12]:


model.view_model()


# In[13]:


data = dowhy.datasets.linear_dataset(
    beta=10,
    num_common_causes=5,
    num_instruments=2,
    num_samples=10000,
    treatment_is_binary=True)


# In[14]:


print(data["treatment_name"])


# In[15]:


model = CausalModel(
    data=data["df"],
    treatment=data["treatment_name"],
    outcome=data["outcome_name"],
    graph=data["gml_graph"])

# Identify causal effect and return target estimands
identified_estimand = model.identify_effect()


# In[16]:


print(identified_estimand)


# In[ ]:


#Causal Graph for German dataset
# A,G->E
#A,G,E->I
#I->S
#A,G->L
#A,L,G->D


# In[ ]:


#Todo:
#Apply regression on each edge
# For a given intervention calculate the scores


# In[ ]:


#Compare with shapley value and other options!


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[36]:


sample_v=sample[sample['status=A13']==1.0]
sample_vp=sample[sample['status=A13']==0.0]


# In[21]:


print (sample_v.credit.hist())


# In[80]:


print (sample_vp.credit.hist())


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[52]:


train_df=get_data(1000)
test_df=get_data(1000)
val_df=get_data(1000)
train_df_selection=train_df[train_df.X2<0.5]
val_df_selection=train_df[val_df.X2<0.5]
privileged_groups = [{'S': 1}]
unprivileged_groups = [{'S': 0}]
bld_te = BinaryLabelDataset(df=test_df, label_names=['Y'],protected_attribute_names=['S'])


# In[53]:


#print (train_df_selection.Y.value_counts())
considered_feat=['X1','X2']


# In[54]:


def train_and_print_metric(df,considered_feat,target,test_df,test_bld,unprivileged_groups,privileged_groups):
    df_considered=df[considered_feat]
    test_df_considered=test_df[considered_feat]
    model = LogisticRegression(random_state=10).fit(df_considered, target)
    y_pred=model.predict(test_df_considered)

    dataset_pred = test_bld.copy()
    dataset_pred.labels=y_pred
    metric_selection = ClassificationMetric(
                bld_te, dataset_pred,
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups)

    print ("Results")
    print("Odds difference",metric_selection.average_odds_difference())
    print("Disparate impact",metric_selection.disparate_impact())
    print(metric_selection.statistical_parity_difference())
    print(metric_selection.equal_opportunity_difference())
    print(metric_selection.theil_index())
    print ("Accuracy",metric_selection.accuracy())


# In[55]:


print ("Results on complete dataset")
train_and_print_metric(train_df,considered_feat,train_df['Y'],test_df,bld_te,unprivileged_groups,privileged_groups)


# In[56]:


print ("Results on biased dataset, selection variable is X2")
train_and_print_metric(train_df_selection,considered_feat,train_df_selection['Y'],test_df,bld_te,unprivileged_groups,privileged_groups)


# In[57]:


print ("Trying reweighting on the biased dataset")
RW = Reweighing(unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups)

bld_trs = BinaryLabelDataset(df=train_df_selection, label_names=['Y'],protected_attribute_names=['S'])
bld_te = BinaryLabelDataset(df=test_df, label_names=['Y'],protected_attribute_names=['S'])

dataset_transf_train = RW.fit_transform(bld_trs)

model = LogisticRegression(random_state=10).fit(dataset_transf_train.features, dataset_transf_train.labels.ravel())
test_df_new=test_df.drop(columns=['Y'])
y_pred=model.predict(test_df_new)

dataset_pred = bld_te.copy()
dataset_pred.labels=y_pred
metric_selection = ClassificationMetric(
                bld_te, dataset_pred,
                unprivileged_groups=unprivileged_groups,
                privileged_groups=privileged_groups)

print ("Reweighting Results")
print("Odds difference",metric_selection.average_odds_difference())
print("Disparate impact",metric_selection.disparate_impact())
print(metric_selection.statistical_parity_difference())
print(metric_selection.equal_opportunity_difference())
print(metric_selection.theil_index())
print ("Accuracy",metric_selection.accuracy())


# In[58]:


from aif360.algorithms.postprocessing import EqOddsPostprocessing


df_considered=train_df_selection[considered_feat]

val_df_considered=val_df_selection[considered_feat]
test_df_considered=test_df[considered_feat]
bld_val = BinaryLabelDataset(df=val_df_selection, label_names=['Y'],protected_attribute_names=['S'])


model = LogisticRegression(random_state=10).fit(df_considered, train_df_selection['Y'])
val_pred_label=model.predict(val_df_considered)
y_pred=model.predict(test_df_considered)

val_pred = bld_val.copy()
val_pred.labels=val_pred_label
bld_ten=BinaryLabelDataset(df=test_df,label_names=['Y'],protected_attribute_names=['S'])

dataset_pred = bld_ten.copy()
dataset_pred.labels=y_pred.reshape((-1, 1))

eqo = EqOddsPostprocessing(unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups, seed=1234567)

pred_eqo = eqo.fit(bld_val, val_pred).predict(dataset_pred)

cm_eqo = ClassificationMetric(bld_te, pred_eqo,
            unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups)
    
print ("Post processing Equalized odds postprocessing")
print("Odds difference",cm_eqo.average_odds_difference())
print("Disparate impact",cm_eqo.disparate_impact())
print(cm_eqo.statistical_parity_difference())
print(cm_eqo.equal_opportunity_difference())
print(cm_eqo.theil_index())
print ("Accuracy",cm_eqo.accuracy())


# In[59]:


from aif360.algorithms.postprocessing import CalibratedEqOddsPostprocessing


df_considered=train_df_selection[considered_feat]

val_df_considered=val_df_selection[considered_feat]
test_df_considered=test_df[considered_feat]

bld_val = BinaryLabelDataset(df=val_df_selection, label_names=['Y'],protected_attribute_names=['S'])


model = LogisticRegression(random_state=10).fit(df_considered, train_df_selection['Y'])
val_pred_label=model.predict(val_df_considered)
val_pred_scores=model.predict_proba(val_df_considered)

y_pred=model.predict(test_df_considered)

val_pred = bld_val.copy()

val_pred.labels=val_pred_label
val_pred.scores=val_pred_scores[:, 1]

bld_ten=BinaryLabelDataset(df=test_df,label_names=['Y'],protected_attribute_names=['S'])

dataset_pred = bld_ten.copy()
dataset_pred.labels=y_pred.reshape((-1, 1))

dataset_pred.scores=model.predict_proba(test_df_considered)[:,1]


eqo = CalibratedEqOddsPostprocessing(unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups, seed=1234567,cost_constraint='fpr')

pred_eqo = eqo.fit(bld_val, val_pred).predict(dataset_pred)



cm_eqo = ClassificationMetric(bld_ten, pred_eqo,
            unprivileged_groups=unprivileged_groups,
                               privileged_groups=privileged_groups)
    
print ("Post processing Equalized odds postprocessing")
print("Odds difference",cm_eqo.average_odds_difference())
print("Disparate impact",cm_eqo.disparate_impact())
print(cm_eqo.statistical_parity_difference())
print(cm_eqo.equal_opportunity_difference())
print(cm_eqo.theil_index())
print ("Accuracy",cm_eqo.accuracy())


# In[ ]:





# In[62]:


train_df.to_csv('train.csv',index=False)
test_df.to_csv('test.csv',index=False)
train_df_selection.to_csv('train_selection.csv',index=False)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




