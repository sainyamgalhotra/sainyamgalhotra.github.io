#!/usr/bin/env python
# coding: utf-8

# # Install packages

# In[230]:


import numpy as np
import pandas as pd
from collections import namedtuple, Counter

import copy
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


# In[248]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

df=pd.read_csv('../../german.csv')
l=[]
for v in df['credit'].values:
    if v==2.0:
        l.append(0)
    else:
        l.append(1)
df['credit']=l
df


featlst=list(df.columns)
featlst.remove('credit')
for feat in featlst:
    highest=max(df[feat])
    lowest=min(df[feat])
    #if len(list(set(df[feat])))>4:
    #    print (feat,len(list(set(df[feat]))))
    l=df[feat]
    if feat=='month':
        processed=[]
        for v in l:
            if v<=10:
                processed.append(0)
            elif v<15:
                processed.append(1)
            elif v<25:
                processed.append(2)
            else:
                processed.append(3)
        df[feat]=processed
    if feat=='housing':
        print (feat)
        processed=[]
        for v in l:
            if v==1:
                processed.append(1)
            else:
                processed.append(0)
        df[feat]=processed 
    if feat=='installment_plans' or feat=='number_of_credits':
        print (feat)
        processed=[]
        for v in l:
            if v<=1:
                processed.append(0)
            else:
                processed.append(1)
        df[feat]=processed
    if feat=='employment' or feat=='credit_history' or feat=='skill_level':
        print (feat)
        processed=[]
        for v in l:
            if v<=1:
                processed.append(0)
            else:
                processed.append(v)
        df[feat]=processed
        
    if feat=='credit_amount':
        processed=[]
        for v in l:
            if v<=1500:
                processed.append(0)
            elif v<3000:
                processed.append(1)
            elif v<5500:
                processed.append(2)
            else:
                processed.append(3)
        df[feat]=processed
    if feat=='purpose':
        l=[]
        for v in df['purpose']:
            if v>4:
                l.append(5)
            elif v<=2:
                l.append(2)
            else:
                l.append(v)
        df[feat]=l
    if feat=='other_debtors':
        processed=[]
        for v in l:
            if v<=0:
                processed.append(0)
            else:
                processed.append(1)
        df[feat]=processed
    if feat=='savings':
        processed=[]
        for v in l:
            if v<=0:
                processed.append(0)
            elif v<=3:
                processed.append(1)
            else:
                processed.append(2)
        df[feat]=processed
    #    #pd.cut(l)
    #    range_lst=pd.cut(l,4,labels=[0,1,2,3])
    #    df[feat]=(pd.cut(l,4,labels=[0,1,2,3]))


y=df['credit']

X_train, X_test, y_train, y_test = train_test_split(df, y, test_size=0.5, random_state=1)

feat=list(df.columns)
feat.remove('credit')

#clf = RandomForestRegressor(max_depth=10, random_state=0)
clf = RandomForestClassifier(max_depth=10, random_state=0)

clf.fit(X_train[feat], y_train)

pred= (clf.predict(X_test[feat]))
pred = [int(round(value)) for value in pred]

print(classification_report(y_test, pred))

print (clf.feature_importances_,feat)


# In[249]:


xgboost=False

if xgboost:
    import xgboost
    import shap

    from sklearn.ensemble import RandomForestClassifier
    from sklearn.ensemble import RandomForestRegressor

    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report

    df=pd.read_csv('german.csv')
    l=[]
    for v in df['credit'].values:
        if v==2.0:
            l.append(0)
        else:
            l.append(1)
    df['credit']=l
    df
    y=df['credit']

    X_train, X_test, y_train, y_test = train_test_split(df, y, test_size=0.2, random_state=1)


    # load JS visualization code to notebook
    shap.initjs()

    # train XGBoost model

    import pandas as pd

    feat=list(df.columns)
    feat.remove('credit')
    model = xgboost.train({"learning_rate": 0.01}, xgboost.DMatrix(X_train[feat], label=y_train), 50)

    pred=model.predict(xgboost.DMatrix(X_test[feat]))
    pred = [int(round(value)) for value in pred]

    print(classification_report(y_test, pred))

    #X_test['credit']=clf.predict(X_test)

X_test['credit']  = pred
df=X_test


# In[ ]:


import datasethelper
df=datasethelper.process_german()

# In[ ]:





# In[250]:



featlst=list(df.columns)
featlst.remove('credit')


# In[251]:


df


# In[252]:




df.to_csv('german_test.csv',index=False)


# In[253]:


debug=False
def get_combination(lst,tuplelst):
    i=0
    new_tuplelst=[]
    if len(tuplelst)==0:
        l=lst[0]
        for v in l:
            new_tuplelst.append([v])
        if len(lst)>1:
            return get_combination(lst[1:],new_tuplelst)
        else:
            return new_tuplelst
    

    currlst=lst[0]
    for l in tuplelst:
        
        for v in currlst:
            newl=copy.deepcopy(l)
            newl.append(v)
            new_tuplelst.append(newl)
        
    if len(lst)>1:
        return get_combination(lst[1:],new_tuplelst)
    else:
        return new_tuplelst
      
def get_C_set(df,C):
    lst=[]
    for Cvar in C:
        lst.append(list(set(list(df[Cvar]))))
        
    combination_lst= (get_combination(lst,[]))
    
    return combination_lst

def get_scores_regression(df,z_attr,z,zprime,klst,kvallst,C,target):
    
    sample=df
    if debug:
        print ("Given k number of data points",sample.shape)
      
    if len(C)>0:
        Clst=get_C_set(df,C)
    else:
        Clst=['']
    
    
    snum=0
    nnum=0
    snnum=0

    for cval in Clst:
        #print("cval is ",cval,C)
        if Clst[0]=='':
            Clst=[]
            
        
        
        conditional_lst=copy.deepcopy(klst)
        conditional_lst.extend(C)
        conditional_lst.extend(z_attr)
        
        conditional_val=copy.deepcopy(kvallst)
        conditional_val.extend(cval)
        
        conditional_valzp=copy.deepcopy(conditional_val)
        conditional_val.extend(z)
        conditional_valzp.extend(zprime)
        
        
        
        #print (conditional_lst,conditional_val)
        pogivenczk=get_prob_o_regression(df,conditional_lst,conditional_val,[target],[1])
        
        pogivenczpk=get_prob_o_regression(df,conditional_lst,conditional_valzp,[target],[1])
        
        
        if len(C)>0:
            #if (len(klst)>0):
            pck=get_prob_o_regression(df,klst,kvallst,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
            #else:
            #    pck=
            
            conditional=copy.deepcopy(klst)
            conditional_val=copy.deepcopy(kvallst)
            conditional.extend(z_attr)
            conditional_val.extend(z)
            #print (cval,C)
            pcgivenzk=get_prob_o_regression(df,conditional,conditional_val,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
            
            conditional_val=copy.deepcopy(kvallst)
            conditional_val.extend(zprime)
            pcgivenzpk=get_prob_o_regression(df,conditional,conditional_val,C,cval)#get_prob_c(sample,cval,C)#get_prob_o_regression(df,conditional_lst,conditional_valzp,C,cval)#Change
        else:
            pck=1
            pcgivenzpk=1
            pcgivenzk=1
        #
        if debug:
            print ("P[o|czk]",pogivenczk)
            print ("P[o|cz'k]",pogivenczpk,pck)
        popgivenczpk=1-pogivenczpk
        snum+=pogivenczk*pcgivenzpk ##P[o|do(z),k]
        nnum+=popgivenczpk*pcgivenzk ##P[o|do(z'),k]
        snnum+=(pogivenczk-pogivenczpk)*pck ##P[o|do(z),k]-P[o|do(z'),k]
        #print(snnum,pogivenczk,pogivenczpk)
        
        
        
        if debug:
            print ("numerators",snum,nnum,snnum)
    
    if len(klst)>0:
        pogivenk=get_prob_o_regression(df,klst,kvallst,[target],[1])
    else:
        pogivenk=df[df[target]==1].shape[0]*1.0/df.shape[0]
    #print (pogivenk)
    #sample_target=get_count(sample[target])
    #pogivenk=sample_target[1]*1.0/(sample_target[1]+sample_target[2])
    
    #sample_target_z=get_count(sample_z[target])
    #pogivenzk=sample_target_z[1]*1.0/(sample_target_z[1]+sample_target_z[2])
    conditional=copy.deepcopy(klst)
    conditional.extend(z_attr)
    conditional_val=copy.deepcopy(kvallst)
    conditional_val.extend(z)
    pogivenzk=get_prob_o_regression(df,conditional,conditional_val,[target],[1])
    
    
    conditional_valzp=copy.deepcopy(kvallst)
    conditional_valzp.extend(zprime)
    #sample_target_zp=get_count(sample_zp[target])
    pogivenzpk=get_prob_o_regression(df,conditional,conditional_valzp,[target],[1])
    #sample_target_zp[2]*1.0/(sample_target_zp[1]+sample_target_zp[2])
    popgivenzpk=1-pogivenzpk
    
    #sample_z=sample[sample[z_attr]==z]#|z,k
    #sample_zp=sample[sample[z_attr]==zprime] #|z',k
    
    #pzgivenk=get_prob_o_regression(df,klst,kvallst,z_attr,z)#
    #sample_z.shape[0]*1.0/(sample_z.shape[0]+sample_zp.shape[0])
    #pzpgivenk=get_prob_o_regression(df,klst,kvallst,z_attr,zprime)#
    #pozgivenk = pogivenzk*pzgivenk
    popgivenzk=1-pogivenzk
    #popzpgivenk=popgivenzpk*pzpgivenk
    #pozpgivenk=pogivenzpk*pzpgivenk
    #popzgivenk=popgivenzk*pzgivenk
    #print (pogivenk,popzpgivenk,pozgivenk,"these")
    
    sn=(snnum)
    s=((snum-pogivenzpk)*1.0/popgivenzpk)
    n=((-popgivenzk+nnum)*1.0/pogivenzk)
    
    ##Lower bound calculation below
    '''
    nlb=(pozgivenk+pozpgivenk-pogivenzpk)*1.0/pozgivenk
    slb=(popzgivenk+popzpgivenk-popgivenzk)*1.0/popzpgivenk

    #newlb=(popgivenzpk-popzpgivenk-popzgivenk - popgivenzpk*(1-pzgivenk-pzpgivenk))*1.0/pozgivenk
    newlb=(-popgivenzk + popgivenzpk)*1.0/pogivenzk
    '''
    
    #sn=max(0,snnum)
    #s= max(0,(snum-pogivenk)*1.0/popzpgivenk)
    #n= max(0,(pogivenk-nnum)*1.0/pozgivenk)
    #print (pogivenzk,pogivenk)
    #Validation:
    #rhs=pozgivenk*n+(1-pogivenzpk)*(1-pzgivenk)*s
    #lhs=1#sn
    #print ("Verification",lhs,rhs)
    
    #print (pzgivenk+pzpgivenk)
    return (n,s,sn)#,nlb,slb,newlb)#,sn_ub,n_ub,s_ub)


# In[254]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import make_regression

def get_val(row,target,target_val):
    i=0
    while i<len(target):
        #print (row[target[i]],target_val[i])
        if not int(row[target[i]])==int(target_val[i]):
            return 0
        i+=1
    return 1

def get_prob_o_regression(df,conditional,conditional_values,target,target_val):
    #print (target_val,df.size)
    new_lst=[]
    count=0
    for index,row in df.iterrows():
        new_lst.append(get_val(row,target,target_val))
        if new_lst[-1]==1:
            count+=1
    
    if len(conditional)==0:
        return count*1.0/df.shape[0]
    #pcgivenk=df[df[target]==1].shape[0]*1.0/df.shape[0]
    if len(list(set(new_lst)))==1:
        if new_lst[0]==1:
            return 1
        else:
            return 0
    if len(conditional)>0:
        X=df[conditional]
    else:
        X=df
    #print (len(X),conditional,conditional_values)
    #regr = LogisticRegression(random_state=0)
    regr = RandomForestRegressor(max_depth=10,random_state=1)#LogisticRegression(random_state=0)
    regr.fit(X, new_lst)
    #print (regr.coef_.tolist())
    #print (regr.predict_proba([conditional_values]),"ASDFDS")
    #return(regr.predict_proba([conditional_values])[0][1])
    return (regr.predict([conditional_values])[0])

    



def get_majority(dic1,s1,s2,feat):
    score=[0,0,0]
    if feat in dic1.keys():
        score=dic1[feat]
        
    i=0
    while i<3:
        score[i]=max(score[i],s1[i])
        score[i]=max(score[i],s2[i])
        i+=1
    dic1[feat]=score
    return dic1

score_dic={}
for feat in featlst:
    print (feat)
    uniqval=list(set(list(df[feat])))
    if feat=='age' or feat=='sex':
        i=0
        while i<len(uniqval):
            j=i+1
            while j<len(uniqval):
                score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],[],'credit')
                score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],[],'credit')
                score_dic=get_majority(score_dic,score1,score2,feat)
                j+=1
            i+=1
    else:
        i=0
        while i<len(uniqval):
            j=i+1
            while j<len(uniqval):
                score1=get_scores_regression(df,[feat],[uniqval[i]],[uniqval[j]],[],[],['age','sex'],'credit')
                score2=get_scores_regression(df,[feat],[uniqval[j]],[uniqval[i]],[],[],['age','sex'],'credit')
                score_dic=get_majority(score_dic,score1,score2,feat)
                j+=1
            i+=1
    print (score_dic)
    sfdjlk
    
print (score_dic)


# In[256]:


df['purpose'].corr(df['credit'])


# In[257]:


df['age'].corr(df['credit'])


# In[258]:


df['status'].corr(df['credit'])


# In[ ]:


n_score={}
s_score={}
sn_score={}
for feat in score_dic.keys():
    n_score[feat]=score_dic[feat][0]
    s_score[feat]=score_dic[feat][1]
    sn_score[feat]=score_dic[feat][2]
    print (feat,n_score[feat],s_score[feat],sn_score[feat])

# In[269]:


sorted_s = sorted(n_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_n = sorted(s_score.items(), key=lambda kv: kv[1],reverse=True)
sorted_sn = sorted(sn_score.items(), key=lambda kv: kv[1],reverse=True)

slst=[]
nlst=[]
snlst=[]
svallst=[]
nvallst=[]
snvallst=[]

i=0
for (x,y) in sorted_s:
    slst.append(x)
    svallst.append(y)
    nlst.append(sorted_n[i][0])
    nvallst.append(sorted_n[i][1])
    snlst.append(sorted_sn[i][0])
    snvallst.append(sorted_sn[i][1])
    i+=1

print (snvallst)
print (snlst)
# In[ ]:

print (nlst)
print (nvallst)


print (slst)
print(svallst)

# In[ ]:

