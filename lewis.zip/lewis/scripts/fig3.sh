python german.py randomforest
mv newplots/german_globalExplanationsrandomforest.pdf newplots/3a.pdf

python adult.py randomforest
mv newplots/adult_globalExplanationsrandomforest.pdf newplots/3b.pdf

python compas.py randomforest
mv newplots/compas_globalExplanations_score_text.pdf newplots/3c.pdf

python drug.py randomforest
mv newplots/drug_globalExplanationsrandomforest.pdf newplots/3d.pdf
mv newplots/drugs_global_related_mushrooms.pdf newplots/7d.pdf
