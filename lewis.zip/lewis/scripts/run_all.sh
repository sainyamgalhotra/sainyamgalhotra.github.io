bash fig3.sh  
bash fig4.sh  
bash fig5.sh  
bash fig6.sh  
bash fig7.sh  
bash fig8.sh  
bash fig9.sh
mv newplots/*.pdf ../freshruns/
