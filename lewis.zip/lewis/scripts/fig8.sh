python fig5,10ab.py
mv newplots/german_local_negative_related.pdf newplots/8a.pdf
mv newplots/german_local_positive_related.pdf newplots/8b.pdf

python fig6,10cd.py
mv newplots/adult_local_negative_related.pdf newplots/8c.pdf
mv newplots/adult_local_positive_related.pdf newplots/8d.pdf
