

python adultxgboost.py xgboost
mv newplots/adult_global_related_xgboost.pdf newplots/6a.pdf


python adultneural.py neural
mv newplots/adult_global_related_neural.pdf newplots/6b.pdf
