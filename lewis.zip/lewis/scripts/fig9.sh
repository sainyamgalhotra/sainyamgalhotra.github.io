python synthetic_correctness-regression-final.py
mv newplots/germansyn_SN_correctness.pdf newplots/9a.pdf

python synthetic_correctness_vary_param.py
mv newplots/germansyn_Sample.pdf newplots/9b.pdf
