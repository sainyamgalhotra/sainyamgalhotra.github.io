#!/usr/bin/env python
# coding: utf-8

# In[1]:


import datasethelper,lewishelper
import copy
import pandas as pd
import xgboost


import sys


(X_train,y_train,df,pred,clf)=datasethelper.process_german("randomforest")


df['credit']=pred

featlst=list(df.columns)
featlst.remove('credit')


# In[ ]:





# In[2]:


df['status'].value_counts()


# In[8]:


'''Separate bin for 3'''
(n0,s0,sn0)=lewishelper.get_scores_regression(df,['status'],[2],[1],['age'],[0.0],['sex'],'credit')


# In[9]:


(n1,s1,sn1)=lewishelper.get_scores_regression(df,['status'],[2],[1],['age'],[1.0],['sex'],'credit')


# In[10]:


n1


# In[11]:


names = ['Nec', 'Suf', 'NeSuf']

# status: 1,2
young = [n0,s0,sn0]#,0.50,0.145]
old = [n1,s1,sn1]#0.175,0.99,0.162]

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

import pylab as plot
fsize=15
params = {'legend.fontsize': fsize,
          'legend.handlelength': 2}
plot.rcParams.update(params)

font = {'family' : "sans serif", 'size'   : fsize}
# matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rc('font', **font)

labels = names
x = np.arange(len(labels))  # the label locations
width = 0.25  # the width of the bars

fig, ax = plt.subplots()

# sex
# rects1 = ax.bar(x - width, female, width, label='Sex=Female', color='lightcoral', edgecolor='black', hatch="/")
# rects2 = ax.bar(x, male, width, label='Sex=Male', color='silver', edgecolor='black', hatch="\\")

# age
rects1 = ax.bar(x - width, young, width, label='Age=Young', color=['lightsteelblue', 'khaki', 'lightgreen'], edgecolor='black', hatch="//")
rects2 = ax.bar(x, old, width, label='Age=Old', color=['cornflowerblue', 'goldenrod', 'green'], edgecolor='black', hatch="\\\\")

def autolabel(rects, val):
    """Attach a text label above each bar in *rects*, displaying its height."""
    i=0
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(val),
                    xy=(rect.get_x() + .1, height + .01),
                    xytext=(3, 0),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=fsize/1.2)
        i+=1


autolabel(rects1, 'Young')
autolabel(rects2, 'Old')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_title('Attribute: Status')
ax.set_ylabel('Scores', labelpad=fsize/1.1)
ax.set_xticks(x)
ax.set_xticklabels(labels)
plt.yticks(np.arange(0, 1.2, .25))

matplotlib.rcParams['hatch.linewidth'] = 0.3

figure = plt.gcf() # get current figure
figure.set_size_inches(5,5)
fig.tight_layout()
plt.savefig('newplots/german_context_age_status_1_2.pdf')


# In[12]:


(X_train,y_train,df,pred,model)=datasethelper.process_adult("randomforest")


# In[13]:


df['marital'].value_counts()


# In[18]:


df['Age'].value_counts()


# In[22]:


scores_young=lewishelper.get_scores_regression(df,['marital'],[1],[0],['Age'],[1],['country','sex'],'target')


# In[21]:


scores_old=lewishelper.get_scores_regression(df,['marital'],[1],[0],['Age'],[2],['country','sex'],'target')


# In[23]:


import matplotlib
import matplotlib.pyplot as plt
import numpy as np

import pylab as plot
fsize=15
params = {'legend.fontsize': fsize,
          'legend.handlelength': 2}
plot.rcParams.update(params)

font = {'family' : "sans serif", 'size'   : fsize}
# matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rc('font', **font)

labels = names
x = np.arange(len(labels))  # the label locations
width = 0.25  # the width of the bars

fig, ax = plt.subplots()

# sex
# rects1 = ax.bar(x - width, female, width, label='Sex=Female', color='lightcoral', edgecolor='black', hatch="/")
# rects2 = ax.bar(x, male, width, label='Sex=Male', color='silver', edgecolor='black', hatch="\\")

# age
rects1 = ax.bar(x - width, scores_young, width, label='Age=Young', color=['lightsteelblue', 'khaki', 'lightgreen'], edgecolor='black', hatch="//")
rects2 = ax.bar(x, scores_old, width, label='Age=Old', color=['cornflowerblue', 'goldenrod', 'green'], edgecolor='black', hatch="\\\\")

def autolabel(rects, val):
    """Attach a text label above each bar in *rects*, displaying its height."""
    i=0
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(val),
                    xy=(rect.get_x() + .1, height + .01),
                    xytext=(3, 0),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=fsize/1.2)
        i+=1


autolabel(rects1, 'Young  ')
autolabel(rects2, '   Old')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_title('Attribute: Marital')
ax.set_ylabel('Scores', labelpad=fsize/1.1)
ax.set_xticks(x)
ax.set_xticklabels(labels)
plt.yticks(np.arange(0, 1.25, .25))
ax.margins(0.05, 0.1)

matplotlib.rcParams['hatch.linewidth'] = 0.3

figure = plt.gcf() # get current figure
figure.set_size_inches(5,5)
fig.tight_layout()
plt.savefig('newplots/adult_context_marital_age_2.pdf')


# In[24]:


col='score_text'
(X_train,y_train,df,pred,clf)=datasethelper.process_compas(col,-1)#:"randomforest")
#df[col]=pred


# In[25]:


df['juv_fel_count'].value_counts()


# In[26]:


scores0_prior_ct=lewishelper.get_scores_regression(df,['priors_count'],[2],[0],['race'],[0],['age_cat','sex'],'score_text')


# In[27]:


scores1_prior_ct=lewishelper.get_scores_regression(df,['priors_count'],[2],[0],['race'],[1],['age_cat','sex'],'score_text')


# In[28]:


import matplotlib
import matplotlib.pyplot as plt
import numpy as np

import pylab as plot
fsize=15
params = {'legend.fontsize': fsize,
          'legend.handlelength': 2}
plot.rcParams.update(params)

font = {'family' : "sans serif", 'size'   : fsize}
# matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rc('font', **font)

labels = names

x = np.arange(len(labels))  # the label locations
# plt.figure(figsize=(6, 10)) # in inches!
fig, ax = plt.subplots()

width = 0.35  # the width of the bars
rects1 = ax.bar(x, scores1_prior_ct, width, label='White', color=['lightsteelblue', 'khaki', 'lightgreen'], edgecolor='black', hatch="//")
rects2 = ax.bar(x + width, scores0_prior_ct, width, label='Black', color=['cornflowerblue', 'goldenrod', 'green'], edgecolor='black', hatch="\\\\")

def autolabel(rects, val):
    """Attach a text label above each bar in *rects*, displaying its height."""
    i=0
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(val),
                    xy=(rect.get_x() + .1, height + .01),
                    xytext=(3, 0),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=fsize/1.1)
        i+=1


autolabel(rects1, 'White')
autolabel(rects2, '     Black')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_title('Attribute: Prior Count')
ax.set_ylabel('Scores')
ax.set_xticks(x)
ax.set_xticklabels(labels)
plt.yticks(np.arange(0, 1.2, .25))

matplotlib.rcParams['hatch.linewidth'] = 0.3

figure = plt.gcf() # get current figure
figure.set_size_inches(5,5)
fig.tight_layout()
plt.savefig('newplots/compas_context_race_priorCount.pdf')


# In[11]:


df.columns


# In[29]:


scores1_juv=lewishelper.get_scores_regression(df,['juv_fel_count'],[1],[0],['race'],[1],['age_cat','sex'],'score_text')


# In[30]:


scores0_juv=lewishelper.get_scores_regression(df,['juv_fel_count'],[1],[0],['race'],[0],['age_cat','sex'],'score_text')


# In[31]:


import matplotlib
import matplotlib.pyplot as plt
import numpy as np

import pylab as plot
fsize=15
params = {'legend.fontsize': fsize,
          'legend.handlelength': 2}
plot.rcParams.update(params)

font = {'family' : "sans serif", 'size'   : fsize}
# matplotlib.rcParams['font.family'] = "sans-serif"
matplotlib.rc('font', **font)

labels = names

x = np.arange(len(labels))  # the label locations
# plt.figure(figsize=(6, 10)) # in inches!
fig, ax = plt.subplots()

width = 0.35  # the width of the bars
rects1 = ax.bar(x, scores1_juv, width, label='White', color=['lightsteelblue', 'khaki', 'lightgreen'], edgecolor='black', hatch="//")
rects2 = ax.bar(x + width, scores0_juv, width, label='Black', color=['cornflowerblue', 'goldenrod', 'green'], edgecolor='black', hatch="\\\\")

def autolabel(rects, val):
    """Attach a text label above each bar in *rects*, displaying its height."""
    i=0
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(val),
                    xy=(rect.get_x() + .1, height + .01),
                    xytext=(3, 0),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', fontsize=fsize/1.1)
        i+=1


autolabel(rects1, 'White')
autolabel(rects2, '     Black')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_title('Attribute: Juvenile Crime')
ax.set_ylabel('Scores')
ax.set_xticks(x)
ax.set_xticklabels(labels)
plt.yticks(np.arange(0, 1.2, .25))

matplotlib.rcParams['hatch.linewidth'] = 0.3

figure = plt.gcf() # get current figure
figure.set_size_inches(5,5)
fig.tight_layout()
plt.savefig('newplots/compas_context_race_juvenile.pdf')


# In[ ]:




