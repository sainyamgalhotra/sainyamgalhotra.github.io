python fig4ab.py
mv newplots/adult_context_marital_age_2.pdf  newplots/4a.pdf
mv newplots/compas_context_race_juvenile.pdf newplots/4b.pdf
