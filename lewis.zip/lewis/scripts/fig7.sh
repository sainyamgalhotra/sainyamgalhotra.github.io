python fig7a.py
mv newplots/german_global_related.pdf newplots/7a.pdf

python adult_relative.py randomforest
mv newplots/adult_global_related_randomforest.pdf newplots/7b.pdf

python fig7c.py
mv newplots/compas_score_text_global_related.pdf newplots/7c.pdf
