import sys
f = open(sys.argv[1],"r")
mapping={}
for line in f:
	line = line.strip()
	line = line.split(' ')
	mapping[int(line[0])] = line[1]

f = open(sys.argv[1]+"adp","r")
for line in f:
	line = line.strip()
	line = line.split()
	if int(line[0]) in mapping.keys():
		print line[1],mapping[int(line[0])],line[0]
