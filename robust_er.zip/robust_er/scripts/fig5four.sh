cd ../src
#javac *.java
rm -r ../output/5f*

mkdir -p ../output/sqrt
java fig5defgh sqrt 1 0 0.1 1 0.3 0.95 0
mv ../output/sqrt ../output/5fadaptive

mkdir -p ../output/sqrt
java fig5defgh sqrt 2 0 0.1 1 0.3 0.95 0
mv ../output/sqrt ../output/5feager


mkdir -p ../output/sqrt
java fig5defgh sqrt 3 0 0.1 1 0.3 0.95 0
mv ../output/sqrt ../output/5flazy


mkdir -p ../output/5f
python ../scripts/calculateavg.py ../output/5fadaptive > ../output/5f/adaptive.txt
python ../scripts/calculateavg.py ../output/5feager > ../output/5f/eager.txt
python ../scripts/calculateavg.py ../output/5flazy > ../output/5f/lazy.txt
#python ../scripts/calculateavg.py ../output/5fgymdense > ../output/5f/dense.txt

cp ../alreadyPresent/5f/plot.gnu ../output/5f/
cp ../alreadyPresent/5f/ideal ../output/5f/
cp ../alreadyPresent/5f/votes.txt ../output/5f/
cp ../alreadyPresent/5f/dense.txt ../output/5f/

cd ../output/5f
gnuplot plot.gnu
epspdf data.ps
cp -r ../5f/ ../../freshRuns/output/
