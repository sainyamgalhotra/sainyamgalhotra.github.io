rm -r ../output/7a
mkdir -p ../output/7a
cp ../output/5a/adaptive.txt ../output/7a/gym 
cp ../output/5b/adaptive.txt ../output/7a/captchas
cp ../output/5e/adaptive.txt ../output/7a/skew
cp ../output/5f/adaptive.txt ../output/7a/sqrt
cp ../output/5g/adaptive.txt ../output/7a/cora

cp ../alreadyPresent/7a/plot.gnu ../output/7a/

cd ../output/7a
gnuplot plot.gnu
epspdf data.ps

cp -r ../7a/ ../../freshRuns/output/
