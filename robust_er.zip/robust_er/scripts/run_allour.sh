bash fig4our.sh
bash fig5our.sh
bash fig6our.sh
bash fig7our.sh
bash fig9our.sh
bash fig10our.sh
