cd ../src
#javac *.java
rm -r ../output/5d*

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 0.2 0.3 0.95 0
mv ../output/cora ../output/corabeta02

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 0.6 0.3 0.95 0
mv ../output/cora ../output/corabeta06

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/corabeta1

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1.4 0.3 0.95 0
mv ../output/cora ../output/corabeta14

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1.8 0.3 0.95 0
mv ../output/cora ../output/corabeta18


mkdir -p ../output/5d
python ../scripts/calculateavg.py ../output/corabeta02 > ../output/5d/corabeta02.txt
python ../scripts/calculateavg.py ../output/corabeta06 > ../output/5d/corabeta06.txt
python ../scripts/calculateavg.py ../output/corabeta1 > ../output/5d/corabeta1.txt
python ../scripts/calculateavg.py ../output/corabeta14 > ../output/5d/corabeta14.txt
python ../scripts/calculateavg.py ../output/corabeta18 > ../output/5d/corabeta18.txt


cp ../alreadyPresent/5d/plot.gnu ../output/5d/
cp ../alreadyPresent/5d/ideal ../output/5d/

cd ../output/5d
gnuplot plot.gnu
epspdf data.ps
cp -r ../5d/ ../../freshRuns/output/
