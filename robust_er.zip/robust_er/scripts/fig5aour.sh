cd ../src
#javac *.java
rm -r ../output/5a*

mkdir -p ../output/gym
java figure5abc gym 1 0
mv ../output/gym ../output/5aadaptive

mkdir -p ../output/gym
java figure5abc gym 2 0
mv ../output/gym ../output/5aeager


mkdir -p ../output/gym
java figure5abc gym 3 0
mv ../output/gym ../output/5alazy

#mkdir -p ../output/gym
#java fig4fig5abcdense gym false false
#mv ../output/gym ../output/5agymdense

mkdir -p ../output/5a
python ../scripts/calculateavg.py ../output/5aadaptive > ../output/5a/adaptive.txt
python ../scripts/calculateavg.py ../output/5aeager > ../output/5a/eager.txt
python ../scripts/calculateavg.py ../output/5alazy > ../output/5a/lazy.txt
#python ../scripts/calculateavgdense.py ../output/5agymdense > ../output/5a/dense.txt





cp ../alreadyPresent/5a/plot.gnu ../output/5a/
cp ../alreadyPresent/5a/ideal ../output/5a/
cp ../alreadyPresent/5a/votes.txt ../output/5a/
cp ../alreadyPresent/5a/dense.txt ../output/5a/

cd ../output/5a
gnuplot plot.gnu
epspdf data.ps

cp -r ../5a/ ../../freshRuns/output/
