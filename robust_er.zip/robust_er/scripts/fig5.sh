bash fig5a.sh
bash fig5b.sh
bash fig5c.sh
bash fig5d.sh
bash fig5e.sh
bash fig5f.sh
bash fig5g.sh
bash fig5h.sh
