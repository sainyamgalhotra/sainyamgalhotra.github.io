cd ../src
#javac *.java

rm -r ../output/9d*

mkdir -p ../output/cora
java fig5defgh cora 10 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9dhybrid

mkdir -p ../output/cora
java fig5defgh cora 11 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9dehybrid


mkdir -p ../output/cora
java fig5defgh cora 12 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9dadphybrid


mkdir -p ../output/9d
python ../scripts/calculateavg.py ../output/9dhybrid > ../output/9d/hybrid.txt
python ../scripts/calculateavg.py ../output/9dehybrid > ../output/9d/ehybrid.txt
python ../scripts/calculateavg.py ../output/9dadphybrid > ../output/9d/adphybrid.txt
#python ../scripts/calculateavg.py ../output/9dgymdense > ../output/9d/9ddense.txt


cp ../alreadyPresent/9d/plot.gnu ../output/9d/

cd ../output/9d
gnuplot plot.gnu
epspdf data.ps
cp -r ../9d/ ../../freshRuns/output/
