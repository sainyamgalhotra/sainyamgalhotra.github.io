cd ../src
#javac *.java
rm -r ../output/4b*

mkdir -p ../output/4b
mkdir -p ../output/gym
java fig4adaptive gym false
mv ../output/gym ../output/4bgymfalse

mkdir -p ../output/gym
java fig4adaptive gym true 
mv ../output/gym ../output/4bgymtrue

cp ../alreadyPresent/4b/dense.txt ../output/4b/
#mkdir -p ../output/gym
#java fig4fig5abcdense gym true false 
#mv ../output/gym ../output/4bgymdense

python ../scripts/calculateavgSCC.py ../output/4bgymfalse > ../output/4b/scc.txt
python ../scripts/calculateavgSCC.py ../output/4bgymtrue > ../output/4b/iscc.txt
#python ../scripts/calculateavgdense.py ../output/4bgymdense > ../output/4b/dense.txt


cp ../alreadyPresent/4b/plot.gnu ../output/4b/

cd ../output/4b
gnuplot plot.gnu
epspdf data.ps

cp -r ../4b/ ../../freshRuns/output/
