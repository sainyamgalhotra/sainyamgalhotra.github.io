bash fig10a.sh
bash fig10b.sh
