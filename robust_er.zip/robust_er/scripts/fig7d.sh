cd ../src
#javac *.java
rm -r ../output/7d*

for pipeline in 0.0 0.1 0.2 0.3 
do
	mkdir -p ../output/dblp_error_$pipeline
	for i in `seq 1 10`;
	do
		echo $i, $pipeline
		java -jar -Xmx40080m  -XX:-UseGCOverheadLimit dblp.jar 1 10 $pipeline
		mv output_fscore10.0_$pipeline'_1' ../output/dblp_error_$pipeline/output_fscore_$i
	done    
done


cd ../output

mkdir -p 7d
for lamb in 0.0 0.1 0.2 0.3
do
	python ../scripts/calculateavgdblp.py dblp_error_$lamb > 7d/$lamb.txt       
done
cp ../alreadyPresent/7d/plot.gnu 7d/
cp ../alreadyPresent/7d/ideal 7d/
cd 7d/
gnuplot plot.gnu
epspdf data.ps
cp -r ../7d/ ../../freshRuns/output/
