cd ..
wget https://www.dropbox.com/s/gojcs1f49jkm4mn/SmallData.zip
unzip SmallData.zip
cd src
wget https://www.dropbox.com/s/s8z7wavt6jmqpvb/data.zip
unzip data.zip
