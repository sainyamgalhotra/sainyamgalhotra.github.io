cd ../src
#javac *.java
rm -r ../output/6a*

mkdir -p ../output/cora200
java fig6acora 1
mv ../output/cora200 ../output/6aadaptive

mkdir -p ../output/cora200
java fig6acora 2
mv ../output/cora200 ../output/6aeager


mkdir -p ../output/cora200
java fig6acora 3
mv ../output/cora200 ../output/6alazy


mkdir -p ../output/6a
python ../scripts/calculateavg.py ../output/6aadaptive > ../output/6a/adaptive.txt
python ../scripts/calculateavg.py ../output/6aeager > ../output/6a/eager.txt
python ../scripts/calculateavg.py ../output/6alazy > ../output/6a/lazy.txt
#python ../scripts/calculateavg.py ../output/5agymdense > ../output/6a/6adense.txt


cp ../alreadyPresent/6a/plot.gnu ../output/6a/
cp ../alreadyPresent/6a/waldo ../output/6a/

cd ../output/6a
gnuplot plot.gnu
epspdf data.ps

cp -r ../6a/ ../../freshRuns/output/
