bash fig7a.sh
bash fig7b.sh
bash fig7c.sh
bash fig7d.sh

