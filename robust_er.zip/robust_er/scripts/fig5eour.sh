cd ../src
#javac *.java
rm -r ../output/5e*

mkdir -p ../output/skew
java fig5defgh skew 1 0 0.1 1 0.3 0.95 0
mv ../output/skew ../output/5eadaptive

mkdir -p ../output/skew
java fig5defgh skew 2 0 0.1 1 0.3 0.95 0
mv ../output/skew ../output/5eeager


mkdir -p ../output/skew
java fig5defgh skew 3 0 0.1 1 0.3 0.95 0
mv ../output/skew ../output/5elazy


mkdir -p ../output/5e
python ../scripts/calculateavg.py ../output/5eadaptive > ../output/5e/adaptive.txt
python ../scripts/calculateavg.py ../output/5eeager > ../output/5e/eager.txt
python ../scripts/calculateavg.py ../output/5elazy > ../output/5e/lazy.txt
#python ../scripts/calculateavg.py ../output/5edense > ../output/5e/5edense.txt


cp ../alreadyPresent/5e/plot.gnu ../output/5e/
cp ../alreadyPresent/5e/ideal ../output/5e/
cp ../alreadyPresent/5e/votes.txt ../output/5e/
cp ../alreadyPresent/5e/dense.txt ../output/5e/

cd ../output/5e
gnuplot plot.gnu
epspdf data.ps
cp -r ../5e/ ../../freshRuns/output/
