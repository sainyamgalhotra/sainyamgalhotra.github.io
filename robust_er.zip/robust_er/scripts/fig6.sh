bash fig6a.sh
bash fig6b.sh
