mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesunique.jar -k 1 -p landmarks.prop
	mv logs/log_explandmarks ../output/votes/$i
done    
cd ../output
mv votes 9avotes
python ../scripts/calculateavgvotes.py 9avotes > 9a/votes.txt       
