mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesynthetic.jar -k 1 -p sqrt.prop
	mv logs/log_expsqrt ../output/votes/$i
done    
cd ../output
mv votes 5fvotes
python ../scripts/calculateavgvotes.py 5fvotes > 5f/votes.txt       
