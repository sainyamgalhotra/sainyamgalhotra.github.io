mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesunique.jar -k 1 -p captchas.prop
	mv logs/log_expcaptchas ../output/votes/$i
done    
cd ../output
mv votes 5bvotes
python ../scripts/calculateavgvotes.py 5bvotes > 5b/votes.txt       
