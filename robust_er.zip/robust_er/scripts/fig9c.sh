cd ../src
#javac *.java
rm -r ../output/9c*

mkdir -p ../output/gym
java figure5abc gym 6 0
mv ../output/gym ../output/9cnode

mkdir -p ../output/gym
java figure5abc gym 9 0
mv ../output/gym ../output/9cedge


#mkdir -p ../output/gym
#java fig4fig5abcdense gym false false
#mv ../output/gym ../output/9cgymdense

mkdir -p ../output/9c
python ../scripts/calculateavg.py ../output/9cnode > ../output/9c/node.txt
python ../scripts/calculateavg.py ../output/9cedge > ../output/9c/edge.txt
#python ../scripts/calculateavg.py ../output/5agymdense > ../output/5a/5adense.txt

cp ../output/5a/votes.txt ../output/9c/
cp ../output/5a/dense.txt ../output/9c/
cp ../alreadyPresent/9c/plot.gnu ../output/9c/
cp ../alreadyPresent/9c/ideal ../output/9c/

cd ../output/9c
gnuplot plot.gnu
epspdf data.ps
cp -r ../9c/ ../../freshRuns/output/
