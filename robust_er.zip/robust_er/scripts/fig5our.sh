bash fig5aour.sh
bash fig5bour.sh
bash fig5cour.sh
bash fig5dour.sh
bash fig5eour.sh
bash fig5four.sh
bash fig5gour.sh
bash fig5hour.sh
