cd ../src
#javac *.java
rm -r ../output/10a*

for pipeline in {1,2,3};
do
	mkdir -p ../output/dblp_$pipeline
	for i in `seq 1 10`;
	do
		echo $i
		java -jar -Xmx40080m  -XX:-UseGCOverheadLimit dblpold.jar $pipeline 10 0.1
		mv output_fscore10.0_0.1_$pipeline ../output/dblp_$pipeline/output_fscore_$i
	done    
done


cd ../output
mkdir -p 10a

for lamb in {1,2,3};
do
	python ../scripts/calculateavgdblp.py dblp_$lamb > 10a/$lamb.txt       
done
cp ../alreadyPresent/10a/plot.gnu 10a/
cp ../alreadyPresent/10a/ideal.txt 10a/
cd 10a/
gnuplot plot.gnu
epspdf data.ps
cp -r ../10a/ ../../freshRuns/output/
