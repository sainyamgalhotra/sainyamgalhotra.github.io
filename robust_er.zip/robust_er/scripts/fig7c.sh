cd ../src
#javac *.java
rm -r ../output/7c*

mkdir -p ../output/cora
java fig7c cora 1 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/7cadaptive

mkdir -p ../output/cora
java fig7c cora 2 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/7ceager


mkdir -p ../output/cora
java fig7c cora 3 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/7clazy


mkdir -p ../output/7c
python ../scripts/calculateavg.py ../output/7cadaptive > ../output/7c/adaptive.txt
python ../scripts/calculateavg.py ../output/7ceager > ../output/7c/eager.txt
python ../scripts/calculateavg.py ../output/7clazy > ../output/7c/lazy.txt
#python ../scripts/calculateavg.py ../output/7cgymdense > ../output/7c/dense.txt

mkdir -p ../output/votescora
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
        echo $i
        java -jar votesynthetic.jar -k 1 -p corasparse.prop > terminal_logs
        mv logs/log_expcora ../output/votescora/$i
done
cd ../output
mv votescora 7cvotes
python ../scripts/calculateavgvotes.py 7cvotes > 7c/votes.txt


cp ../alreadyPresent/7c/plot.gnu ../output/7c/
cp ../alreadyPresent/7c/ideal ../output/7c/
cp ../alreadyPresent/7c/dense.txt ../output/7c/

cd ../output/7c
gnuplot plot.gnu
epspdf data.ps
cp -r ../7c/ ../../freshRuns/output/
