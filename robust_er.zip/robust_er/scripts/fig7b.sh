rm -r ../output/7b
mkdir -p ../output/7b

cp ../alreadyPresent/7b/process.py ../output/7b

cd ../output/7b
cp ../5a/ideal ../7b/gym
cp ../5a/adaptive.txt ../7b/gymadp
python process.py gym > gymqq 

cp ../5b/ideal ../7b/captchas
cp ../5b/adaptive.txt ../7b/captchasadp
python process.py captchas > captchasqq 

cp ../5e/ideal ../7b/skew
cp ../5e/adaptive.txt ../7b/skewadp
python process.py skew > skewqq 

cp ../5f/ideal ../7b/sqrt
cp ../5f/adaptive.txt ../7b/sqrtadp
python process.py sqrt > sqrtqq 

cp ../5g/ideal ../7b/cora
cp ../5g/adaptive.txt ../7b/coraadp
python process.py cora > coraqq 

cp ../../alreadyPresent/7b/plot.gnu ../7b/

cd ../7b
gnuplot plot.gnu
epspdf data.ps
cp -r ../7b/ ../../freshRuns/output/
