cd ../src
#javac *.java
rm -r ../output/9h*

for lamb in {4..12..2};
do
	mkdir -p ../output/dblp$lamb
	for i in `seq 1 10`;
	do
		echo $i
		java -jar -Xmx40080m  -XX:-UseGCOverheadLimit dblp.jar 1 $lamb 0.1
		mv output_fscore$lamb'.0_0.1_1' ../output/dblp$lamb/output_fscore_$i
	done    
done


cd ../output

mkdir -p 9h
for lamb in {4..12..2};
do
	python ../scripts/calculateavgdblp.py dblp$lamb > 9h/$lamb.txt       
done
cp ../alreadyPresent/9h/plot.gnu 9h/
cp ../alreadyPresent/9h/ideal 9h/
cd 9h/
gnuplot plot.gnu
epspdf data.ps
cp -r ../9h/ ../../freshRuns/output/
