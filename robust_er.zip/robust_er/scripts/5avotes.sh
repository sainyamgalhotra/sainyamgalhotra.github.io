mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesunique.jar -k 1 -p gym.prop
	mv logs/log_expgym ../output/votes/$i
done    
cd ../output
mv votes 5avotes
python ../scripts/calculateavgvotes.py 5avotes > 5a/votes.txt       
