cd ../src
#javac *.java
rm ../output/4a*

mkdir -p ../output/4a
mkdir -p ../output/captchas

java fig4adaptive captchas false
mv ../output/captchas ../output/4acaptchasfalse

mkdir -p ../output/captchas
java fig4adaptive captchas true 
mv ../output/captchas ../output/4acaptchastrue

cp ../alreadyPresent/4a/dense.txt ../output/4a/
#mkdir -p ../output/captchas
#java fig4fig5abcdense captchas true false
#mv ../output/captchas ../output/4acaptchasdense


python ../scripts/calculateavgSCC.py ../output/4acaptchasfalse > ../output/4a/scc.txt
python ../scripts/calculateavgSCC.py ../output/4acaptchastrue > ../output/4a/iscc.txt
#python ../scripts/calculateavgdense.py ../output/4acaptchasdense > ../output/4a/dense.txt


cp ../alreadyPresent/4a/plot.gnu ../output/4a/

cd ../output/4a
gnuplot plot.gnu
epspdf data.ps
cp -r ../4a/ ../../freshRuns/output/
