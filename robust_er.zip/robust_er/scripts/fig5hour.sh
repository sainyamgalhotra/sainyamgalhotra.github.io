cd ../src
#javac *.java
rm -r ../output/5h*

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.2 1 0.3 0.95 0
mv ../output/cora ../output/5hadaptive

mkdir -p ../output/cora
java fig5defgh cora 2 0 0.2 1 0.3 0.95 0
mv ../output/cora ../output/5heager


mkdir -p ../output/cora
java fig5defgh cora 3 0 0.2 1 0.3 0.95 0
mv ../output/cora ../output/5hlazy


mkdir -p ../output/5h
python ../scripts/calculateavg.py ../output/5hadaptive > ../output/5h/adaptive.txt
python ../scripts/calculateavg.py ../output/5heager > ../output/5h/eager.txt
python ../scripts/calculateavg.py ../output/5hlazy > ../output/5h/lazy.txt
#python ../scripts/calculateavg.py ../output/5hgymdense > ../output/5h/dense.txt



cp ../alreadyPresent/5h/plot.gnu ../output/5h/
cp ../alreadyPresent/5h/ideal ../output/5h/
cp ../alreadyPresent/5h/dense.txt ../output/5h/
cp ../alreadyPresent/5h/votes.txt ../output/5h/

cd ../output/5h
gnuplot plot.gnu
epspdf data.ps
cp -r ../5h/ ../../freshRuns/output/
