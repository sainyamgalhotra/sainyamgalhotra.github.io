cd ../src
#javac *.java
rm -r ../output/9a*

mkdir -p ../output/landmarks
java figure5abc landmarks 1 0
mv ../output/landmarks ../output/9aadaptive

mkdir -p ../output/landmarks
java figure5abc landmarks 2 0
mv ../output/landmarks ../output/9aeager


mkdir -p ../output/landmarks
java figure5abc landmarks 3 0
mv ../output/landmarks ../output/9alazy

#mkdir -p ../output/landmarks
#java fig4fig5abcdense landmarks false false
#mv ../output/landmarks ../output/9alandmarksdense

mkdir -p ../output/9a
python ../scripts/calculateavg.py ../output/9aadaptive > ../output/9a/adaptive.txt
python ../scripts/calculateavg.py ../output/9aeager > ../output/9a/eager.txt
python ../scripts/calculateavg.py ../output/9alazy > ../output/9a/lazy.txt
#python ../scripts/calculateavgdense.py ../output/9alandmarksdense > ../output/9a/9adense.txt

cp ../alreadyPresent/9a/plot.gnu ../output/9a/
cp ../alreadyPresent/9a/ideal ../output/9a/
cp ../alreadyPresent/9a/dense.txt ../output/9a/
cp ../alreadyPresent/9a/votes.txt ../output/9a/

cd ../output/9a
gnuplot plot.gnu
epspdf data.ps
cp -r ../9a/ ../../freshRuns/output/
