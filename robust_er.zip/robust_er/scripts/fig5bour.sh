cd ../src
#javac *.java
rm -r ../output/5b*

mkdir -p ../output/captchas
java figure5abc captchas 1 0
mv ../output/captchas ../output/5badaptive

mkdir -p ../output/captchas
java figure5abc captchas 2 0
mv ../output/captchas ../output/5beager


mkdir -p ../output/captchas
java figure5abc captchas 3 0
mv ../output/captchas ../output/5blazy

#mkdir -p ../output/captchas
#java fig4fig5abcdense captchas false false
#mv ../output/captchas ../output/5acaptchasdense


mkdir -p ../output/5b
python ../scripts/calculateavg.py ../output/5badaptive > ../output/5b/adaptive.txt
python ../scripts/calculateavg.py ../output/5beager > ../output/5b/eager.txt
python ../scripts/calculateavg.py ../output/5blazy > ../output/5b/lazy.txt
#python ../scripts/calculateavgdense.py ../output/5bcaptchasdense > ../output/5b/dense.txt

cp ../alreadyPresent/5b/plot.gnu ../output/5b/
cp ../alreadyPresent/5b/ideal ../output/5b/
cp ../alreadyPresent/5b/dense.txt ../output/5b/
cp ../alreadyPresent/5b/votes.txt ../output/5b/

cd ../output/5b
gnuplot plot.gnu
epspdf data.ps
cp -r ../5b/ ../../freshRuns/output/
