cd ../src
#javac *.java
rm -r ../output/9g*

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.2 0.95 0
mv ../output/cora ../output/9g2

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9g3


mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.4 0.95 0
mv ../output/cora ../output/9g4

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.5 0.95 0
mv ../output/cora ../output/9g5

mkdir -p ../output/9g
python ../scripts/calculateavg.py ../output/9g2 > ../output/9g/2.txt
python ../scripts/calculateavg.py ../output/9g3 > ../output/9g/3.txt
python ../scripts/calculateavg.py ../output/9g4 > ../output/9g/4.txt
python ../scripts/calculateavg.py ../output/9g5 > ../output/9g/5.txt


cp ../alreadyPresent/9g/plot.gnu ../output/9g/
cp ../alreadyPresent/9g/ideal ../output/9g/

cd ../output/9g
gnuplot plot.gnu
epspdf data.ps
cp -r ../9g/ ../../freshRuns/output/
