mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesynthetic.jar -k 1 -p cora2.prop > output_log
	mv logs/log_expcora2 ../output/votes/$i
done    
cd ../output
mv votes 5hvotes
python ../scripts/calculateavgvotes.py 5hvotes > 5h/votes.txt       
