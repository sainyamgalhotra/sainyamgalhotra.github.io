import sys
indir = sys.argv[1]
f1 = open(indir+"/output_fscore_1","r")
f2 = open(indir+"/output_fscore_2","r")
f3 = open(indir+"/output_fscore_3","r")
f4 = open(indir+"/output_fscore_4","r")
f5 = open(indir+"/output_fscore_5","r")
f6 = open(indir+"/output_fscore_6","r")
f7 = open(indir+"/output_fscore_7","r")
f8 = open(indir+"/output_fscore_8","r")
f9 = open(indir+"/output_fscore_9","r")
f10 = open(indir+"/output_fscore_10","r")


arr = []
num=[]
max = 20000
i=0
while i<max :
    arr.append(0)
    num.append(0)
    i+=1

for lin in f1:
    lin = lin.strip()
    lin = lin.split()

    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1

for lin in f2:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1

for lin in f3:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1

for lin in f4:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1
for lin in f5:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1
for lin in f6:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1
for lin in f7:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1
for lin in f8:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1
for lin in f9:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1
for lin in f10:
    lin = lin.strip()
    lin = lin.split()
    arr[int(lin[0])] +=float(lin[-1])
    num[int(lin[0])] += 1


i=0
while i<max:
    if(num[i]>0):
        print (str(i)+" "+str(arr[i]*1.0/num[i]))
    i+=1
