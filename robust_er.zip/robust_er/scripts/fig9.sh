bash fig9a.sh
bash fig9b.sh
bash fig9c.sh
bash fig9d.sh
bash fig9e.sh
bash fig9f.sh
bash fig9g.sh
bash fig9h.sh
