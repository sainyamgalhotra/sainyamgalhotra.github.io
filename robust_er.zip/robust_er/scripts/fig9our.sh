bash fig9aour.sh
bash fig9bour.sh
bash fig9cour.sh
bash fig9d.sh
bash fig9e.sh
bash fig9f.sh
bash fig9g.sh
bash fig9h.sh
