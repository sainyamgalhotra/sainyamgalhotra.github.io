mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesynthetic.jar -k 1 -p corasparse.prop
	mv logs/log_expcorasparse ../output/votes/$i
done    
cd ../output
mv votes 9bvotes
python ../scripts/calculateavgvotes.py 9bvotes > 9b/votes.txt       
