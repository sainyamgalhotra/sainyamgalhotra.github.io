cd ../src
#javac *.java
rm -r ../output/5g*

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/5gadaptive

mkdir -p ../output/cora
java fig5defgh cora 2 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/5geager


mkdir -p ../output/cora
java fig5defgh cora 3 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/5glazy


mkdir -p ../output/5g
python ../scripts/calculateavg.py ../output/5gadaptive > ../output/5g/adaptive.txt
python ../scripts/calculateavg.py ../output/5geager > ../output/5g/eager.txt
python ../scripts/calculateavg.py ../output/5glazy > ../output/5g/lazy.txt
#python ../scripts/calculateavg.py ../output/5ggymdense > ../output/5g/dense.txt


cp ../alreadyPresent/5g/plot.gnu ../output/5g/
cp ../alreadyPresent/5g/ideal ../output/5g/
cp ../alreadyPresent/5g/votes.txt ../output/5g/
cp ../alreadyPresent/5g/dense.txt ../output/5g/

cd ../output/5g
gnuplot plot.gnu
epspdf data.ps
cp -r ../5g/ ../../freshRuns/output/
