cd ../src
#javac *.java
rm -r ../output/5c*

mkdir -p ../output/gym
java figure5abc gym 1 0 true true 0
mv ../output/gym ../output/5c0

mkdir -p ../output/gym
java figure5abc gym 1 0 true true 0.1
mv ../output/gym ../output/5c01

mkdir -p ../output/gym
java figure5abc gym 1 0 true true 0.2
mv ../output/gym ../output/5c02

mkdir -p ../output/gym
java figure5abc gym 1 0 true true 0.3
mv ../output/gym ../output/5c03

mkdir -p ../output/gym
java figure5abc gym 1 0 true true 0.05
mv ../output/gym ../output/5c05


mkdir -p ../output/5c
python ../scripts/calculateavg.py ../output/5c0 > ../output/5c/5c0.txt
python ../scripts/calculateavg.py ../output/5c01 > ../output/5c/5c01.txt
python ../scripts/calculateavg.py ../output/5c02 > ../output/5c/5c02.txt
python ../scripts/calculateavg.py ../output/5c03 > ../output/5c/5c03.txt
python ../scripts/calculateavg.py ../output/5c05 > ../output/5c/5c05.txt


cp ../alreadyPresent/5c/plot.gnu ../output/5c/

cd ../output/5c
gnuplot plot.gnu
epspdf data.ps
cp -r ../5c/ ../../freshRuns/output/
