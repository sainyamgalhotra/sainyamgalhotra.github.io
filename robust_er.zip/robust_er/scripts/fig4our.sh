bash fig4aour.sh
bash fig4bour.sh
