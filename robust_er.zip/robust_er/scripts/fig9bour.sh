cd ../src
#javac *.java
rm -r ../output/9b*

mkdir -p ../output/cora
java fig5defgh cora 6 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9bnode

#mkdir -p ../output/cora
#java fig5defgh cora 9 0 0.1 1 0.3 0.95 0
#mv ../output/cora ../output/9bedge

mkdir -p ../output/9b
python ../scripts/calculateavg.py ../output/9bnode > ../output/9b/node.txt
#python ../scripts/calculateavg.py ../output/9bedge > ../output/9b/edge.txt
#python ../scripts/calculateavg.py ../output/9bgymdense > ../output/9b/dense.txt


cp ../output/5g/votes.txt ../output/9b/
cp ../alreadyPresent/9b/edge.txt ../output/9b/
cp ../output/9b/dense.txt ../output/9b/
cp ../alreadyPresent/9b/plot.gnu ../output/9b/
cp ../alreadyPresent/9b/ideal ../output/9b/

cd ../output/9b
gnuplot plot.gnu
epspdf data.ps
cp -r ../9b/ ../../freshRuns/output/
