cd ../src
#javac *.java
rm -r ../output/6b*

mkdir -p ../output/allsports
java fig6adaptive allsports 1
mv ../output/allsports ../output/6badaptive

mkdir -p ../output/allsports
java fig6adaptive allsports 2
mv ../output/allsports ../output/6beager


mkdir -p ../output/allsports
java fig6adaptive allsports 3
mv ../output/allsports ../output/6blazy


mkdir -p ../output/6b
python ../scripts/calculateavg.py ../output/6badaptive > ../output/6b/adaptive.txt
python ../scripts/calculateavg.py ../output/6beager > ../output/6b/eager.txt
python ../scripts/calculateavg.py ../output/6blazy > ../output/6b/lazy.txt
#python ../scripts/calculateavg.py ../output/5agymdense > ../output/6b/6bdense.txt


cp ../alreadyPresent/6b/plot.gnu ../output/6b/
cp ../alreadyPresent/6b/waldo30 ../output/6b/

cd ../output/6b
gnuplot plot.gnu
epspdf data.ps

cp -r ../6b/ ../../freshRuns/output/
