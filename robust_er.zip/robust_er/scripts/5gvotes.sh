mkdir -p ../output/votes
cd ../FaultTolerantERWithTheCrowd/
for i in `seq 1 10`;
do
	echo $i
	java -jar votesynthetic.jar -k 1 -p cora.prop
	mv logs/log_expcora ../output/votes/$i
done    
cd ../output
mv votes 5gvotes
python ../scripts/calculateavgvotes.py 5gvotes > 5g/votes.txt       
