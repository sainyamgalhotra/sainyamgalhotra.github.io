bash fig4a.sh
bash fig4b.sh
