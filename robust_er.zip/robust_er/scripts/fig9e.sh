cd ../src
#javac *.java
rm -r ../output/9e*

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9e95

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.93 0
mv ../output/cora ../output/9e93


mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.91 0
mv ../output/cora ../output/9e91

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.97 0
mv ../output/cora ../output/9e97

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.99 0
mv ../output/cora ../output/9e99

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.8 0
mv ../output/cora ../output/9e8


mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.9999 0
mv ../output/cora ../output/9e9999


mkdir -p ../output/9e
python ../scripts/calculateavg.py ../output/9e95 > ../output/9e/95.txt
python ../scripts/calculateavg.py ../output/9e93 > ../output/9e/93.txt
python ../scripts/calculateavg.py ../output/9e91 > ../output/9e/91.txt
python ../scripts/calculateavg.py ../output/9e97 > ../output/9e/97.txt
python ../scripts/calculateavg.py ../output/9e8 > ../output/9e/8.txt
python ../scripts/calculateavg.py ../output/9e99 > ../output/9e/99.txt
python ../scripts/calculateavg.py ../output/9e9999 > ../output/9e/9999.txt



cp ../alreadyPresent/9e/plot.gnu ../output/9e/
cp ../alreadyPresent/9e/ideal ../output/9e/

cd ../output/9e
gnuplot plot.gnu
epspdf data.ps
cp -r ../9e/ ../../freshRuns/output/
