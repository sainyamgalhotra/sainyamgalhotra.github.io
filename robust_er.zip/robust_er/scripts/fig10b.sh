cd ../src
#javac *.java
rm -r ../output/10b*

for pipeline in {2,3};
do
	mkdir -p ../output/dblp_$pipeline
	for i in `seq 1 10`;
	do
		echo $i
		java -jar -Xmx40080m  -XX:-UseGCOverheadLimit dblp.jar $pipeline 10 0.1
		mv output_fscore10.0_0.1_$pipeline ../output/dblp_$pipeline/output_fscore_$i
	done    
done


cd ../output
mkdir -p 10b

cp 7d/0.1.txt 10b/1.txt
for lamb in {2,3};
do
	python ../scripts/calculateavgdblp.py dblp_$lamb > 10b/$lamb.txt       
done

cp ../alreadyPresent/10b/plot.gnu 10b/
cp ../alreadyPresent/10b/ideal 10b/
cd 10b/
gnuplot plot.gnu
epspdf data.ps
cp -r ../10b/ ../../freshRuns/output/
