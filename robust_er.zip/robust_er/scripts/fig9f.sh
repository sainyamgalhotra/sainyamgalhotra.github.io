cd ../src
#javac *.java
rm -r ../output/9f*

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 0
mv ../output/cora ../output/9f1

mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 -0.5
mv ../output/cora ../output/9f05


mkdir -p ../output/cora
java fig5defgh cora 1 0 0.1 1 0.3 0.95 0.5
mv ../output/cora ../output/9f15


mkdir -p ../output/9f
python ../scripts/calculateavg.py ../output/9f1 > ../output/9f/1.txt
python ../scripts/calculateavg.py ../output/9f05 > ../output/9f/05.txt
python ../scripts/calculateavg.py ../output/9f15 > ../output/9f/15.txt


cp ../alreadyPresent/9f/plot.gnu ../output/9f/
cp ../alreadyPresent/9f/ideal ../output/9f/

cd ../output/9f
gnuplot plot.gnu
epspdf data.ps
cp -r ../9f/ ../../freshRuns/output/
