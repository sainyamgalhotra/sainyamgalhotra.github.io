bash fig7a.sh
bash fig7b.sh
bash fig7cour.sh
bash fig7dour.sh

