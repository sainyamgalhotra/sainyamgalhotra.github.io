/**
 * 
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;


public class fig5defgh {
	int queries=0;
	static Random generator = new Random(1992);

	HashMap<pair,Boolean> oracle = new HashMap<pair,Boolean>();
	ArrayList<component> set_clusters = new ArrayList<component>();
	Map<pair, Boolean> queried_edge_map = new HashMap<pair, Boolean>();
	int N;
	int true_pos=0;
	int false_pos=0;
	int max_query=0;
	int expansionType = 0 ;//0 means random, 1 means closest to 1, 2 means closest to 0 amd 3 means closes to 0.5
	double sparsityThreshold = 0.0;
	int countSparsity=0;
	boolean noisySparsity = false;

	ArrayList<double[]> prob_list = new ArrayList<double[]>();
	static double r_t_g;
	static double g_t_r;
	boolean file_present = false;
	int pipeline = 1;
	double beta = 1;
	double confidence = 0.95;
	boolean unique = false;
	int num_unique = 3;
	PrintStream ouput_print;
	Map<pair, Integer> answers;
	Map<pair, Integer> curr_ans;
	double theta = 0.3;
	int tau=0;

	double oraclenoiseval = 0.0;
	int oraclenoisetype = 1;

	boolean noiseEdgeProb = false;
	int noiseEdgeProbType=1;
	double edgeProbNoiseVal = 0.01;

	HashMap<Integer,Integer> parentlist=new HashMap<Integer,Integer>();
	public  ArrayList<int[]>  sort_edges_pairlist(ArrayList<int[]> pairlist, Map<pair, Double> edge_prob){
		ArrayList<int[]> sorted = new ArrayList<int[]>();
		if(expansionType == 0) {
			Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
			Collections.shuffle(pairlist,newgen);
			return pairlist;
		}

		ArrayList<double[]> lst = new ArrayList<double[]>();
		for(int i=0;i<pairlist.size();i++) {
			pair t = new pair(pairlist.get(i)[0],pairlist.get(i)[1]);
			double[] tmp = {edge_prob.get(t),pairlist.get(i)[0],pairlist.get(i)[1]};
			lst.add(tmp);
		}
		Collections.sort(lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[0]; double s2 = o2[0];
				if(expansionType ==1) {
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}else if(expansionType ==2) {
					if (s1 != s2)
						return (s1 > s2 ? 1 : -1);
					else
						return 0;
				}else {
					if(s1>=0.5)
						s1=1-s1;
					if(s2>=0.5)
						s2=1-s2;
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}

			}
		});
		for(double[] a:lst) {
			int[] tmp = {(int)a[1],(int)a[2]};
			sorted.add(tmp);
		}
		return sorted;
	}

	public  ArrayList<Integer>  sort_edges(ArrayList<Integer> current, int max, Map<pair, Double> edge_prob){
		ArrayList<Integer> sorted = new ArrayList<Integer>();
		if(expansionType == 0) {
			Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
			Collections.shuffle(current,newgen);
			return current;
		}

		ArrayList<double[]> lst = new ArrayList<double[]>();
		for(int i=0;i<current.size();i++) {
			pair t = new pair(max,current.get(i));
			double[] tmp = {edge_prob.get(t),current.get(i)};
			lst.add(tmp);
		}
		Collections.sort(lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[0]; double s2 = o2[0];
				if(expansionType ==1) {
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}else if(expansionType ==2) {
					if (s1 != s2)
						return (s1 > s2 ? 1 : -1);
					else
						return 0;
				}else {
					if(s1>=0.5)
						s1=1-s1;
					if(s2>=0.5)
						s2=1-s2;
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}

			}
		});
		for(double[] a:lst) {
			sorted.add((int)a[1]);
		}
		return sorted;
	}

	public void mergeClusters(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();

		int num_clust_queried = 0;
		int logn = (int) ((int)Math.log(graph_nodes.size())/Math.log(2));
		//System.out.println("merging the clusters now");
		while(true){

			if(num_clust_queried >= (logn*(logn-1))/2)
				break;

			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double benefit = 0.0;
					int num_q=0;

					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(fresh_queried_edge_map.containsKey(t)){
								num_q++;
								if(fresh_queried_edge_map.get(t)){
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;
								}
							}
							benefit+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}

					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {benefit,i,j,pos,neg,pr,pg, benefit/(a.size()*b.size()), num_q};
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				if(num_clust_queried >= (logn*(logn-1))/2)
					break;

				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();


				num_clust_queried++;
				double prob_curr = 1.0;
				int size = Math.min(a.size(), b.size());
				double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
				prob_wanted = Math.pow(prob_wanted, size);
				double pr=entry[5],pg=entry[6];

				if(pr*1.0/(pr+pg) > this.confidence)
					continue;
				if(entry[8] == a.size() * b.size())
					continue;

				ArrayList<int[]> pairlist = new ArrayList<int[]>();
				for(int a1:a){
					for(int a2:b){
						int[] tmp  = {a1,a2};
						pairlist.add(tmp);
					}
				}

				pairlist  = sort_edges_pairlist(pairlist,edge_prob);
				int green=0, red=0;
				for(int[] querypair:pairlist){
					pair t = new pair(querypair[0],querypair[1]);
					pair t1 = new pair(querypair[1], querypair[0]);

					boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1], 0, 0);
					if(!queried_edge_map.containsKey(t)){
						queries++;
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


						queried_edge_map.put(t1, output[1]);
						queried_edge_map.put(t, output[1]);

					}
					if(!fresh_queried_edge_map.containsKey(t)){
						if(output[1]){
							prob_curr *= r_t_g;
							pg *= (1 - g_t_r);
							pr *= r_t_g;
							green++;

						}else{
							red++;
							pg *=g_t_r;
							pr *= 1 - r_t_g;

						}
						fresh_queried_edge_map.put(t, output[1]);
						fresh_queried_edge_map.put(t1, output[1]);
					}

					if(prob_curr<=prob_wanted ){
						break;
					}
					if(pr*1.0/(pr+pg)>this.confidence){
						break;
					}

				}

				if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
					int pos=0,neg=0;
					for(int x:a){
						for(int y:b){
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}


					a.addAll(b);
					component newtmp = new component(a);
					set_clusters.set(i, newtmp);
					ArrayList<Integer> clrlist = new ArrayList<Integer>();
					component clrtmp = new component(clrlist);
					set_clusters.set(j, clrtmp);
					true_pos+=pos;
					false_pos+=neg;
					
					break;
				}else{
					;//if(entry[3]>100)
					// /	System.out.println("not merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
				}

			}


		}
		double precision = true_pos*1.0/g_edges;
		double recall = true_pos*1.0/(true_pos+false_pos);
		this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));
	}
	public void regularize(Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, int g_edges){

		while(true){

			boolean changed_anycluster = false;
			ArrayList<int[]> sizelist = new ArrayList<int[]>();
			for(int i=0;i<set_clusters.size();i++){
				int[] tp = {i,set_clusters.get(i).get_component().size()};
				sizelist.add(tp);
			}
			Collections.sort(sizelist, new Comparator<int[]>() {
				public int compare(int[] o1, int[] o2) {
					int s1 = o1[1]; int s2 = o2[1];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});


			for(int[] clust : sizelist){
				int i=clust[0];
				//for(int i=0;i<set_clusters.size();i++){
				ArrayList<Integer> curr_comp =set_clusters.get(i).get_component();
				if(curr_comp.size()==1)
					continue;

				ArrayList<Integer> deleted = new ArrayList<Integer>();
				double wanted = 1.0/Math.pow(Math.exp(1)*(curr_comp.size()), this.beta);
				deleted.clear();

				ArrayList<double[]> confidenceList = new ArrayList<double[]>(); 

				for(int a : curr_comp){

					double prob = 1;
					double sim = 0;
					double pr=1.0,pg=1.0;
					for(int b : curr_comp){
						if(a==b)
							continue;
						pair t = new pair(a,b);
						if(queried_edge_map.containsKey(t)){
							if(queried_edge_map.get(t)){
								prob *= (r_t_g);
								pg *= (1 - g_t_r);
								pr *= (r_t_g);
							}else{
								pg *=g_t_r;
								pr *= 1 - r_t_g;
							}
						}
						sim+=edge_prob.get(t);
					}
					sim = sim/(curr_comp.size()-1);
					double[] node = {prob,a,pr,pg};
					confidenceList.add(node);
				}
				Collections.sort(confidenceList, new Comparator<double[]>() {
					public int compare(double[] o1, double[] o2) {
						double s1 = o1[0]; double s2 = o2[0];
						if (s1 != s2)
							return (s1 > s2 ? -1 : 1);
						else
							return 0;
					}
				});


				for(double[] node : confidenceList){
					double prob = node[0];
					int a = (int) node[1];
					double pr = node[2];
					double pg = node[3];

					if(prob > wanted ){
						ArrayList<Integer> tmp_comp = new ArrayList<Integer>();
						tmp_comp.addAll(curr_comp);

						tmp_comp  = sort_edges(tmp_comp,a,edge_prob);
						for(int q:tmp_comp){
							if(q==a)
								continue;
							pair t  = new pair(a,q);
							if(queried_edge_map.containsKey(t))
								continue;
							boolean[] output =  query_edge_prob(oracle, gt, q, a, 0, 0);
							if(!queried_edge_map.containsKey(t)){
								queries++;
								double precision = true_pos*1.0/g_edges;
								double recall = true_pos*1.0/(true_pos+false_pos);
								if(true_pos!=0)	
									this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

								pair t1 = new pair(a,q);
								queried_edge_map.put(t1, output[1]);
								queried_edge_map.put(t, output[1]);
								if(output[1]){
									prob *= r_t_g;
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *= g_t_r;
									pr *= 1 - r_t_g;
								}
							}
							if(prob<=wanted)
								break;
							if( pr*1.0/(pr+pg) > this.confidence)
								break;
						}
						if(prob <= wanted )
							;//System.out.println("Need more questions for "+a+" "+prob+" "+wanted);
						else {//if( pr*1.0/(pr+pg) > 0.5) {//
							deleted.add(a);
							for(int k:curr_comp){
								if( !deleted.contains(k) ){
									if(gt.get(a).equals(gt.get(k))){
										true_pos--;
									}
									else{
										false_pos--;
										//System.out.println("Improving precision");
									}	
								}
							}
							//System.out.println("Please remove "+a+" "+prob+" "+wanted+" "+los+" "+gain+" "+pr*1.0/(pr+pg)+" "+g+" "+r);
						}

					}
				}
				ArrayList<Integer> new_comp = new ArrayList<Integer>();
				if(deleted.size()>0)
					changed_anycluster = true;

				for(int n1: curr_comp){
					if(!deleted.contains(n1))
						new_comp.add(n1);	
				}
				component tmpcomp = new component(new_comp);

				this.set_clusters.set(i, tmpcomp);

			}
			if(!changed_anycluster)
				break;
		}

	}
	public void EdgeExpOrdering(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		while(true){
			List<double[]> probList = new ArrayList<double[]>();

			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					int num_q=0;
					double pg = 1.0, pr=1.0,prob_curr=1.0;
					double prob = 0.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									prob_curr  *= (r_t_g);
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;

								}
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(prob == 0)
						continue;
					if(num_q==a.size()*b.size())
						continue;

					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(prob==0.0)
						continue;
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				{

					double prob_curr = entry[9];
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}

					pairlist  = sort_edges_pairlist(pairlist,edge_prob);

					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);

							if(output[1]){
								prob_curr *= r_t_g;
							}

							if(output[1]){
								pg *= (1 - g_t_r);
								pr *= r_t_g;

							}else{
								pg *=g_t_r;
								pr *= 1 - r_t_g;

							}

						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						break;
					}
				}

			}

		}
	}

	public void EdgeEdgeExpOrdering(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		while(true){
		
			double precision1 = true_pos*1.0/g_edges;
			double recall1 = true_pos*1.0/(true_pos+false_pos);
			if(2*precision1*recall1/(precision1+recall1) > 0.9)
				break;
			if(queries > 8000)
				break;
			List<double[]> probList = new ArrayList<double[]>();

			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int num_q=0;
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0,prob_curr=1.0;
					double prob = 0.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									prob_curr  *= (r_t_g);
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;

								}
							}

							prob+=edge_prob.get(t);
							//System.out.println(x+" "+y+" "+prob+" "+a.size()+" "+b.size());
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q==a.size()*b.size())
						continue;

					prob = prob*1.0/(a.size()*b.size());

					prob = Math.round(prob*100)*1.0/100;
					if(prob==0)
						continue;
					if(pr*1.0/(pr+pg) > this.confidence){
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			//System.out.println(probList.size());
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				

					double prob_curr = entry[9];
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}

					pairlist  = sort_edges_pairlist(pairlist,edge_prob);
					boolean first = true;
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);

							if(output[1]){
								prob_curr *= r_t_g;
							}

							if(output[1]){
								pg *= (1 - g_t_r);
								pr *= r_t_g;

							}else{
								pg *=g_t_r;
								pr *= 1 - r_t_g;

							}

						}
						if(entry[0]>=0.5 && first && output[1]){
							prob_wanted = 0.999;
							break;
						}else if(entry[0]<=0.5 && first && !output[1]){
							break;
						}
						first = false;
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//if(neg > 1000)
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						break;
					}
				

			}

		}
		//this.ouput_print.println("done with edge ordering");
	}
	public void edgeOrdering(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0,prob_curr=1.0;
					double prob = 0.0;
					int num_q=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								if(queried_edge_map.get(t)){
									prob_curr  *= (r_t_g);
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;

								}
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(prob==0)
						continue;
					if(num_q>0)
						continue;
					if(num_q==a.size()*b.size())
						continue;
					if(pg<1)
						continue;
					if(pr<1)
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				{

					double prob_curr = entry[9];
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];
					//if(pr<1 || pg<1)
					//	System.out.println("something is wrong ****************************");
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}

					pairlist  = sort_edges_pairlist(pairlist,edge_prob);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);

							if(output[1]){
								prob_curr *= r_t_g;
								pg *= (1 - g_t_r);
								pr *= r_t_g;

							}else{
								pg *=g_t_r;
								pr *= 1 - r_t_g;

							}

						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}
						break;
					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						break;
					}

				}

			}

		}
	}
	public void nodeOrdering(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){
		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;

		while(num_green*1.0/queries >= theta || queries <=5){
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);
				/*if(num_green*1.0/queries < 0.3 && queries > 5){
					finalbreak=true;
					break;
				}*/

				//double num_query = current.size();
				current  = sort_edges(current,max,edge_prob);

				double prob_curr = 1.0;
				double prob_wanted = 0.9999;//Math.pow(r_to_g,num_wanted);

				//List<Integer> tmp = new ArrayList<Integer>();
				//tmp = pickNRandom(current,(int)num_query);

				for(int q : current){

					pair t = new pair(q,max);
					//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
					boolean[] output =  query_edge_prob(oracle, gt, q, max,0,0);

					if(!queried_edge_map.containsKey(t)){
						queries++;
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

						pair t1 = new pair(max,q);
						queried_edge_map.put(t1, output[1]);
						queried_edge_map.put(t, output[1]);
					}

					if(output[1]){
						num_green++;
						prob_curr *= r_t_g;
					}

					break;
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
							//pair t = new pair(i,max); 
							//System.out.println("added a wrong node"+edge_prob.get(t)+" "+current.size()+" "+max+" "+i+" "+num_g+" "+red+" "+prob_curr+" "+prob_wanted);
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}
				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}
		//System.out.println("done with everything it is");
	}
	public void NodeNodeExpOrdering(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){
		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;
		//	tau = (int) (((Math.log(graph.num_nodes())/Math.log(2)))/2);

		while(num_green*1.0/queries >= theta || queries <=5){
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}

			//System.out.println(max);
			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}


			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit


			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				//math.ceil for landmarks
				//this.ouput_print.println("prob "+comp[0]*1.0/current.size()+" "+comp[1]+" "+max);
				double sim = comp[0]*1.0/current.size();
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);


				current  = sort_edges(current,max,edge_prob);

				//This is needed to consider deterministic settings
				//				current  = sort_edges(current,max,edge_prob);
				double prob_curr = 1.0;
				double prob_wanted = 0.9999;//Math.pow(r_to_g,num_wanted);

				double pr =1.0, pg=1.0;
				boolean first = true;
				for(int q : current){

					pair t = new pair(q,max);
					//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
					boolean[] output =  query_edge_prob(oracle, gt, q, max,0,0);

					//this.ouput_print.println(q+" "+max+" "+output[1]+" "+output[0]);
					if(!queried_edge_map.containsKey(t)){
						queries++;
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

						pair t1 = new pair(max,q);
						queried_edge_map.put(t1, output[1]);
						queried_edge_map.put(t, output[1]);
					}

					if(output[1]){
						num_green++;
						prob_curr *= r_t_g;
						pg *= (1 - g_t_r);
						pr *= r_t_g;

					}
					else {
						pg *=g_t_r;
						pr *= 1 - r_t_g;
					}

					if(sim>=0.5 && first && output[1]){
						prob_wanted = 0.999;
						break;	
					}else if(sim < 0.5 && first && !output[1]){
						break;
					}else{
						prob_wanted = 1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
					}

					first = false;

					if(pr*1.0/(pr+pg) > this.confidence){
						break;
					}
					if(prob_curr<=prob_wanted){
						break;
					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
							//pair t = new pair(i,max); 
							//System.out.println("added a wrong node"+edge_prob.get(t)+" "+current.size()+" "+max+" "+i+" "+num_g+" "+red+" "+prob_curr+" "+prob_wanted);
						}
					}
					if(!current.contains(max))
						current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}




				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);


			if(processed_nodes.size()==graph.num_nodes())
				break;

		}
	}
	public void nodeOrderingExp(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){
		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;
		while(num_green*1.0/queries >= theta || queries <=5){
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}
			//System.out.println("u is "+max+" "+processed_nodes.size());

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);

				continue;
			}


			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				//System.out.println("avg "+comp[0]*1.0/current.size());
				//math.ceil for landmarks
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
				if(prob_wanted < Math.pow(r_t_g, current.size()))
					prob_wanted = Math.pow(r_t_g, current.size())+0.00001;

				double pr=1.0, pg=1.0;


				current  = sort_edges(current,max,edge_prob);
				for(int q : current){
					{
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max,0,0);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_green++;
							prob_curr *= r_t_g;
							pg *= (1 - g_t_r);
							pr *= r_t_g;

						}
						else {
							pg *=g_t_r;
							pr *= 1 - r_t_g;

						}

						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}



				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;

		}
	}
	public void add_noise(double prob, Graph graph, HashMap<pair,Boolean>  oracle, HashMap<Integer, Integer> gt){


		if(oraclenoisetype == 1){
			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					boolean ret[] = query_edge_prob(oracle, gt, i,  j,0,0);
					pair tmp = new pair(i,j);
					pair tmp1 = new pair(j,i);
					double rand = generator.nextDouble();
					if(rand < prob){
						if(ret[0]){
							this.oracle.put(tmp, false);//  (tmp)
							this.oracle.put(tmp1, false);//  (tmp)	
						}else{
							this.oracle.put(tmp, true);//  (tmp)
							this.oracle.put(tmp1, true);//  (tmp)
						}
					}else{
						if(ret[0]){
							this.oracle.put(tmp, true);//  (tmp)
							this.oracle.put(tmp1, true);//  (tmp)	
						}else{
							this.oracle.put(tmp, false);//  (tmp)
							this.oracle.put(tmp1, false);//  (tmp)
						}
					}
				}
			}
		}else if(oraclenoisetype==2){
			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					boolean ret[] = query_edge_prob(oracle, gt, i,  j,0,0);
					pair tmp = new pair(i,j);
					pair tmp1 = new pair(j,i);
					if(ret[0]==ret[1]){
						//Change with probability prob
						double rand = generator.nextDouble();
						if(rand <= prob){
							if(ret[1]){
								this.oracle.put(tmp1, false);//  (tmp)
								this.oracle.put(tmp, false);//  (tmp)	
							}else{
								this.oracle.put(tmp1, true);//  (tmp)
								this.oracle.put(tmp, true);//  (tmp)
							}
						}
					}else{
						double rand = generator.nextDouble();
						if(rand >= prob){
							if(ret[1]){
								this.oracle.put(tmp1, false);//  (tmp)
								this.oracle.put(tmp, false);//  (tmp)	
							}else{
								this.oracle.put(tmp1, true);//  (tmp)
								this.oracle.put(tmp, true);//  (tmp)
							}
						}
					}
				}
			}
		}

		/*
				if(ret[0]==ret[1]){
					//Change with probability prob
					double rand = Math.random();
					if(rand <= prob){
						if(ret[1]){
							this.answers.put(tmp1, 0);//  (tmp)
							this.answers.put(tmp, 0);//  (tmp)	
						}else{
							this.answers.put(tmp1, 1);//  (tmp)
							this.answers.put(tmp, 1);//  (tmp)
						}
					}
				}else{
					double rand = Math.random();
					if(rand >= prob){
						if(ret[1]){
							this.answers.put(tmp1, 0);//  (tmp)
							this.answers.put(tmp, 0);//  (tmp)	
						}else{
							this.answers.put(tmp1, 1);//  (tmp)
							this.answers.put(tmp, 1);//  (tmp)
						}
					}
				}*/

		this.r_t_g = prob;
		this.g_t_r = prob;
		//measure the r to g and g to r errors now
		//			Noise in oracle answers
		//Noise 1 : Generate all answers with known error probability
		//Noise 2 : Flip the correct asnwers with prob p
		//Noise 3 : Flip correct answer with prob p and incorrect with prob 1 - p

		//Noise in edge probability 
		//1) Mapping to 0 and 1 with some probability
		// If the edge is green and prob < 0.5, I flip with prob 1 - p and similarly for red
		//If edge is green with prob > 0.5, I flip with prob p.
		//2) Mapping to 1 - prob, and prob with probability p
	}
	double get_noise_val(int u, int v, HashMap<Integer, Integer> gt, double p){


		if(noiseEdgeProbType ==1){
			double rand = generator.nextDouble();
			if(gt.get(u).equals(gt.get(v)) && p >=0.5){
				if(rand <= edgeProbNoiseVal){
					return 0.0;
				}else return 1.0;	
			}else if(gt.get(u).equals(gt.get(v)) && p < 0.5){
				if(rand >= edgeProbNoiseVal){
					return 1.0;
				}else return 0.0;	
			}else if((!gt.get(u).equals(gt.get(v))) && p < 0.5){
				if(rand <= edgeProbNoiseVal){
					return 1.0;
				}else return 0.0;	
			}else if((!gt.get(u).equals(gt.get(v))) && p >= 0.5){
				if(rand >= edgeProbNoiseVal){
					return 0.0;
				}else return 1.0;	
			}

		}else if(noiseEdgeProbType==2){
			double rand = generator.nextDouble();
			if(gt.get(u).equals(gt.get(v)) && p >=0.5){
				if(rand <= edgeProbNoiseVal){
					return 1-p;
				}else return p;	
			}else if(gt.get(u).equals(gt.get(v)) && p < 0.5){
				if(rand >= edgeProbNoiseVal){
					return 1-p;
				}else return p;	
			}else if((!gt.get(u).equals(gt.get(v))) && p < 0.5){
				if(rand <= edgeProbNoiseVal){
					return 1-p;
				}else return p;	
			}else if((!gt.get(u).equals(gt.get(v))) && p >= 0.5){
				if(rand >= edgeProbNoiseVal){
					return 1-p;
				}else return p;	
			}

		}else{
			double rand = generator.nextDouble();
			if(gt.get(u).equals(gt.get(v))){
				if(rand <= edgeProbNoiseVal){
					return 0.0;
				}else return 1.0;	
			}else {
				if(rand <= edgeProbNoiseVal){
					return 1.0;
				}else return 0.0;	
			}


		}

		return 0.0;
	}

	public boolean[] query_edge_prob(HashMap<pair,Boolean>  oracle, HashMap<Integer, Integer> gt, int u, int v, double r_to_g, double g_to_r){
		boolean ret[] = {false, false};
		pair tmp = new pair(u,v);

		if(oracle.get(tmp))
			ret[1]=true;
		else
			ret[1]=false;
		/*
		if (gt.get(u).equals(gt.get(v))){
			if(Math.random() >= g_to_r){
				ret[1] = true;
			}
			ret[0]=true;
		}else{
			if(Math.random() < r_to_g){
				ret[1] = true;
			};
		}
		return ret;
		 */
		/*

		if(this.answers.containsKey(tmp)){

			int tmps = this.answers.get(tmp);
			ret[1] =  (tmps==1);
			/*
			int r = 0;
			for(int a : tmps){
				if(a==1)
					r++;
				else
					r--;
			}

			ret[1] = (this.answers.get(tmp).get(this.curr_ans.get(tmp))==1);
			this.curr_ans.put(tmp, (curr_ans.get(tmp)+1)%5);
			this.curr_ans.put(tmp1, (curr_ans.get(tmp1)+1)%5);
			if(r>0)
				ret[1]  = true;
		}else{
			System.out.println("SOMETHING IS WRONG HERE**************************"+u+" "+v);
			ret[1] = gt.get(u).equals(gt.get(v));
		}
		 */
		//ret[1]=false;
		//Ground truth
		if (gt.get(u).equals(gt.get(v))){
			ret[0]=true;
		}

		return ret;
	}

	public static List<Integer> pickNRandom(List<Integer> lst, int n) {
		List<Integer> copy = new LinkedList<Integer>(lst);
		Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));

		Collections.shuffle(copy,newgen);
		List<Integer> copy_new = new LinkedList<Integer>();
		/*int i=1;
		    copy_new.add(copy.get(0));
		    int j=1;
		    while(i<n){

		    	int i1 = copy.get(j);
		    	int j1=0;
		    	boolean is_edge=false;
		    	while(j1<copy_new.size()){
		    		pair tmp = new pair(copy_new.get(j1),i1);
		    		if(queried_edge_map.containsKey(tmp)){
		    			if(queried_edge_map.get(tmp)){
		    				copy_new.add(i1);
		    				j++;
		    				is_edge=true;
		    				break;
		    			}

		    		}
		    		j1++;
		    	}
		    	if(is_edge)
		    	i++;
		    	else j++;
		    	if(j==copy.size())
		    		break;
		    }
		 */
		if(copy_new.size()<n){
			copy_new = copy.subList(0,n);
		}

		return copy_new;
	}

	double get_benefit(int u,  Map<pair, Double> edge_prob){

		int iter = 0;
		double max_ben = 0;
		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			for(int n : nodes){
				//if(u==n)
				//System.out.println(u+" "+n+" "+nodes.size());;
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
			}
			if(prob > max_ben){
				max_ben = prob;
			}
			iter++;
		}

		return max_ben;
	}

	public ArrayList<double[]> get_benefit_component(int u,  Map<pair, Double> edge_prob){
		ArrayList<double[]> comp_lst = new ArrayList<double[]>();


		int iter = 0;
		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			for(int n : nodes){
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
			}
			double[] entry = {prob,iter};
			comp_lst.add(entry);
			iter++;
		}




		Collections.sort(comp_lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[0]; double s2 = o2[0];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});
		return comp_lst;
	}

	public HashMap<pair,Boolean> print_edges(HashMap<Integer, Integer> gt, Graph graph, PrintStream out,  int iter){

		HashMap<pair,Boolean> queried_edge_map = new HashMap<pair,Boolean>();

		int n1 = 0,n2 = 0;
		try{
			PrintStream edge_prob_true, edge_prob_false;

			edge_prob_true = new PrintStream ("../answers/edge_prob"+(r_t_g)+"_"+(g_t_r)+"_true"+iter);
			edge_prob_false = new PrintStream ("../answers/edge_prob"+(r_t_g)+"_"+(g_t_r)+"_false"+iter);
			//System.out.println("AAAA");
			while(n1<graph.num_nodes()){
				n2=n1+1;
				while(n2<graph.num_nodes()){
					pair tmp1 = new pair(n1,n2);
					pair tmp2 = new pair(n2,n1);
					if (gt.get(n1).equals(gt.get(n2))){
						if(unique){
							int t=0;
							for(int i=0;i<num_unique;i++){
								if( generator.nextDouble() >= g_t_r){
									t++;
								}
							}
							if(t>num_unique/2){
								queried_edge_map.put(tmp1,true);
								queried_edge_map.put(tmp2,true);
								edge_prob_true.println(n1+" "+n2);
							}
							else{
								queried_edge_map.put(tmp1,false);
								queried_edge_map.put(tmp2,false);
								edge_prob_false.println(n1+" "+n2);
							}
						}else{
							double rand = generator.nextDouble();
							if( rand >= g_t_r){
								queried_edge_map.put(tmp1,true);
								queried_edge_map.put(tmp2,true);
								edge_prob_true.println(n1+" "+n2);
								//System.out.println("printing");

							}
							else{
								//System.out.println("false" + rand);

								queried_edge_map.put(tmp1,false);
								queried_edge_map.put(tmp2,false);
								edge_prob_false.println(n1+" "+n2);
							}
						}

					}else{
						if(unique){
							int t=0;
							for(int i=0;i<num_unique;i++){
								if( generator.nextDouble() <= r_t_g){
									t++;
								}
							}
							if(t>num_unique/2){
								queried_edge_map.put(tmp1,true);
								queried_edge_map.put(tmp2,true);
								edge_prob_true.println(n1+" "+n2);
							}
							else{
								queried_edge_map.put(tmp1,false);
								queried_edge_map.put(tmp2,false);
								edge_prob_false.println(n1+" "+n2);
							}
						}else{
							if(generator.nextDouble() <= r_t_g){
								queried_edge_map.put(tmp1,true);
								queried_edge_map.put(tmp2,true);
								edge_prob_true.println(n1+" "+n2);
							}
							else{
								queried_edge_map.put(tmp1,false);
								queried_edge_map.put(tmp2,false);
								edge_prob_false.println(n1+" "+n2);
							}
						}


					}
					n2++;
				}
				n1++;
			}


			edge_prob_true.close();
			edge_prob_false.close();

		} catch (Exception e) {
			System.out.println("Exception raised");
		}
		return queried_edge_map;
	}
	public HashMap<pair,Boolean> read_edges(HashMap<Integer, Integer> gt, Graph graph, PrintStream out, int iter){


		HashMap<pair,Boolean> oracle_edges = new HashMap<pair,Boolean>();
		int n1 = 0,n2 = 0;
		try{
			FileReader edge_prob_true, edge_prob_false;

			edge_prob_true = new FileReader ("answers/edge_prob"+(r_t_g)+"_"+(g_t_r)+"_true"+iter);
			edge_prob_false = new FileReader ("answers/edge_prob"+(r_t_g)+"_"+(g_t_r)+"_false"+iter);
			String line;
			BufferedReader true_reader = new BufferedReader(edge_prob_true);


			while((line = true_reader.readLine()) != null) {
				String[]  numb = line.split(" ",2);
				n1 = Integer.parseInt(numb[0]);
				n2 = Integer.parseInt(numb[1]);
				pair tmp1 = new pair(n1,n2);
				pair tmp2 = new pair(n2,n1);
				oracle_edges.put(tmp1,true);
				oracle_edges.put(tmp2,true);
				//System.out.println(line);

			}   



			BufferedReader false_reader = new BufferedReader(edge_prob_false);


			while((line = false_reader.readLine()) != null) {
				String[]  numb = line.split(" ",2);
				n1 = Integer.parseInt(numb[0]);
				n2 = Integer.parseInt(numb[1]);
				pair tmp1 = new pair(n1,n2);
				pair tmp2 = new pair(n2,n1);
				oracle_edges.put(tmp1,false);
				oracle_edges.put(tmp2,false);
				//System.out.println(line);

			}  

			// Always close files.
			true_reader.close(); 
			false_reader.close();

			edge_prob_true.close();
			edge_prob_false.close();

		} catch (Exception e) {
			System.out.println("Exception raised");
		}
		return oracle_edges;
	}

	public void mergeClustersOld(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){


		Map<pair,Integer> already_done = new HashMap<pair,Integer>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					pair t1 = new pair(i,j);
					if(already_done.containsKey(t1))
						continue;
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int queried=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								queried++;
								if(queried_edge_map.get(t)){
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - (r_t_g);

								}

							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					prob = prob*1.0/(a.size()*b.size());
					if(queried>0)
						continue;
					if(pr*1.0/(pr+pg) > this.confidence)
						continue;
					
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg};
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				pair t11 = new pair(i,j);
				already_done.put(t11,1);


				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				{

					double num_query = 100;
					//TODO : CHANGE THIS ACCORDING TO ALPHA


					if(num_query > a.size())
						num_query=  a.size();

					if(num_query > b.size())
						num_query=  b.size();



					double prob_curr = 1.0;
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					int num_g=0,red=0;
					double pr=1.0,pg=1.0;//entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}

					pairlist  = sort_edges_pairlist(pairlist,edge_prob);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_g++;
							prob_curr *= r_t_g;
						}
						else 
							red++;

						if(output[1]){
							pg *= (1 - g_t_r);
							pr *= r_t_g;

						}else{
							pg *=g_t_r;
							pr *= 1 - r_t_g;

						}
						if(prob_curr<=prob_wanted && pg*1.0/(pr+pg)>0.5 && num_g > red){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}
						break;

					}

					if((prob_curr<= prob_wanted &&  pg*1.0/(pr+pg)>0.5 && num_g > red )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						//if(neg>10)
						//	this.ouput_print.println("A"+a.size()+" "+b.size()+" "+false_pos+" "+num_g+" "+red+" "+num_wanted+" "+prob_wanted+" "+prob_curr);
						//System.out.println("Increased recall by"+pos+" "+neg);
						break;
					}else{
						already_done.put(t11,1);
					}

				}

			}

		}
	}
	public boolean bfs(double[][] rgraph, int s, int t, Graph graph){
		parentlist.clear();
		HashMap<Integer,Integer> visited = new HashMap<Integer,Integer>();
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(s);
		visited.put(s, 1);
		parentlist.put(s, -1);
		while (!queue.isEmpty()){
			int u = queue.poll();
			for(int v = 0; v<graph.num_nodes();v++){
				if(visited.containsKey(v)){
					if(visited.get(v)==1)
						continue;
				}
				if(rgraph[u][v]>0){
					queue.add(v);
					parentlist.put(v, u);
					visited.put(v,1);
				}
			}
		}
		if(visited.containsKey(t)){
			if(visited.get(t)==1)
				return true;
		}
		return false;
	}
	public void dfs(double rGraph[][], int s, boolean visited[], Graph graph)
	{
		visited[s] = true;
		for (int i = 0; i < graph.num_nodes(); i++)
			if (rGraph[s][i] >0 && !visited[i])
				dfs(rGraph, i, visited, graph);
	}
	public void minCut( Graph graph, Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, double g_edges){
		int i1 = 0;
		//System.out.println("called mincut");
		while(true){
			if(i1>=set_clusters.size())
				break;
			double density = 0;
			int num_edges = 0;
			//for(int i1=0;i1<set_clusters.size();i1++)
			{
				ArrayList<Integer> nodes = set_clusters.get(i1).get_component();
				/*int qu=0;
			for(int a:nodes){
				for(int b:nodes){
					pair tmp = new pair(a,b);
					if(queried_edge_map.containsKey(tmp))
						qu++;
				}
			}
			int num_q_wanted = (int) (nodes.size() * Math.log(nodes.size()*Math.exp(1))*1.0/Math.log(1.0/r_t_g)); 
			num_q_wanted -= qu/2;
			this.ouput_print.println(i1+" "+num_q_wanted+" "+qu+" "+nodes.size());
			for(int i=0;i<num_q_wanted;){
				Collections.shuffle(nodes);
				int n1 = nodes.get(0);
				int n2 = nodes.get(1);
				pair t = new pair(n1,n2);
				pair t1 = new pair(n2,n1);
				if(queried_edge_map.containsKey(t))
					continue;
				else{
					boolean[] output =  query_edge_prob(oracle, gt, n1, n2, 0, 0);
					queried_edge_map.put(t, output[1]);
					queried_edge_map.put(t1, output[1]);
					i++;
				}
			}
				 */

				double[][] rGraph = new double [graph.num_nodes()][graph.num_nodes()];
				int u,v;
				for (u = 0; u < graph.num_nodes(); u++){
					for (v = u+1; v < graph.num_nodes(); v++){	        	
						if(nodes.contains(u) && nodes.contains(v)){
							pair tmp = new pair(u,v);
							if(queried_edge_map.containsKey(tmp)){
								if(queried_edge_map.get(tmp)){
									rGraph[u][v] = - Math.log( r_t_g);//graph[u][v];
									rGraph[v][u] = - Math.log( r_t_g);//graph[u][v];
									density+= - Math.log( r_t_g);//graph[u][v];

								}
								num_edges++;
							}
						}
					}
				}
				//this.ouput_print.println("density is "+i1+" "+density+" "+nodes.size() * Math.log(Math.exp(1)*nodes.size()));
				//System.out.println("trying with"+i1+" "+density+" "+nodes.size()+" "+num_edges+" "+nodes.size() * Math.log(Math.exp(1)*nodes.size()));
				if(num_edges == nodes.size()*(nodes.size()-1)/2){
					i1++;
					continue;
				}

				if(density >= nodes.size() * Math.log(Math.exp(1)*nodes.size())){

					i1++;
					continue;

				}
				if(nodes.size()<2){
					i1++;
					continue;
				}
				Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));

				Collections.shuffle(nodes,newgen);
				int s = nodes.get(0);
				int t = nodes.get(1);
				//System.out.println("trying for "+i1+" "+s+" "+t+" "+nodes.size()+" "+Math.log(Math.exp(1)*nodes.size()));
				double flow = 0;
				while (bfs(rGraph, s, t, graph))
				{


					double path_flow = 1000000;
					for (v=t; v!=s; v=parentlist.get(v)){

						u = parentlist.get(v);
						//System.out.println("here"+v+" "+u+" "+rGraph[u][v]);
						path_flow = Math.min(path_flow, rGraph[u][v]);
					}
					if (path_flow==1000000)
						break;
					for (v=t; v != s; v=parentlist.get(v)){
						u = parentlist.get(v);
						rGraph[u][v] -= path_flow;
						rGraph[v][u] += path_flow;
					}

					//System.out.println("here"+s+" "+t+" "+nodes.size()+" "+flow+" "+path_flow);
					flow+=path_flow;

				}
				//this.ouput_print.println("floe is "+i1+" "+flow);
				boolean[] visited = new boolean[graph.num_nodes()];
				dfs(rGraph, s, visited, graph);
				ArrayList<Integer> a= new ArrayList<Integer>();
				ArrayList<Integer> b= new ArrayList<Integer>();
				int oneside = 0, other = 0;
				for (int i :nodes){
					if(visited[i] ){
						oneside++;
						a.add(i);
					}
					else{
						other++;
						b.add(i);
					}
				}
				if(flow >= Math.min(oneside, other)*Math.log(Math.exp(1)*nodes.size()) ){
					i1++;
					continue;
				}

				//System.out.println(i1+"flow is "+flow+" "+oneside+" "+other+" "+queries+" "+Math.min(oneside, other)*Math.log(Math.exp(1)*nodes.size()));
				//a is one side and b is other side Now we try to query node with minimum degree....
				ArrayList<double[]> degree_a= new ArrayList<double[]>();
				for(int n:a){
					double degree = 0;

					for(int n2:nodes){
						pair tmp = new pair(n,n2);
						if(queried_edge_map.containsKey(tmp)){
							if(queried_edge_map.get(tmp))
								degree+= - Math.log(r_t_g);
						}
					}
					double[] tmpdeg  = {(double)n,degree};
					degree_a.add(tmpdeg);
				}

				ArrayList<double[]> degree_b= new ArrayList<double[]>();
				for(int n:b){
					double degree = 0;

					for(int n2:nodes){
						pair tmp = new pair(n,n2);
						if(queried_edge_map.containsKey(tmp)){
							if(queried_edge_map.get(tmp))
								degree+= - Math.log(r_t_g);
						}
					}
					double[] tmpdeg  = {(double)n,degree};
					degree_b.add(tmpdeg);
				}

				double pr = 1.0,pg=1.0;
				for(int a1:a){
					for(int a2:b){
						pair tmp = new pair(a1,a2);
						if(queried_edge_map.containsKey(tmp)){
							if(queried_edge_map.get(tmp)){
								pg *= (1 - g_t_r);
								pr *= (r_t_g);

							}else{
								pg *= g_t_r;
								pr *= 1 - r_t_g;
							}
						}
					}
				}
				//this.ouput_print.println(a.size()+" "+b.size()+" cut");
				//while 1
				//pick the first elements and query if not queried
				//Update degree and update prob, pg, pr
				//break if criterion met
				int start_node_a=0;
				int start_node_b=0;
				boolean couldnotquerymore =  false;
				while(true){
					//sort two degrees
					int n1 = (int)degree_a.get(start_node_a)[0];
					int n2 = (int)degree_b.get(start_node_b)[0];
					pair tmp = new pair(n1,n2);
					pair tmp1 = new pair(n2,n1);
					if(queried_edge_map.containsKey(tmp)){
						start_node_b++;
						if(start_node_b==degree_b.size()){
							start_node_b=0;
							start_node_a++;
						}
					}else{
						couldnotquerymore =  true;
						queries++;
						boolean[] output =  query_edge_prob(oracle, gt, n1, n2, 0, 0);
						queried_edge_map.put(tmp, output[1]);
						queried_edge_map.put(tmp1, output[1]);
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

						if(output[1]){
							//System.out.println("green edge");
							double[] newdeg={n1,degree_a.get(start_node_a)[1]-1*Math.log((r_t_g)) };
							degree_a.set(start_node_a, newdeg);
							double[] newdegb={n2,degree_b.get(start_node_b)[1]-1*Math.log(r_t_g) };
							degree_b.set(start_node_b, newdegb);
							flow += -1*Math.log((r_t_g));
							pg *= (1 - g_t_r);
							pr *= (r_t_g);

							start_node_a=0;
							start_node_b=0;
							Collections.sort(degree_a, new Comparator<double[]>() {
								public int compare(double[] o1, double[] o2) {
									double s1 = o1[1]; double s2 = o2[1];
									if (s1 != s2)
										return (s1 > s2 ? 1 : -1);
									else
										return 0;
								}
							});

							Collections.sort(degree_b, new Comparator<double[]>() {
								public int compare(double[] o1, double[] o2) {
									double s1 = o1[1]; double s2 = o2[1];
									if (s1 != s2)
										return (s1 > s2 ? 1 : -1);
									else
										return 0;
								}
							});


						}else{
							pg *=g_t_r;
							pr *= 1 - (r_t_g);

						}

					}
					if(flow >= Math.min(a.size(), b.size())*Math.log(Math.exp(1)*nodes.size()) )
						break;
					if(pr*1.0/(pr+pg) > this.confidence){
						//this.ouput_print.println("found a partition "+i1);
						component acomp =new component(a);
						component bcomp =new component(b);
						for(int a11:a){
							for(int a12:b){
								if(gt.get(a11).equals(gt.get(a12)))
									true_pos--;
								else
									false_pos--;
							}
						}
						set_clusters.set(i1, acomp);
						set_clusters.add(bcomp);

						break;
					}
					if(start_node_a==degree_a.size())
						break;
				}

				if(!couldnotquerymore)
					i1++;



			}

		}
		return;

	}

	public ArrayList<double[]> get_component_lst(int u,  Map<pair, Double> edge_prob){
		ArrayList<double[]> comp_lst = new ArrayList<double[]>();


		int iter = 0;

		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			double max = -1;
			int maxnode = -1;
			double min = 1.0;
			for(int n : nodes){
				//if(u==n)
					//System.out.println("here u "+u);
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
				if(edge_prob.get(ed)>max){
					max = edge_prob.get(ed);
					maxnode = n;
				}
				if(edge_prob.get(ed)<min)
					min = edge_prob.get(ed);
			}
			//if(maxnode==0)
			//	System.out.println(max+" "+min);
			double[] entry = {prob,iter, max,min,maxnode};
			comp_lst.add(entry);
			iter++;

		}


		//Max

		Collections.sort(comp_lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[2]; double s2 = o2[2];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});
		return comp_lst;
	}

	public void nodeOrderingOld(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);

		do
		{
			//Get the elements of the window...
			int max=-1;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				max=u;
				break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_component_lst(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean added = false;
			for(double[] comp : comp_list){
				boolean[] output =  query_edge_prob(oracle, gt, (int)comp[4], max,0.0,0.0);
				pair t = new pair(max,(int)comp[4]);
				pair t1 = new pair((int)comp[4],max);
				if(!queried_edge_map.containsKey(t)){
					queries++;
					double precision = true_pos*1.0/g_edges;
					double recall = true_pos*1.0/(true_pos+false_pos);
					if(true_pos!=0)	
						this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


					queried_edge_map.put(t1, output[1]);
					queried_edge_map.put(t, output[1]);
				}
				if(output[1]){
					ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
							//pair t = new pair(i,max); 
							//System.out.println("added a wrong node"+edge_prob.get(t)+" "+current.size()+" "+max+" "+i+" "+num_g+" "+red+" "+prob_curr+" "+prob_wanted);
						}
					}
					//System.out.println(true_pos+" "+false_pos);

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;

					break;

				}
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(true);
		//System.out.println("done with everything it is");
	}
	public void nodeOrderingOldWithExp(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;

		do
		{
			//Get the elements of the window...
			int max=-1;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				max=u;
				break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_component_lst(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
				//if(prob_wanted < Math.pow(r_t_g, current.size()))
				//prob_wanted = Math.pow(r_t_g, current.size())+0.00001;

				double pr=1.0, pg=1.0;


				current  = sort_edges(current,max,edge_prob);
				for(int q : current){
					{
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max,0.0,0.0);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_green++;
							{
								prob_curr  *= r_t_g;//(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-g_t_r);//(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= r_t_g;//(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}
						}else{
							{
								pg *= g_t_r;//(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-r_t_g);//(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);	
							}	
						}

						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted || num_green==current.size()){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}

			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(true);
		//System.out.println("done with everything it is");
	}

	public void nodeOrderingOldWithAdpExp(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;

		do
		{
			//Get the elements of the window...
			int max=-1;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				max=u;
				break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_component_lst(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean added = false;
			for(double[] comp : comp_list){
				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
				//if(prob_wanted < Math.pow(r_t_g, current.size()))
				//prob_wanted = Math.pow(r_t_g, current.size())+0.00001;

				double pr=1.0, pg=1.0;


				current  = sort_edges(current,max,edge_prob);
				boolean first = true;
				for(int q : current){
					{	
						if(first)
							q = (int) comp[4];
						//System.out.println(q+" "+max+" "+processed_nodes.contains(max)+" "+comp);
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max,0.0,0.0);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_green++;
							{
								prob_curr  *= r_t_g;//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-g_t_r);//(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= r_t_g;//(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}
						}else{
							{
								pg *= (g_t_r);//(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-r_t_g);//(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);	
							}	
						}
						double sim  = edge_prob.get(t);

						if(sim>=0.5 && first && output[1]){
							prob_wanted = 0.999;
							break;	
						}else if(sim < 0.5 && first && !output[1]){
							break;
						}else{
							prob_wanted = 1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
						}

						first = false;


						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted || num_green==current.size()){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}

			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(true);
		//System.out.println("done with everything it is");
	}
	public void edgeOrderingOld(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					double max = 0.0,maxu=-1,maxv=-1;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								if(queried_edge_map.get(t)){
									pg *= (1 - g_t_r);
									pr *= r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;

								}
								num_q++;
							}
							if(edge_prob.get(t) > max){
								max = edge_prob.get(t);
								maxu = x;
								maxv = y;
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;

						}
					}
					if(prob==0)
						continue;
					if(num_q>0)
						continue;
					if(pg<1)
						continue;
					if(pr<1)
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()),max,maxu,maxv};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			//System.out.println(probList.size());
			if(probList.size()==0)
				break;
			Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));

			Collections.shuffle(probList,newgen);


			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[8]; double s2 = o2[8];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});
			int ii=0;
			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				ii++;
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);
				//System.out.println("here"+ii);
				{

					double prob_curr = 1.0;
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
					{
						pair t = new pair((int)entry[9],(int)entry[10]);
						boolean[] output =  query_edge_prob(oracle, gt, (int)entry[9],(int)entry[10], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair((int)entry[10],(int)entry[9]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);

							if(output[1]){
								prob_curr *= r_t_g;
							}

						}
						//System.out.println(prob_curr+" "+prob_wanted+" "+output[1]+" "+entry[8]+" "+(int)entry[9]+" "+(int)entry[10]+" "+edge_prob.get(t));
					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						ArrayList<Integer>a = set_clusters.get((int)entry[1]).get_component();
						ArrayList<Integer>b = set_clusters.get((int)entry[2]).get_component();

						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						break;
					}

				}

			}

		}
	}
	public void edgeOrderingOldExp(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					double max = 0.0,maxu=-1,maxv=-1;
					double prob_curr = 1.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								if(queried_edge_map.get(t)){
									pg *= (1 - g_t_r);
									pr *= r_t_g;
									prob_curr*=r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;

								}
								num_q++;
							}
							if(edge_prob.get(t) > max){
								max = edge_prob.get(t);
								maxu = x;
								maxv = y;
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;

						}
					}
					if(prob==0)
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;
					if(num_q==a.size()*b.size())
						continue;
					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()),max,maxu,maxv,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			//System.out.println(probList.size());
			if(probList.size()==0)
				break;
			Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));

			Collections.shuffle(probList,newgen);

			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[8]; double s2 = o2[8];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});
			int ii=0;
			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				ArrayList<Integer>a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer>b = set_clusters.get((int)entry[2]).get_component();

				ii++;
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);
				//System.out.println("here"+ii);

				{

					double prob_curr = entry[11];
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					double pr=entry[5],pg=entry[6];

					pairlist  = sort_edges_pairlist(pairlist,edge_prob);

					for(int[] querypair:pairlist)

					{
						pair t = new pair((int)querypair[0],(int)querypair[1]);
						boolean[] output =  query_edge_prob(oracle, gt, (int)entry[9],(int)entry[10], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair((int)querypair[1],(int)querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);

							if(output[1]){
								prob_curr *= r_t_g;
								pg *= (1 - g_t_r);
								pr *= r_t_g;

							}else{
								pg *=g_t_r;
								pr *= 1 - r_t_g;

							}

						}
						if(prob_curr<=prob_wanted)
							break;
						if(pr*1.0/(pr+pg) > confidence)
							break;
						//System.out.println(prob_curr+" "+prob_wanted+" "+output[1]+" "+entry[8]+" "+(int)entry[9]+" "+(int)entry[10]+" "+edge_prob.get(t));
					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;

						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						break;
					}

				}

			}

		}
	}

	public void edgeOrderingOldWithAdpExp(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					double max = -1,maxu=-1,maxv=-1;
					double prob_curr = 1.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								if(queried_edge_map.get(t)){
									pg *= (1 - g_t_r);
									pr *= r_t_g;
									prob_curr*=r_t_g;
								}else{
									pg *=g_t_r;
									pr *= 1 - r_t_g;

								}
								num_q++;
							}else{
								if(edge_prob.get(t) > max){
									max = edge_prob.get(t);
									maxu = x;
									maxv = y;
								}

							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;

						}
					}
					if(prob==0)
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;
					if(num_q==a.size()*b.size())
						continue;
					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()),max,maxu,maxv,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			//System.out.println(probList.size());
			if(probList.size()==0)
				break;
			Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));

			Collections.shuffle(probList,newgen);

			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[8]; double s2 = o2[8];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});
			int ii=0;
			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				ArrayList<Integer>a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer>b = set_clusters.get((int)entry[2]).get_component();

				ii++;
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);
				//System.out.println("here"+ii);

				{

					double prob_curr = entry[11];
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					double pr=entry[5],pg=entry[6];

					pairlist  = sort_edges_pairlist(pairlist,edge_prob);
					boolean first = true;
					for(int[] querypair:pairlist)
					{
						if(first){
							querypair[0]=(int) entry[9];
							querypair[1]=(int) entry[10];

						}
						pair t = new pair((int)querypair[0],(int)querypair[1]);
						//System.out.println(entry[0]+" "+pr+" "+pg+" "+(int)querypair[0]+" "+(int)querypair[1]+" "+a.size()+" "+b.size()+" "+prob_curr);
						//System.out.println((int)querypair[0]+" "+(int)querypair[1]+" "+a.size()+" "+b.size()+" "+prob_curr);
						boolean[] output =  query_edge_prob(oracle, gt, (int)querypair[0],(int)querypair[1], 0, 0);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair((int)querypair[1],(int)querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);

							if(output[1]){
								prob_curr *= r_t_g;
								pg *= (1 - g_t_r);
								pr *= r_t_g;

							}else{
								pg *=g_t_r;
								pr *= 1 - r_t_g;

							}

						}
						if(first){
							if(entry[8]>=0.5 && output[1])
								prob_wanted = 0.999;
							if(entry[8]<0.5 && !output[1])
								pg = 0.0;

						}
						first = false;
						if(prob_curr<=prob_wanted)
							break;
						if(pr*1.0/(pr+pg) > confidence)
							break;
						//System.out.println(prob_curr+" "+prob_wanted+" "+output[1]+" "+entry[8]+" "+(int)entry[9]+" "+(int)entry[10]+" "+edge_prob.get(t));
					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;

						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						break;
					}

				}

			}

		}
	}

	public int[] process( HashMap<Integer, Integer> gt   , PrintStream out,
			Graph graph,TreeMap  <Integer, Double > expected_sorted,
		 int g_limit, Map      <Integer, List<double[]>> adj_weighted, double g_edges, int iter) throws Exception {

		//System.out.println("total green is "+g_edges);
		this.N = graph.num_nodes();

		if(!file_present){
			oracle = print_edges(gt,graph, out, iter);
		}
		else{
			oracle = read_edges(gt,graph, out, iter);
		}

		//System.out.println("In function process and prepared the edge answers");

		Map<pair, Double> edge_prob = new HashMap<pair, Double>();
		int node_id = 0;

		double min=1.0;
		while(node_id<graph.num_nodes()){
			for (double[] edge1 : adj_weighted.get(node_id)) {   
				pair temp= new pair((int)edge1[0],(int)edge1[1]);	
				pair temp1= new pair((int)edge1[1],(int)edge1[0]);
				if(noisySparsity) {
					if(edge1[2] < sparsityThreshold) {
						countSparsity++;
						edge1[2]=0;
					}
				}else {
					if(!gt.get((int)edge1[0]).equals(gt.get((int)edge1[1])) && edge1[2] < sparsityThreshold) {
						countSparsity++;
						edge1[2]=0;
					}
				}
				if(gt.get((int)edge1[0]).equals(gt.get((int)edge1[1])) && edge1[2]<min)
					min  = edge1[2];
				edge_prob.put(temp, edge1[2]);
				edge_prob.put(temp1, edge1[2]);
				prob_list.add(edge1);
			}
			node_id++;
		}
		//System.out.println("sparsity count is "+countSparsity);
		Collections.sort(prob_list, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[2]; double s2 = o2[2];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});

		

		//System.out.println("Edges have been  made");
		//System.out.println("total green is "+g_edges);



		//Set the empty ones to 0
		for(int node_id1=0;node_id1<graph.num_nodes();node_id1++){
			for(int node_id2=0;node_id2<graph.num_nodes();node_id2++){
				pair t = new pair(node_id1,node_id2);
				pair t1 = new pair(node_id2,node_id1);
				if(edge_prob.containsKey(t))
					continue;
				edge_prob.put(t1, 0.0);
				edge_prob.put(t, 0.0);
			}
		}

		//System.out.println("Edges made and similarities have been set");



		ArrayList<Node> graph_nodes =new ArrayList<Node>();
		for(int it=0;it<graph.num_nodes();it++){
			Node tmp = new Node();
			graph_nodes.add(tmp);
		}


		if(pipeline == 1){

			NodeNodeExpOrdering( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
		
			
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}

			int singlenotdone = 0;
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					singlenotdone++;
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);
				}
			}
			//System.out.println(singlenotdone+" single left out");

			EdgeEdgeExpOrdering(gt,edge_prob,graph_nodes,(int)g_edges);
			
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);

			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
			//System.out.println("Count of sparsity "+countSparsity);
		}else if(pipeline==2){

			//System.out.println("Starting Phase #1");
			nodeOrderingExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);	      		
			
			
			//System.out.println("  Starting queries #2 "+queries);

			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);

				}
			}


			EdgeExpOrdering(gt,edge_prob,graph_nodes,(int)g_edges);

			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

		}else if (pipeline==3){
			//System.out.println("Starting Phase #1");
			nodeOrdering( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);	      		

			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);

				}
			}
			edgeOrdering(gt,edge_prob,graph_nodes,(int)g_edges);

			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

		}else if(pipeline==4){
			nodeOrderingOld( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
		}else if(pipeline==5){
			nodeOrderingOldWithExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if(pipeline==6){
			nodeOrderingOldWithAdpExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if(pipeline==7){
			for(int i=0;i<graph.num_nodes();i++){
				ArrayList<Integer> nodes1 = new ArrayList<Integer>();
				nodes1.add(i);
				component curr_comp1 = new component(nodes1);
				set_clusters.add(curr_comp1);

			}
			edgeOrderingOld(gt,edge_prob,graph_nodes,(int)g_edges);
		}else if(pipeline==8){
			for(int i=0;i<graph.num_nodes();i++){
				ArrayList<Integer> nodes1 = new ArrayList<Integer>();
				nodes1.add(i);
				component curr_comp1 = new component(nodes1);
				set_clusters.add(curr_comp1);

			}
			edgeOrderingOldExp(gt,edge_prob,graph_nodes,(int)g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if(pipeline==9){
			for(int i=0;i<graph.num_nodes();i++){
				ArrayList<Integer> nodes1 = new ArrayList<Integer>();
				nodes1.add(i);
				component curr_comp1 = new component(nodes1);
				set_clusters.add(curr_comp1);

			}
			edgeOrderingOldWithAdpExp(gt,edge_prob,graph_nodes,(int)g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if (pipeline==10){
			//System.out.println("Starting Phase #1");
			nodeOrdering( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);	      		

			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);

				}
			}
			edgeOrdering(gt,edge_prob,graph_nodes,(int)g_edges);
			//this.ouput_print.println("edge over edge now");

		}else if(pipeline == 12){

			NodeNodeExpOrdering( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
			//sanityCheck(gt);
			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}

			int singlenotdone = 0;
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					singlenotdone++;
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);
				}
			}
			//System.out.println(singlenotdone+" single left out");
			//this.ouput_print.println("here edge");
			EdgeEdgeExpOrdering(gt,edge_prob,graph_nodes,(int)g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);

			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if(pipeline==11){

			//System.out.println("Starting Phase #1");
			nodeOrderingExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);	      		

			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);

				}
			}


			EdgeExpOrdering(gt,edge_prob,graph_nodes,(int)g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);

			//this.ouput_print.println("edge over edge now");
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

		}


		return new int[]{0,0};       
	}

	public static void main(String[] args) throws Exception{
		if(args.length < 8){
			System.out.println("Help: Run java fig <folder> <pipeline>   <expansionType><error> <beta> <theta> <confidence> <tau>");
			System.exit(0);
		}
		String folder = args[0];

		r_t_g = Float.parseFloat(args[3]);
		g_t_r = Float.parseFloat(args[3]);
		//Large cluster with a large block having representative token
		//Overlap with many small blocks which are red edges..Could be because of mistakes...

		for(int iter = 1;iter<=10;iter++){
			//System.out.println("Iter is "+iter);

			fig5defgh no  = new fig5defgh();
			no.pipeline = Integer.parseInt(args[1]);
			no.expansionType = Integer.parseInt(args[2]);
			no.beta = Float.parseFloat(args[4]);
			no.theta = Float.parseFloat(args[5]);
			no.confidence = Float.parseFloat(args[6]);


			HashMap<Integer, Integer> gt = new HashMap<Integer,Integer>();

			String gold = "../Data/"+folder+"/gold.txt";
			Scanner scanner = new Scanner(new File(gold));
			{

				while(scanner.hasNextLine()){
					String[] line=scanner.nextLine().split(" ");

					int a1 = Integer.parseInt(line[0]);
					int a2 = Integer.parseInt(line[1]);
					gt.put(a1,a2);

				}
			}


			try {
				String graph_file     = "../Data/"+folder+"/graph.txt";
				Graph graph;
				PrintStream out;
				out = new PrintStream("../output/"+folder+"/output.txt");

				Map      <Integer, List<double[]>> adj_weighted=new HashMap<Integer, List<double[]>>();;

				scanner = new Scanner(new File(graph_file));
				graph = new Graph(scanner.nextInt());
				no.tau  = (int)(Float.parseFloat(args[7])*((Math.log(graph.num_nodes())/Math.log(2))));
				double g_edges = scanner.nextInt();
				int i=0;
				for (;i<graph.num_nodes();i++) {
					adj_weighted.put(i, new ArrayList<double[]>());
				}

				while(scanner.hasNextLine()){
					int u = scanner.nextInt();

					if(u==-1)
						break;
					int v = scanner.nextInt();
					double prob = scanner.nextFloat();
					if(no.noiseEdgeProb)
						prob = no.get_noise_val(u,v,gt,prob);
					double[] edge = {u,v,prob};
					adj_weighted.get(u).add(edge);
					adj_weighted.get(v).add(edge);

				}
				int max = graph.num_nodes();
				for (int u =0; u<graph.num_nodes(); u++) {
					if(gt.containsKey(u))
						continue;
					else{
						gt.put(u, max);
						max++;
					}

				}


				no.answers = new HashMap<pair, Integer>();
				no.curr_ans = new HashMap<pair, Integer>();
				no.ouput_print = new PrintStream ("../output/"+folder+"/output_fscore_"+Integer.toString(iter));

				//System.out.println("Done reading "+adj_weighted.size());

				HashMap<Integer, Double> expected = new HashMap<Integer, Double>();
				for (int u =0; u<graph.num_nodes(); u++) {
					double sum = 0.0;//,sum_square = 0.0;
					for (double[] edge: adj_weighted.get(u)) {
						double s  = edge[2];
						if(no.noisySparsity) {
							if(edge[2] >=no.sparsityThreshold )
								sum      += s;	
						}else {
							if(edge[2] >=no.sparsityThreshold || gt.get((int)edge[0]).equals(gt.get((int)edge[1])))
								sum      += s;	
						}					}
					expected.put(u, sum);

				}
				TreeMap<Integer, Double       > expected_sorted;
				ValueComparator bvc  = new ValueComparator(expected, null);
				expected_sorted = new TreeMap<Integer, Double>(bvc);
				expected_sorted.putAll(expected);
				int g_limit = 300000;

				
				no.process( gt, out,graph,expected_sorted,g_limit , adj_weighted,  g_edges, iter ) ;
			}
			catch(FileNotFoundException ex) {
				System.out.println("Exception in code");            // Always must return something

			}
		}
	}	
}

