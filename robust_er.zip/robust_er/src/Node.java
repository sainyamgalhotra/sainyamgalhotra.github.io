
import java.util.ArrayList;


public class Node {
	int comp_id;
	ArrayList<Integer> green_queried;
	ArrayList<Integer> red_queried;
	public Node(){
		this.comp_id=-1;
		green_queried =new ArrayList<Integer>();
		red_queried  =new ArrayList<Integer>();	
	}
	public void set_com(int comp){
		this.comp_id =  comp;
	}
	public void add_green(int a){
		this.green_queried.add(a);
		
	}
	public void add_red(int a){
		this.red_queried.add(a);
	}
}
