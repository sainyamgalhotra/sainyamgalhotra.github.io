
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;



public class Graph {
    private 		 int[] id;    // id[i] = parent of i
    private 		 int[] sz;    // sz[i] = number of objects in subtree rooted at i
	private Set<Integer>[] ed;	  // edges
	public int g_queries = 0;
	public int r_queries = 0;
    public int N_size;
    /**
     * Initializes an empty union-find data structure with N isolated components 0 through N-1.
     * @throws java.lang.IllegalArgumentException if N < 0
     * @param N the number of objects
     */
    @SuppressWarnings("unchecked")
	public Graph(int N) {
        id = new int[N];
        sz = new int[N];
    	ed = new HashSet[N];
        for (int i = 0; i < N; i++) {
        	ed[i] = new HashSet<Integer>();
            id[i] = i;
            sz[i] = 1;
            //ed[i].add(i);//CHECK PLEASE
        }
        N_size = N;
    }
    public int comp_size(int node){
    	int root = find(node);
    	return sz[root];
    }
 public void remove(int u){
    	
    	id[u]  = u;
    	
    	for(int i=0;i<this.num_nodes();i++){
    		if(ed[i].contains(u)){
    			ed[i].remove(u);
    			sz[i]--;
    		}
    	}
    	ed[u].clear();
    	sz[u]=1;
    	return;
    }
    
    public int num_nodes (){
    	
    	return id.length;
    }
    public Collection<Integer> sizes() {
    	Collection<Integer> comps = new LinkedList<Integer>();
    	for (int i = 0; i < sz.length; i++) {
    		if (id[i] == i) { //is non-trivial root
   				comps.add(sz[i]);
    		}
    	}
    	return comps;
    }
    
    public Collection<Integer> sizes(Collection<Integer> indices) {
    	HashSet<Integer> nontrivials = new HashSet<Integer>();
    	for (int i : indices) {
    		nontrivials.add(this.find(i));
    	}    	
 
    	Collection<Integer> comps = new LinkedList<Integer>();
    	for (int i = 0; i < sz.length; i++) {
    		if (id[i] == i) { //is non-trivial root
    			if (nontrivials.contains(i)) {
    				comps.add(sz[i]);
    			}
    		}
    	}
    	return comps;
    }
    
    public void add_edge(int u, int v){
    	ed[u].add(v);
    	ed[v].add(u);
    	return;
    }
    public boolean is_edge(int u, int v){
    	if(ed[u].contains(v))
    		return true;
    	else return false;
    }
    public  Set<Integer> get_edges (int u){
    	Set<Integer> edge_list = new HashSet<Integer>();
        for(int i:ed[u]){
        	edge_list.add(i);
        }
        return edge_list;
    	
    }
    
    public Set<Integer> nodes (int u){
		
    	
    	int node_id=0;
        Set<Integer> nodes_list = new HashSet<Integer>();

    	while(node_id<N_size){
    		if(united(node_id,u))
    			nodes_list.add(node_id);
    		node_id++;
    	}
    	System.out.println("Size is "+nodes_list.size());
    	return nodes_list;
    	
    	/*int root = find(u);
        nodes_list.add(root);
    	for(int j :ed[root]){
    		nodes_list.add(j);
    	}
    	return nodes_list;
    	*/
    }
    
    /**
     * Returns the component identifier for the component containing site <tt>p</tt>.
     * @param p the integer representing one site
     * @return the component identifier for the component containing site <tt>p</tt>
     * @throws java.lang.IndexOutOfBoundsException unless 0 <= p < N
     */
    public int find(int p) {
        while (p != id[p])
            p = id[p];
        return p;
    }
    
    public int size(int p) {
        int rootP = find(p);

        return sz[rootP];
    }
    
    public boolean is_nt_root(int p) {
    	return id[p] == p;
    }

    /**
     * Are the two sites <tt>p</tt> and <tt>q</tt> in the same component?
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @return <tt>true</tt> if the two sites <tt>p</tt> and <tt>q</tt>
     *    are in the same component, and <tt>false</tt> otherwise
     * @throws java.lang.IndexOutOfBoundsException unless both 0 <= p < N and 0 <= q < N
     */
    public boolean united(int p, int q) {
        return find(p) == find(q);
    }
    
    public boolean connected(int p, int q) {
    	for (int i : ed[find(p)]) {
    		if (united(i, q)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    /**
     * Merges the component containing site<tt>p</tt> with the component
     * containing site <tt>q</tt>.
     * @param p the integer representing one site
     * @param q the integer representing the other site
     * @throws java.lang.IndexOutOfBoundsException unless both 0 <= p < N and 0 <= q < N
     */
    public void union(int p, int q) {
        int rootP = find(p);
        int rootQ = find(q);
        if (rootP == rootQ) return;

        // make smaller root point to larger one
        if   (sz[rootP] < sz[rootQ]) { id[rootP] = rootQ; sz[rootQ] += sz[rootP]; ed[rootQ].addAll(ed[rootP]);  }
        else                         { id[rootQ] = rootP; sz[rootP] += sz[rootQ]; ed[rootP].addAll(ed[rootQ]);  }
        
    }
    
    public int benefit(int p, int q) {
        int rootP = find(p);
        int rootQ = find(q);
        if (rootP == rootQ) return 0;

        // compute benefits in terms of pairs
        return sz[rootQ] * sz[rootP];
    }
    
    public double benefit_clique(int p, HashMap<pair,Double> edge_map, ArrayList<Integer> seen_so_far) {
    	HashMap<Integer, Double> root_sum =  new HashMap<Integer, Double>();
    	HashMap<Integer, Integer> num =  new HashMap<Integer, Integer>();
    	HashMap<Integer, Double> sqr_sum =  new HashMap<Integer, Double>();
    	//take seen so far as input to improve speed
    	for(int i:seen_so_far){
    		if(edge_map.get(new pair(p,i))==null)
    			continue;
    		double tmp = edge_map.get(new pair(p,i));
    		//System.out.println("******SAME");
    		int root = find(i);
    		if(root_sum.get(root)!=null){
        		root_sum.put((Integer)root,tmp+root_sum.get(root) );
        		sqr_sum.put((Integer)root,tmp*tmp + sqr_sum.get(root) );
        		num.put((Integer)root,1 + num.get(root) );
    			
    		}
    		else{
        		root_sum.put((Integer)root,tmp);
        		sqr_sum.put((Integer)root,tmp*tmp  );
        		num.put((Integer)root,1);
    		}
    			
    	}
    	
    	double ben=0.0;
    	double max = 0.0;
    	for(int i:root_sum.keySet()){
    		if(num.get(i)>1){
        		ben = sz[i]*(root_sum.get(i)*root_sum.get(i) - sqr_sum.get(i))*1.0/(num.get(i)*(num.get(i)-1));
        		if(ben>max){
        			max = ben;
        		}
    			
    		}
    			
    	}
    	return max;
    }  
    public void connection(int p, int q) {
        int rootP = find(p);
        int rootQ = find(q);
        assert (rootP != rootQ);
    	
    	ed[rootP].add(q);
    	ed[rootQ].add(p);
    }

	public Graph custom_clone() {
		Graph g = new Graph(this.id.length);

	    for (int i = 0; i < id.length; i++) {
	    	g.id[i] = this.id[i];
	    	g.sz[i] = this.sz[i];
        	g.ed[i] = new HashSet<Integer>();
        	for (int j : this.ed[i]) {
        		g.ed[i].add(j);
        	}
	    }

		return g;
	}
}


