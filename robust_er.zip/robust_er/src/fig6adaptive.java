/**
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;


/**
 * 
 */


public class fig6adaptive {
	int queries=0;
	HashMap<pair,Boolean> oracle = new HashMap<pair,Boolean>();
	ArrayList<component> set_clusters = new ArrayList<component>();
	Map<pair, Boolean> queried_edge_map = new HashMap<pair, Boolean>();
	int true_pos=0;
	int false_pos=0;

	Set<Integer> singleton_nodes = new HashSet<Integer>();
	Set<Integer> changed = new HashSet<Integer>();
	int max_query=0;
	int N;
	boolean print_over =false;
	double theta = 0.3;
	int tau=0;
	double beta=1;
	PrintStream ouput_print;
	Map<pair, Integer> answers;
	Map<pair, Integer> curr_ans;
	double max_r_to_g=0.0;//0.0027397260274/0.9;//0.09523809523809523/0.9;//0.0;
	static double max_g_to_r=0.0;//0.20/0.7;//0.22222222/0.9;//0.10/.4; 
	double confidence=0.95;
	HashMap<Integer,Integer> parentlist=new HashMap<Integer,Integer>();
	ArrayList<double[]> prob_list = new ArrayList<double[]>();
	int pipeline = 1;
	String folder;

	boolean oraclenoise = false;
	double oraclenoiseval = 0.1;
	int oraclenoisetype = 2;

	boolean noiseEdgeProb = false;
	int noiseEdgeProbType=1;
	double edgeProbNoiseValgtor = 0.3;
	double edgeProbNoiseValrtog = 0.0;

	public void mergeClusters(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges){

		Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();

		int num_clust_queried = 0;
		int logn = (int) ((int)Math.log(graph_nodes.size())/Math.log(2));

		while(true){

			if(num_clust_queried >= (logn*(logn-1))/2)
				break;

			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double benefit = 0.0;
					int num_q=0;

					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(fresh_queried_edge_map.containsKey(t)){
								num_q++;
								if(fresh_queried_edge_map.get(t)){
									if(oraclenoise){
										pg *= (1 - max_g_to_r);
										pr *= (max_r_to_g);	
									}else{
										pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									}
								}else{
									if(oraclenoise){
										pg *=max_g_to_r;
										pr *= (1 - max_r_to_g);
									}else{
										pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);

									}
								}	
							}
							benefit+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}

					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {benefit,i,j,pos,neg,pr,pg, benefit/(a.size()*b.size()), num_q};
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				if(num_clust_queried >= (logn*(logn-1))/2)
					break;


				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();


				num_clust_queried++;
				double prob_curr = 1.0;
				int size = Math.min(a.size(), b.size());
				double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
				prob_wanted = Math.pow(prob_wanted, size);
				double pr=entry[5],pg=entry[6];

				if(pr*1.0/(pr+pg) > this.confidence)
					continue;
				if(entry[8] == a.size() * b.size())
					continue;

				ArrayList<int[]> pairlist = new ArrayList<int[]>();
				for(int a1:a){
					for(int a2:b){
						int[] tmp  = {a1,a2};
						pairlist.add(tmp);
					}
				}
				Collections.shuffle(pairlist);
				for(int[] querypair:pairlist){
					pair t = new pair(querypair[0],querypair[1]);
					pair t1 = new pair(querypair[1], querypair[0]);

					boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
					if(!queried_edge_map.containsKey(t)){
						queries++;
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


						queried_edge_map.put(t1, output[1]);
						queried_edge_map.put(t, output[1]);

					}
					if(!fresh_queried_edge_map.containsKey(t)){
						if(output[1]){
							if(oraclenoise){
								prob_curr  *= (max_r_to_g);
								pg *= (1 - max_g_to_r);
								pr *= (max_r_to_g);
							}else{
								prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}
						}else{
							if(oraclenoise){
								pg *=max_g_to_r;
								pr *= 1 - (max_r_to_g);	
							}else{
								pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-get_r_to_g(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);	
							}
						}	
						fresh_queried_edge_map.put(t, output[1]);
						fresh_queried_edge_map.put(t1, output[1]);
					}

					if(prob_curr<=prob_wanted ){
						break;
					}
					if(pr*1.0/(pr+pg)>this.confidence){
						break;
					}

				}

				if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
					int pos=0,neg=0;
					for(int x:a){
						for(int y:b){
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}


					a.addAll(b);
					component newtmp = new component(a);
					set_clusters.set(i, newtmp);
					ArrayList<Integer> clrlist = new ArrayList<Integer>();
					component clrtmp = new component(clrlist);
					set_clusters.set(j, clrtmp);
					true_pos+=pos;
					false_pos+=neg;

					//this.ouput_print.println("merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
					break;
				}else{
					;//if(entry[3]>100)
						//System.out.println("not merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
				}

			}


		}
		double precision = true_pos*1.0/g_edges;
		double recall = true_pos*1.0/(true_pos+false_pos);
		this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));
	}
	public void regularize(Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, int g_edges){

		while(true){

			boolean changed_anycluster = false;
			ArrayList<int[]> sizelist = new ArrayList<int[]>();
			for(int i=0;i<set_clusters.size();i++){
				int[] tp = {i,set_clusters.get(i).get_component().size()};
				sizelist.add(tp);
			}
			Collections.sort(sizelist, new Comparator<int[]>() {
				public int compare(int[] o1, int[] o2) {
					int s1 = o1[1]; int s2 = o2[1];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});


			for(int[] clust : sizelist){
				int i=clust[0];
				//for(int i=0;i<set_clusters.size();i++){
				ArrayList<Integer> curr_comp =set_clusters.get(i).get_component();
				if(curr_comp.size()==1)
					continue;

				ArrayList<Integer> deleted = new ArrayList<Integer>();
				double wanted = 1.0/Math.pow(Math.exp(1)*(curr_comp.size()), this.beta);
				deleted.clear();

				ArrayList<double[]> confidenceList = new ArrayList<double[]>(); 

				for(int a : curr_comp){

					double prob = 1;
					double sim = 0;
					double pr=1.0,pg=1.0;
					for(int b : curr_comp){
						if(a==b)
							continue;
						pair t = new pair(a,b);
						if(queried_edge_map.containsKey(t)){
							if(queried_edge_map.get(t)){
								if(oraclenoise){
									prob  *= (max_r_to_g);
									pg *= (1 - max_g_to_r);
									pr *= (max_r_to_g);
								}else{
									prob  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}
							}else{
								if(oraclenoise){
									pg *=max_g_to_r;
									pr *= 1 - (max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
								}
							}	
						}
						sim+=edge_prob.get(t);
					}
					sim = sim/(curr_comp.size()-1);
					double[] node = {prob,a,pr,pg};
					confidenceList.add(node);
				}
				Collections.sort(confidenceList, new Comparator<double[]>() {
					public int compare(double[] o1, double[] o2) {
						double s1 = o1[0]; double s2 = o2[0];
						if (s1 != s2)
							return (s1 > s2 ? -1 : 1);
						else
							return 0;
					}
				});


				for(double[] node : confidenceList){
					double prob = node[0];
					int a = (int) node[1];
					double pr = node[2];
					double pg = node[3];

					if(prob > wanted ){
						ArrayList<Integer> tmp_comp = new ArrayList<Integer>();
						tmp_comp.addAll(curr_comp);
						Collections.shuffle(tmp_comp);
						for(int q:tmp_comp){
							if(q==a)
								continue;
							pair t  = new pair(a,q);
							if(queried_edge_map.containsKey(t))
								continue;
							boolean[] output =  query_edge_prob(oracle, gt, q, a);
							if(!queried_edge_map.containsKey(t)){
								queries++;
								double precision = true_pos*1.0/g_edges;
								double recall = true_pos*1.0/(true_pos+false_pos);
								if(true_pos!=0)	
									this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

								pair t1 = new pair(a,q);
								queried_edge_map.put(t1, output[1]);
								queried_edge_map.put(t, output[1]);
								if(output[1]){
									if(oraclenoise){
										prob  *= (max_r_to_g);
										pg *= (1 - max_g_to_r);
										pr *= (max_r_to_g);	
									}else{
										prob  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
										pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									}
								}else{
									if(oraclenoise){
										pg *=max_g_to_r;
										pr *= 1 - (max_r_to_g);
									}else{
										pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
									}
								}	
							}
							if(prob<=wanted)
								break;
							if( pr*1.0/(pr+pg) > this.confidence)
								break;
						}
						if(prob <= wanted )
							;//System.out.println("Need more questions for "+a+" "+prob+" "+wanted);
						else {//if( pr*1.0/(pr+pg) > 0.5) {//
							deleted.add(a);
							for(int k:curr_comp){
								if( !deleted.contains(k) ){
									if(gt.get(a).equals(gt.get(k))){
										true_pos--;
									}
									else{
										false_pos--;
										//System.out.println("Improving precision");
									}	
								}
							}
							//System.out.println("Please remove "+a+" "+prob+" "+wanted+" "+los+" "+gain+" "+pr*1.0/(pr+pg)+" "+g+" "+r);
						}

					}
				}
				ArrayList<Integer> new_comp = new ArrayList<Integer>();
				if(deleted.size()>0)
					changed_anycluster = true;

				for(int n1: curr_comp){
					if(!deleted.contains(n1))
						new_comp.add(n1);	
				}
				component tmpcomp = new component(new_comp);

				this.set_clusters.set(i, tmpcomp);

			}
			if(!changed_anycluster)
				break;
		}

	}
	public void EdgeEdgeExpOrdering(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){

		while(true){
			List<double[]> probList = new ArrayList<double[]>();

			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					int num_q=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									if(oraclenoise){
										pg *= (1 - max_g_to_r);
										pr *= (max_r_to_g);
									}else{
										pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									}
								}else{
									if(oraclenoise){
										pg *=max_g_to_r;
										pr *= 1 - (max_r_to_g);
									}else{
										pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
									}
								}	
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q==a.size()*b.size())
						continue;

					prob = prob*1.0/(a.size()*b.size());
					if(prob==0.0)
						continue;
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]+" "+entry[8]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				{

					double prob_curr = 1.0;
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];
					//System.out.println(" "+pr*1.0/(pr+pg));
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Collections.shuffle(pairlist);
					boolean first = true;
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));
							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);

							if(output[1]){
								if(oraclenoise){
									prob_curr  *= (max_r_to_g);
									pg *= (1 - max_g_to_r);
									pr *= (max_r_to_g);
								}else{
									prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
								}
							}else{
								if(oraclenoise){
									pg *=max_g_to_r;
									pr *= 1 - (max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);g);	
								}

							}	

						}
						if(entry[0]>=0.5 && first && output[1]){
							prob_wanted = 0.999;
							break;
						}else if(entry[0]<=0.5 && first && !output[1]){
							break;
						}
						first = false;
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}
						//if(neg > 50)
						//this.ouput_print.println("here ti was "+a.size()+" "+b.size()+" "+entry[0]+" "+num_g+" "+prob_curr+" "+num_r+" "+num_g);

						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						break;
					}
				}

			}

		}
	}

	public void EdgeExpOrdering(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){

		while(true){
			List<double[]> probList = new ArrayList<double[]>();

			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					int num_q=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									if(oraclenoise){
										pg *= (1 - max_g_to_r);
										pr *= (max_r_to_g);	
									}else{
										pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
									}
								}else{
									if(oraclenoise){
										pg *=max_g_to_r;
										pr *= 1 - (max_r_to_g);	
									}else{
										pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
									}
								}	
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}

					if(num_q==a.size()*b.size())
						continue;

					prob = prob*1.0/(a.size()*b.size());
					if(prob==0.0)
						continue;

					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size())};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				{

					double prob_curr = 1.0;
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Collections.shuffle(pairlist);

					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);

							if(output[1]){
								if(oraclenoise){
									prob_curr  *= (max_r_to_g);
									pg *= (1 - max_g_to_r);
									pr *= (max_r_to_g);
								}else{
									prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
								}
							}else{
								if(oraclenoise){
									pg *=max_g_to_r;
									pr *= 1 - (max_r_to_g);	
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
								}
							}	


						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						break;
					}
				}

			}

		}
	}

	public void edgeOrdering(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								if(queried_edge_map.get(t)){
									if(oraclenoise){
										pg *= (1 - max_g_to_r);
										pr *= (max_r_to_g);	
									}else{
										pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									}
								}else{
									if(oraclenoise){
										pg *=max_g_to_r;
										pr *= 1 - (max_r_to_g);	
									}else{
										pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
										pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
									}
								}	
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q>0)
						continue;
					if(num_q==a.size()*b.size())
						continue;

					if(pg<1)
						continue;
					if(pr<1)
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(prob==0.0)
						continue;
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob*prob*(a.size()*b.size())};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				{

					double prob_curr = 1.0;
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];
					//if(pr<1 || pg<1)
					//	System.out.println("something is wrong ****************************");
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Collections.shuffle(pairlist);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);

							if(output[1]){
								if(oraclenoise){
									prob_curr  *= (max_r_to_g);
									pg *= (1 - max_g_to_r);
									pr *= (max_r_to_g);	
								}else{
									prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}
							}else{
								if(oraclenoise){
									pg *=max_g_to_r;
									pr *= 1 - (max_r_to_g);	
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
								}
							}	

						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}
						break;
					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						break;
					}

				}

			}

		}
	}

	public void nodeOrdering(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;

		do
		{
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);
				/*if(num_green*1.0/queries < 0.3 && queries > 5){
					finalbreak=true;
					break;
				}*/

				//double num_query = current.size();

				Collections.shuffle(current);

				double prob_curr = 1.0;
				double prob_wanted = 0.9999;//Math.pow(r_to_g,num_wanted);

				//List<Integer> tmp = new ArrayList<Integer>();
				//tmp = pickNRandom(current,(int)num_query);

				for(int q : current){

					pair t = new pair(q,max);
					//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
					boolean[] output =  query_edge_prob(oracle, gt, q, max);

					if(!queried_edge_map.containsKey(t)){
						queries++;
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

						pair t1 = new pair(max,q);
						queried_edge_map.put(t1, output[1]);
						queried_edge_map.put(t, output[1]);
					}

					if(output[1]){
						num_green++;
						if(oraclenoise){
							prob_curr  *= (max_r_to_g);
						}else{
							prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
						}

					}

					break;
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
							//pair t = new pair(i,max); 
							//System.out.println("added a wrong node"+edge_prob.get(t)+" "+current.size()+" "+max+" "+i+" "+num_g+" "+red+" "+prob_curr+" "+prob_wanted);
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}
				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(num_green*1.0/queries >= 0.3 || queries <=5);
		//System.out.println("done with everything it is");
	}

	public double get_r_to_g(double sim){
		if(sim==1.0)
			sim= 0.99;
		double captchas_lst[] = {0.0,0,0,0,0,0,0,0.0, 0.0,0.0,0.0};

		double gym_lst[] = {0.0036,0.0,0.0116,0.0,0.038,0.0,0.0734,0.0, 0.1,0.0};

		double landmarks_lst[] = {0.0,0.0,0.0,0.0,0.0,0.00034,0.0024,0.00317,0.0014,0.00277,0.0};

		double allsports_lst[] = {0.00174206831019,0.00518134715026,0.00803212851406,0.0333333333333,0.0434782608696,0.0,0.111111111111,0.0,0.0,0.0,0.0};

		if(folder.equals("captchas"))
			return captchas_lst[(int)sim*10];
		else if(folder.equals("gym"))
			return gym_lst[(int)sim*10];
		else if (folder.equals("allsports"))
			return allsports_lst[(int)sim*10];
		else
			return landmarks_lst[(int)sim*10];
	}

	public double get_g_to_r(double sim){
		if(sim==1.0)
			sim= 0.99;

		double captchas_lst[] = {0.0,0,0,0,0,0,0.2,0.119, 0.100,0.104};
		double gym_lst[] = {0.22,0.0,0.4242,0.0,0.1944,0.0,0.10606,0.0, 0.0769,0.0273};

		double landmarks_lst[] = {0.0,0.1818,0.22,0.2229,0.2709,0.3039,0.2519,0.14626,0.0604,0.02597};
		double allsports_lst[] = {0.075,0.0,0.0540540540541,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
		if(folder.equals("captchas"))
			return captchas_lst[(int)sim*10];
		else if(folder.equals("gym"))
			return gym_lst[(int)sim*10];
		else if (folder.equals("allsports"))
			return allsports_lst[(int)sim*10];
		else
			return landmarks_lst[(int)sim*10];
	}

	public void NodeNodeExpOrdering(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){
		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;


		do
		{
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}


			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit


			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				//math.ceil for landmarks
				//this.ouput_print.println("prob "+comp[0]*1.0/current.size()+" "+comp[1]+" "+max);
				double sim = comp[0]*1.0/current.size();
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);

				Collections.shuffle(current);

				double prob_curr = 1.0;
				double prob_wanted = 0.9999;//Math.pow(r_to_g,num_wanted);

				double pr =1.0, pg=1.0;
				boolean first = true;
				for(int q : current){

					pair t = new pair(q,max);
					//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
					boolean[] output =  query_edge_prob(oracle, gt, q, max);

					if(!queried_edge_map.containsKey(t)){
						queries++;
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

						pair t1 = new pair(max,q);
						queried_edge_map.put(t1, output[1]);
						queried_edge_map.put(t, output[1]);
					}

					if(output[1]){
						num_green++;
						if(oraclenoise){
							prob_curr  *= (max_r_to_g);
							pg *= (1 - max_g_to_r);
							pr *= (max_r_to_g);
						}else{

							//CHANGE THIS
							prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
						}

					}else{
						if(oraclenoise){
							pg *=max_g_to_r;
							pr *= 1 - (max_r_to_g);
						}else{
							//CHANGE THIS
							pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= 1 - get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);	
						}

					}

					if(sim>=0.5 && first && output[1]){
						prob_wanted = 0.999;
						break;	
					}else if(sim < 0.5 && first && !output[1]){
						break;
					}else{
						prob_wanted = 1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
					}

					first = false;

					if(pr*1.0/(pr+pg) > this.confidence){
						break;
					}
					if(prob_curr<=prob_wanted){
						break;
					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}
					if(!current.contains(max))
						current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;

					break;
				}




				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);


			if(processed_nodes.size()==graph.num_nodes())
				break;

		}while(num_green*1.0/queries >= 0.3 || queries <=5 );
		//this.ouput_print.println("done with this");
	}

	public void nodeOrderingExp(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){
		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;
		do
		{
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}
			//System.out.println("u is "+max+" "+processed_nodes.size());

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);

				continue;
			}


			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				//System.out.println("avg "+comp[0]*1.0/current.size());
				//math.ceil for landmarks
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
				//if(prob_wanted < Math.pow(r_t_g, current.size()))
				//prob_wanted = Math.pow(r_t_g, current.size())+0.00001;

				double pr=1.0, pg=1.0;

				Collections.shuffle(current);
				for(int q : current){
					{
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_green++;
							if(oraclenoise){
								prob_curr  *= (max_r_to_g);
								pg *= (1 - max_g_to_r);
								pr *= (max_r_to_g);
							}else{
								prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}
						}else{
							if(oraclenoise){
								pg *=max_g_to_r;
								pr *= 1 - (max_r_to_g);
							}else{
								pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-get_r_to_g(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);	
							}	
						}

						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}



				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;

		}while(num_green*1.0/queries >= 0.3 || queries <=5 );
	}

	public Map<pair, Double> add_edge_prob_noise(double prob, Graph graph, Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt){
		Map<pair, Double> noisy_edge_prob = new HashMap<pair,Double>();

		if(noiseEdgeProbType ==1){
			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					pair t1 = new pair(i,j);
					pair t2 = new pair(j,i);
					double p = edge_prob.get(t1);
					double rand = Math.random();
					if(gt.get(i).equals(gt.get(j)) && p >=0.5){
						if(rand <= prob){
							noisy_edge_prob.put(t1, 0.0);
							noisy_edge_prob.put(t2, 0.0);
						}else{
							noisy_edge_prob.put(t1, 1.0);
							noisy_edge_prob.put(t2, 1.0);
						}
					}else if(gt.get(i).equals(gt.get(j)) && p < 0.5){
						if(rand >= prob){
							noisy_edge_prob.put(t1, 1.0);
							noisy_edge_prob.put(t2, 1.0);
						}else{
							noisy_edge_prob.put(t1, 0.0);
							noisy_edge_prob.put(t2, 0.0);
						}
					}else if( (! gt.get(i).equals(gt.get(j))) && p >=0.5){
						if(rand >= prob){
							noisy_edge_prob.put(t1, 0.0);
							noisy_edge_prob.put(t2, 0.0);
						}else{
							noisy_edge_prob.put(t1, 1.0);
							noisy_edge_prob.put(t2, 1.0);
						}
					}else{
						if(rand <= prob){
							noisy_edge_prob.put(t1, 1.0);
							noisy_edge_prob.put(t2, 1.0);
						}else{
							noisy_edge_prob.put(t1, 0.0);
							noisy_edge_prob.put(t2, 0.0);
						}
					}

				}
			}
		}else if(noiseEdgeProbType==2){

			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					pair t1 = new pair(i,j);
					pair t2 = new pair(j,i);
					double p = edge_prob.get(t1);
					double rand = Math.random();
					if(gt.get(i).equals(gt.get(j)) && p >=0.5){
						if(rand <= prob){
							noisy_edge_prob.put(t1, 1-p);
							noisy_edge_prob.put(t2, 1-p);
						}else{
							noisy_edge_prob.put(t1, p);
							noisy_edge_prob.put(t2, p);
						}
					}else if(gt.get(i).equals(gt.get(j)) && p < 0.5){
						if(rand >= prob){
							noisy_edge_prob.put(t1, 1-p);
							noisy_edge_prob.put(t2, 1-p);
						}else{
							noisy_edge_prob.put(t1, p);
							noisy_edge_prob.put(t2, p);
						}
					}else if( (! gt.get(i).equals(gt.get(j))) && p >=0.5){
						if(rand >= prob){
							noisy_edge_prob.put(t1, 1-p);
							noisy_edge_prob.put(t2, 1-p);
						}else{
							noisy_edge_prob.put(t1, p);
							noisy_edge_prob.put(t2, p);
						}
					}else{
						if(rand <= prob){
							noisy_edge_prob.put(t1, 1-p);
							noisy_edge_prob.put(t2, 1-p);
						}else{
							noisy_edge_prob.put(t1, p);
							noisy_edge_prob.put(t2, p);
						}
					}

				}
			}
		}else{

			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					pair t1 = new pair(i,j);
					pair t2 = new pair(j,i);
					double rand = Math.random();
					if(gt.get(i).equals(gt.get(j))){
						if(rand <= prob){
							noisy_edge_prob.put(t1, 0.0);
							noisy_edge_prob.put(t2, 0.0);
						}else{
							noisy_edge_prob.put(t1, 1.0);
							noisy_edge_prob.put(t2, 1.0);
						}
					}else{
						if(rand <= prob){
							noisy_edge_prob.put(t1, 1.0);
							noisy_edge_prob.put(t2, 1.0);
						}else{
							noisy_edge_prob.put(t1, 0.0);
							noisy_edge_prob.put(t2, 0.0);
						}
					}

				}
			}
		}


		return noisy_edge_prob;

	}

	public void add_noise(double prob, Graph graph, HashMap<pair,Boolean>  oracle, HashMap<Integer, Integer> gt){


		if(oraclenoisetype == 1){
			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					boolean ret[] = query_edge_prob(oracle, gt, i,  j);
					pair tmp = new pair(i,j);
					pair tmp1 = new pair(j,i);
					double rand = Math.random();
					if(rand < prob){
						if(ret[0]){
							this.answers.put(tmp, 0);//  (tmp)
							this.answers.put(tmp1, 0);//  (tmp)	
						}else{
							this.answers.put(tmp, 1);//  (tmp)
							this.answers.put(tmp1, 1);//  (tmp)
						}
					}else{
						if(ret[0]){
							this.answers.put(tmp, 1);//  (tmp)
							this.answers.put(tmp1, 1);//  (tmp)	
						}else{
							this.answers.put(tmp, 0);//  (tmp)
							this.answers.put(tmp1, 0);//  (tmp)
						}
					}
				}
			}
		}else if(oraclenoisetype==2){
			for(int i=0;i<graph.num_nodes();i++){
				for(int j=i+1;j<graph.num_nodes();j++){
					boolean ret[] = query_edge_prob(oracle, gt, i,  j);
					pair tmp = new pair(i,j);
					pair tmp1 = new pair(j,i);
					if(ret[0]==ret[1]){
						//Change with probability prob
						double rand = Math.random();
						if(rand <= prob){
							if(ret[1]){
								this.answers.put(tmp1, 0);//  (tmp)
								this.answers.put(tmp, 0);//  (tmp)	
							}else{
								this.answers.put(tmp1, 1);//  (tmp)
								this.answers.put(tmp, 1);//  (tmp)
							}
						}
					}else{
						double rand = Math.random();
						if(rand >= prob){
							if(ret[1]){
								this.answers.put(tmp1, 0);//  (tmp)
								this.answers.put(tmp, 0);//  (tmp)	
							}else{
								this.answers.put(tmp1, 1);//  (tmp)
								this.answers.put(tmp, 1);//  (tmp)
							}
						}
					}
				}
			}
		}

		/*
				if(ret[0]==ret[1]){
					//Change with probability prob
					double rand = Math.random();
					if(rand <= prob){
						if(ret[1]){
							this.answers.put(tmp1, 0);//  (tmp)
							this.answers.put(tmp, 0);//  (tmp)	
						}else{
							this.answers.put(tmp1, 1);//  (tmp)
							this.answers.put(tmp, 1);//  (tmp)
						}
					}
				}else{
					double rand = Math.random();
					if(rand >= prob){
						if(ret[1]){
							this.answers.put(tmp1, 0);//  (tmp)
							this.answers.put(tmp, 0);//  (tmp)	
						}else{
							this.answers.put(tmp1, 1);//  (tmp)
							this.answers.put(tmp, 1);//  (tmp)
						}
					}
				}*/

		this.max_r_to_g = prob;
		max_g_to_r = prob;
		//measure the r to g and g to r errors now
		//			Noise in oracle answers
		//Noise 1 : Generate all answers with known error probability
		//Noise 2 : Flip the correct asnwers with prob p
		//Noise 3 : Flip correct answer with prob p and incorrect with prob 1 - p

		//Noise in edge probability 
		//1) Mapping to 0 and 1 with some probability
		// If the edge is green and prob < 0.5, I flip with prob 1 - p and similarly for red
		//If edge is green with prob > 0.5, I flip with prob p.
		//2) Mapping to 1 - prob, and prob with probability p
	}
	double get_noise_val(int u, int v, HashMap<Integer, Integer> gt, double p){


		if(noiseEdgeProbType ==1){
			double rand = Math.random();
			if(gt.get(u).equals(gt.get(v)) && p >=0.5){
				if(rand <= edgeProbNoiseValgtor){
					return 0.0;
				}else return 1.0;	
			}else if(gt.get(u).equals(gt.get(v)) && p < 0.5){
				if(rand >= edgeProbNoiseValgtor){
					return 1.0;
				}else return 0.0;	
			}else if((!gt.get(u).equals(gt.get(v))) && p < 0.5){
				if(rand <= edgeProbNoiseValrtog){
					return 1.0;
				}else return 0.0;	
			}else if((!gt.get(u).equals(gt.get(v))) && p >= 0.5){
				if(rand >= edgeProbNoiseValrtog){
					return 0.0;
				}else return 1.0;	
			}

		}else if(noiseEdgeProbType==2){
			double rand = Math.random();
			if(gt.get(u).equals(gt.get(v)) && p >=0.5){
				if(rand <= edgeProbNoiseValgtor){
					return 1-p;
				}else return p;	
			}else if(gt.get(u).equals(gt.get(v)) && p < 0.5){
				if(rand >= edgeProbNoiseValgtor){
					return 1-p;
				}else return p;	
			}else if((!gt.get(u).equals(gt.get(v))) && p < 0.5){
				if(rand <= edgeProbNoiseValrtog){
					return 1-p;
				}else return p;	
			}else if((!gt.get(u).equals(gt.get(v))) && p >= 0.5){
				if(rand >= edgeProbNoiseValrtog){
					return 1-p;
				}else return p;	
			}

		}else{
			double rand = Math.random();
			if(gt.get(u).equals(gt.get(v))){
				if(rand <= edgeProbNoiseValgtor){
					return 0.0;
				}else return 1.0;	
			}else {
				if(rand <= edgeProbNoiseValrtog){
					return 1.0;
				}else return 0.0;	
			}


		}

		return 0.0;
	}

	public boolean bfs(double[][] rgraph, int s, int t, Graph graph){
		parentlist.clear();
		HashMap<Integer,Integer> visited = new HashMap<Integer,Integer>();
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(s);
		visited.put(s, 1);
		parentlist.put(s, -1);
		while (!queue.isEmpty()){
			int u = queue.poll();
			for(int v = 0; v<graph.num_nodes();v++){
				if(visited.containsKey(v)){
					if(visited.get(v)==1)
						continue;
				}
				if(rgraph[u][v]>0){
					queue.add(v);
					parentlist.put(v, u);
					visited.put(v,1);
				}
			}
		}
		if(visited.containsKey(t)){
			if(visited.get(t)==1)
				return true;
		}
		return false;
	}
	public void dfs(double rGraph[][], int s, boolean visited[], Graph graph)
	{
		visited[s] = true;
		for (int i = 0; i < graph.num_nodes(); i++)
			if (rGraph[s][i] >0 && !visited[i])
				dfs(rGraph, i, visited, graph);
	}

	public void minCut( Graph graph, Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, double g_edges){
		int i1 = 0;
		//System.out.println("called mincut");
		while(true){
			if(i1>=set_clusters.size())
				break;
			double density = 0;
			int num_edges = 0;
			//for(int i1=0;i1<set_clusters.size();i1++)
			{
				ArrayList<Integer> nodes = set_clusters.get(i1).get_component();
				double[][] rGraph = new double [graph.num_nodes()][graph.num_nodes()];
				int u,v;
				for (u = 0; u < graph.num_nodes(); u++){
					for (v = u+1; v < graph.num_nodes(); v++){	        	
						if(nodes.contains(u) && nodes.contains(v)){
							pair tmp = new pair(u,v);
							if(queried_edge_map.containsKey(tmp)){
								if(queried_edge_map.get(tmp)){
									rGraph[u][v] = - Math.log( max_r_to_g*edge_prob.get(tmp));//graph[u][v];
									rGraph[v][u] = - Math.log( max_r_to_g*edge_prob.get(tmp));//graph[u][v];
									density+= - Math.log( max_r_to_g);//graph[u][v];

								}
								num_edges++;
							}
						}
					}
				}
				//this.ouput_print.println("density is "+i1+" "+density+" "+nodes.size() * Math.log(Math.exp(1)*nodes.size()));
				//System.out.println("trying with"+i1+" "+density+" "+nodes.size()+" "+num_edges+" "+nodes.size() * Math.log(Math.exp(1)*nodes.size()));
				if(num_edges == nodes.size()*(nodes.size()-1)/2){
					i1++;
					continue;
				}

				if(density >= nodes.size() * Math.log(Math.exp(1)*nodes.size())){

					i1++;
					continue;

				}
				if(nodes.size()<2){
					i1++;
					continue;
				}
				Collections.shuffle(nodes);
				int s = nodes.get(0);
				int t = nodes.get(1);
				//System.out.println("trying for "+i1+" "+s+" "+t+" "+nodes.size()+" "+Math.log(Math.exp(1)*nodes.size()));
				double flow = 0;
				while (bfs(rGraph, s, t, graph))
				{


					double path_flow = 1000000;
					for (v=t; v!=s; v=parentlist.get(v)){

						u = parentlist.get(v);
						//System.out.println("here"+v+" "+u+" "+rGraph[u][v]);
						path_flow = Math.min(path_flow, rGraph[u][v]);
					}
					if (path_flow==1000000)
						break;
					for (v=t; v != s; v=parentlist.get(v)){
						u = parentlist.get(v);
						rGraph[u][v] -= path_flow;
						rGraph[v][u] += path_flow;
					}

					//System.out.println("here"+s+" "+t+" "+nodes.size()+" "+flow+" "+path_flow);
					flow+=path_flow;

				}
				//this.ouput_print.println("floe is "+i1+" "+flow);
				boolean[] visited = new boolean[graph.num_nodes()];
				dfs(rGraph, s, visited, graph);
				ArrayList<Integer> a= new ArrayList<Integer>();
				ArrayList<Integer> b= new ArrayList<Integer>();
				int oneside = 0, other = 0;
				for (int i :nodes){
					if(visited[i] ){
						oneside++;
						a.add(i);
					}
					else{
						other++;
						b.add(i);
					}
				}
				if(flow >= Math.min(oneside, other)*Math.log(Math.exp(1)*nodes.size()) ){
					i1++;
					continue;
				}

				//System.out.println(i1+"flow is "+flow+" "+oneside+" "+other+" "+queries+" "+Math.min(oneside, other)*Math.log(Math.exp(1)*nodes.size()));
				//a is one side and b is other side Now we try to query node with minimum degree....
				ArrayList<double[]> degree_a= new ArrayList<double[]>();
				for(int n:a){
					double degree = 0;

					for(int n2:nodes){
						pair tmp = new pair(n,n2);
						if(queried_edge_map.containsKey(tmp)){
							if(queried_edge_map.get(tmp))
								degree+= - Math.log(max_r_to_g*edge_prob.get(tmp));
						}
					}
					double[] tmpdeg  = {(double)n,degree};
					degree_a.add(tmpdeg);
				}

				ArrayList<double[]> degree_b= new ArrayList<double[]>();
				for(int n:b){
					double degree = 0;

					for(int n2:nodes){
						pair tmp = new pair(n,n2);
						if(queried_edge_map.containsKey(tmp)){
							if(queried_edge_map.get(tmp))
								degree+= - Math.log(max_r_to_g*edge_prob.get(tmp));
						}
					}
					double[] tmpdeg  = {(double)n,degree};
					degree_b.add(tmpdeg);
				}

				double pr = 1.0,pg=1.0;
				for(int a1:a){
					for(int a2:b){
						pair tmp = new pair(a1,a2);
						if(queried_edge_map.containsKey(tmp)){
							if(queried_edge_map.get(tmp)){
								pg *= (1 - (1-edge_prob.get(tmp))*max_g_to_r);
								pr *= (edge_prob.get(tmp)*max_r_to_g);

							}else{
								pg *=(1-edge_prob.get(tmp))*max_g_to_r;
								pr *= 1 - (edge_prob.get(tmp)*max_r_to_g);
							}
						}
					}
				}

				//while 1
				//pick the first elements and query if not queried
				//Update degree and update prob, pg, pr
				//break if criterion met
				int start_node_a=0;
				int start_node_b=0;
				boolean couldnotquerymore =  false;
				while(true){
					//sort two degrees
					int n1 = (int)degree_a.get(start_node_a)[0];
					int n2 = (int)degree_b.get(start_node_b)[0];
					pair tmp = new pair(n1,n2);
					pair tmp1 = new pair(n2,n1);
					if(queried_edge_map.containsKey(tmp)){
						start_node_b++;
						if(start_node_b==degree_b.size()){
							start_node_b=0;
							start_node_a++;
						}
					}else{
						couldnotquerymore =  true;
						queries++;
						boolean[] output =  query_edge_prob(oracle, gt, n1, n2);
						queried_edge_map.put(tmp, output[1]);
						queried_edge_map.put(tmp1, output[1]);
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

						if(output[1]){
							//System.out.println("green edge");
							double[] newdeg={n1,degree_a.get(start_node_a)[1]-1*Math.log((edge_prob.get(tmp)*max_r_to_g)) };
							degree_a.set(start_node_a, newdeg);
							double[] newdegb={n2,degree_b.get(start_node_b)[1]-1*Math.log((edge_prob.get(tmp)*max_r_to_g)) };
							degree_b.set(start_node_b, newdegb);
							flow += -1*Math.log((edge_prob.get(tmp)*max_r_to_g));
							pg *= (1 - (1-edge_prob.get(tmp))*max_g_to_r);
							pr *= (edge_prob.get(tmp)*max_r_to_g);

							start_node_a=0;
							start_node_b=0;
							Collections.sort(degree_a, new Comparator<double[]>() {
								public int compare(double[] o1, double[] o2) {
									double s1 = o1[1]; double s2 = o2[1];
									if (s1 != s2)
										return (s1 > s2 ? 1 : -1);
									else
										return 0;
								}
							});

							Collections.sort(degree_b, new Comparator<double[]>() {
								public int compare(double[] o1, double[] o2) {
									double s1 = o1[1]; double s2 = o2[1];
									if (s1 != s2)
										return (s1 > s2 ? 1 : -1);
									else
										return 0;
								}
							});


						}else{
							pg *=(1-edge_prob.get(tmp))*max_g_to_r;
							pr *= 1 - (edge_prob.get(tmp)*max_r_to_g);

						}

					}
					if(flow >= Math.min(a.size(), b.size())*Math.log(Math.exp(1)*nodes.size()) )
						break;
					if(pr*1.0/(pr+pg) > this.confidence){
						//this.ouput_print.println("found a partition "+i1);
						component acomp =new component(a);
						component bcomp =new component(b);
						for(int a11:a){
							for(int a12:b){
								if(gt.get(a11).equals(gt.get(a12)))
									true_pos--;
								else
									false_pos--;
							}
						}
						set_clusters.set(i1, acomp);
						set_clusters.add(bcomp);

						break;
					}
					if(start_node_a==degree_a.size())
						break;
				}

				if(!couldnotquerymore)
					i1++;



			}

		}
		return;

	}

	public boolean[] query_edge_prob(HashMap<pair,Boolean>  oracle, HashMap<Integer, Integer> gt, int u, int v){
		boolean ret[] = {false, false};
		pair tmp = new pair(u,v);

		if(this.answers.containsKey(tmp)){

			int tmps = this.answers.get(tmp);
			ret[1] =  (tmps==1);

		}else{
			//System.out.println("SOMETHING IS WRONG HERE**************************"+u+" "+v);
			ret[1] = gt.get(u).equals(gt.get(v));
		}

		//ret[1]=false;
		//Ground truth
		if (gt.get(u).equals(gt.get(v))){
			ret[0]=true;
		}

		return ret;
	}

	public static List<Integer> pickNRandom(List<Integer> lst, int n, Map<pair, Double> edge_prob, int fl) {
		List<Integer> copy = new LinkedList<Integer>(lst);

		Collections.shuffle(copy);
		List<Integer> copy_new = new LinkedList<Integer>();

		if(copy_new.size()<n){
			copy_new = copy.subList(0,n);
		}

		return copy_new;


	}

	double get_benefit(int u,  Map<pair, Double> edge_prob){

		int iter = 0;
		double max_ben = 0;
		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			for(int n : nodes){
				//if(u==n)
				//System.out.println(u+" "+n+" "+nodes.size());;
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
			}
			if(prob > max_ben){
				max_ben = prob;
			}
			iter++;
		}

		return max_ben;
	}
	public ArrayList<double[]> get_benefit_component(int u,  Map<pair, Double> edge_prob){
		ArrayList<double[]> comp_lst = new ArrayList<double[]>();


		int iter = 0;

		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			double max = 0.0;
			double min = 1.0;
			for(int n : nodes){
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
				if(edge_prob.get(ed)>max)
					max = edge_prob.get(ed);
				if(edge_prob.get(ed)<min)
					min = edge_prob.get(ed);
			}
			double[] entry = {prob,iter, max,min};

			comp_lst.add(entry);
			iter++;
		}




		Collections.sort(comp_lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[0]; double s2 = o2[0];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});
		return comp_lst;
	}
	public void mergeClusters(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){

		Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		int num_clust_queried = 0;
		int logn = (int) ((int)Math.log(graph_nodes.size())/Math.log(2));
		while(true){
			if(num_clust_queried > logn*(logn-1)/2)
				break;
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(fresh_queried_edge_map.containsKey(t)){
								num_q++;
								if(fresh_queried_edge_map.get(t)){
									pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= (edge_prob.get(t)*max_r_to_g);
								}else{
									pg *=(1-edge_prob.get(t))*max_g_to_r;
									pr *= 1 - (edge_prob.get(t)*max_r_to_g);
								}							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q==a.size()*b.size())
						continue;
					//prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(prob<=threshold || prob > prev_threshold)
						continue;
					//System.out.println(prob);
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size())};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);


				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				if(entry[7]>threshold && entry[7] <=prev_threshold){

					double num_query = 100;
					//TODO : CHANGE THIS ACCORDING TO ALPHA


					if(num_query > a.size())
						num_query=  a.size();

					if(num_query > b.size())
						num_query=  b.size();


					num_clust_queried++;
					double prob_curr = 1.0;
					int size = Math.min(a.size(), b.size());
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
					prob_wanted = Math.pow(prob_wanted, size);

					double pr=entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Collections.shuffle(pairlist);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							fresh_queried_edge_map.put(t1, output[1]);
							fresh_queried_edge_map.put(t1, output[1]);

						}
						if(!fresh_queried_edge_map.containsKey(t)){
							if(output[1]){
								prob_curr *= (edge_prob.get(t)*max_r_to_g);
							}

							if(output[1]){
								pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (edge_prob.get(t)*max_r_to_g);
							}else{
								pg *=(1-edge_prob.get(t))*max_g_to_r;
								pr *= 1 - (edge_prob.get(t)*max_r_to_g);
							}						
						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						//if(neg>10)
						//	this.ouput_print.println("A"+a.size()+" "+b.size()+" "+false_pos+" "+num_g+" "+red+" "+num_wanted+" "+prob_wanted+" "+prob_curr);
						//System.out.println("Increased recall by"+pos+" "+neg);
						//if(entry[3]>100)
						//	System.out.println("merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
						break;
					}else{
						;//if(entry[3]>100)
	//						System.out.println("not merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);

					}

				}

			}

		}
	}
	public void mergeClustersOld(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){


		Map<pair,Integer> already_done = new HashMap<pair,Integer>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					pair t1 = new pair(i,j);
					if(already_done.containsKey(t1))
						continue;
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int queried=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								queried++;
								if(queried_edge_map.get(t)){
									pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= (edge_prob.get(t)*max_r_to_g);
								}else{
									pg *=(1-edge_prob.get(t))*max_g_to_r;
									pr *= 1 - (edge_prob.get(t)*max_r_to_g);

								}

							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					prob = prob*1.0/(a.size()*b.size());
					if(queried>0)
						continue;
					if(pr*1.0/(pr+pg) > this.confidence)
						continue;
					if(prob<=threshold || prob > prev_threshold)
						continue;
					//System.out.println(prob);
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg};
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				pair t11 = new pair(i,j);
				already_done.put(t11,1);


				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				if(entry[0]>threshold && entry[0] <=prev_threshold){

					double num_query = 100;
					//TODO : CHANGE THIS ACCORDING TO ALPHA


					if(num_query > a.size())
						num_query=  a.size();

					if(num_query > b.size())
						num_query=  b.size();



					double prob_curr = 1.0;
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);


					int num_g=0,red=0;
					double pr=1.0,pg=1.0;//entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Collections.shuffle(pairlist);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_g++;
							prob_curr *= edge_prob.get(t)*max_r_to_g;
						}
						else 
							red++;

						if(output[1]){
							pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= (edge_prob.get(t)*max_r_to_g);

						}else{
							pg *=(1-edge_prob.get(t))*max_g_to_r;
							pr *= 1 - (edge_prob.get(t)*max_r_to_g);

						}
						if(prob_curr<=prob_wanted && pg*1.0/(pr+pg)>0.5 && num_g > red){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}
						break;

					}

					if((prob_curr<= prob_wanted &&  pg*1.0/(pr+pg)>0.5 && num_g > red )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						//if(neg>10)
						//	this.ouput_print.println("A"+a.size()+" "+b.size()+" "+false_pos+" "+num_g+" "+red+" "+num_wanted+" "+prob_wanted+" "+prob_curr);
						//System.out.println("Increased recall by"+pos+" "+neg);
						break;
					}else{
						already_done.put(t11,1);
					}

				}

			}

		}
	}


	public void edgeOrderingolder(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= (edge_prob.get(t)*max_r_to_g);
								}else{
									pg *=(1-edge_prob.get(t))*max_g_to_r;
									pr *= 1 - (edge_prob.get(t)*max_r_to_g);
								}
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q==a.size()*b.size())
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(prob<=threshold || prob > prev_threshold)
						continue;
					//System.out.println(prob);
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size())};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);				

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				if(entry[0]>threshold && entry[0] <=prev_threshold){

					double num_query = 100;
					//TODO : CHANGE THIS ACCORDING TO ALPHA


					if(num_query > a.size())
						num_query=  a.size();

					if(num_query > b.size())
						num_query=  b.size();



					double prob_curr = 1.0;
					int size = Math.min(a.size(), b.size());
					double prob_wanted =1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
					prob_wanted  = Math.pow(prob_wanted, size);

					prob_wanted = Math.pow(a.size(), a.size())*Math.pow(b.size(), b.size())/Math.pow(a.size()+b.size(), a.size()+b.size());


					double pr=entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}

					Collections.shuffle(pairlist);
					boolean first = true;
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);


							if(output[1]){
								prob_curr *= (edge_prob.get(t)*max_r_to_g);

							}


							if(output[1]){
								pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (edge_prob.get(t)*max_r_to_g);
							}else{
								pg *=(1-edge_prob.get(t))*max_g_to_r;
								pr *= 1 - (edge_prob.get(t)*max_r_to_g);
							}

						}
						if(entry[0]>=0.7 && first && output[1]){
							prob_wanted = 0.999;
							break;
						}else if(entry[0]<=0.3 && first && !output[1]){
							break;
						}
						first = false;
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}

						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						//if(neg>10)
						//	this.ouput_print.println("A"+a.size()+" "+b.size()+" "+false_pos+" "+num_g+" "+red+" "+num_wanted+" "+prob_wanted+" "+prob_curr);
						//System.out.println("Increased recall by"+pos+" "+neg);
						//if(entry[4]>100)
							//System.out.println("merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
						break;
					}else{
						;//if(entry[3]>100)
							//System.out.println("not merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);

					}

				}

			}

		}
	}
	public void edgeOrderingOld(HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){

		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){

					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double prob = 0.0;
					int num_q=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= (edge_prob.get(t)*max_r_to_g);
								}else{
									pg *=(1-edge_prob.get(t))*max_g_to_r;
									pr *= 1 - (edge_prob.get(t)*max_r_to_g);
								}
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q>0)
						continue;
					if(num_q==a.size()*b.size())
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(prob<=threshold || prob > prev_threshold)
						continue;
					//System.out.println(prob);
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;

					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size())};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);

				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();

				if(entry[0]>threshold && entry[0] <=prev_threshold){

					double num_query = 100;
					//TODO : CHANGE THIS ACCORDING TO ALPHA


					if(num_query > a.size())
						num_query=  a.size();

					if(num_query > b.size())
						num_query=  b.size();



					double prob_curr = 1.0;
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];

					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Collections.shuffle(pairlist);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);


							if(output[1]){
								prob_curr *= (edge_prob.get(t)*max_r_to_g);
							}

							if(output[1]){
								pg *= (1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (edge_prob.get(t)*max_r_to_g);
							}else{
								pg *=(1-edge_prob.get(t))*max_g_to_r;
								pr *= 1 - (edge_prob.get(t)*max_r_to_g);
							}

						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}
						break;
					}

					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						//if(neg>10)
						//	this.ouput_print.println("A"+a.size()+" "+b.size()+" "+false_pos+" "+num_g+" "+red+" "+num_wanted+" "+prob_wanted+" "+prob_curr);
						//System.out.println("Increased recall by"+pos+" "+neg);
						//if(entry[4]>100)
						//	System.out.println("merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
						break;
					}else{
						;//if(entry[3]>100)
						//	System.out.println("not merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);

					}

				}

			}

		}
	}

	public void nodeOrderingExpold(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){
		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);
		int num_green = 0;

		while(true)
		{
			//Get the elements of the window...
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}

				w--;
				if(w==0)
					break;
			}
			//System.out.println("u is "+max+" "+processed_nodes.size());

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);

				continue;
			}


			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean finalbreak = false;
			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
				//math.ceil for landmarks
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				//System.out.println("fractions is "+num_green*1.0/queries+" "+queries);
				//System.out.println("fractions i s "+num_green*1.0/queries+" "+Math.log(2)/Math.log(graph.num_nodes())+" "+set_clusters.size()+" "+queries+" "+true_pos+" "+false_pos);
				if(num_green*1.0/queries < 0.33 && queries > 5){
					finalbreak=true;
					break;
				}


				double num_query = 100;
				if(num_query > current.size())
					num_query=  current.size();


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);

				List<Integer> tmp = new ArrayList<Integer>();
				tmp = pickNRandom(current,(int)num_query, edge_prob,0);
				int num_g=0,red=0;
				double pr=1.0, pg=1.0;
				for(int q : tmp){
					{
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							num_green++;
							num_g++;
							prob_curr *= edge_prob.get(t)*max_r_to_g;

							pg *= (1 - (1-edge_prob.get(t1))*max_g_to_r);
							pr *= (edge_prob.get(t1)*max_r_to_g);

						}
						else {
							red++;

							pg *=(1-edge_prob.get(t1))*max_g_to_r;
							pr *= 1 - (edge_prob.get(t1)*max_r_to_g);

						}

						if(output[1]){
							graph_nodes.get(q).add_green(max);
							graph_nodes.get(max).add_green(q);							
						}
						else{
							graph_nodes.get(q).add_red(max);
							graph_nodes.get(max).add_red(q);
							changed.add(q);
						}
						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
							pair t = new pair(i,max); 
							//System.out.println("added a wrong node"+edge_prob.get(t)+" "+current.size()+" "+max+" "+i+" "+num_g+" "+red+" "+prob_curr+" "+prob_wanted);
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}



				num++;
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);
			if(finalbreak)
				break;

			if(processed_nodes.size()==graph.num_nodes())
				break;
			changed.clear();

		}
	}


	public ArrayList<double[]> get_component_lst(int u,  Map<pair, Double> edge_prob){
		ArrayList<double[]> comp_lst = new ArrayList<double[]>();


		int iter = 0;

		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			double max = 0.0;
			int maxnode = 0;
			double min = 1.0;
			for(int n : nodes){
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
				if(edge_prob.get(ed)>max){
					max = edge_prob.get(ed);
					maxnode = n;
				}
				if(edge_prob.get(ed)<min)
					min = edge_prob.get(ed);
			}
			double[] entry = {prob,iter, max,min,maxnode};

			comp_lst.add(entry);
			iter++;
		}


		//Max

		Collections.sort(comp_lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[2]; double s2 = o2[2];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});
		return comp_lst;
	}

	public void nodeOrderingOld(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);

		do
		{
			//Get the elements of the window...
			int max=-1;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				max=u;
				break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_component_lst(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean added = false;
			for(double[] comp : comp_list){
				boolean[] output =  query_edge_prob(oracle, gt, (int)comp[4], max);
				pair t = new pair(max,(int)comp[4]);
				pair t1 = new pair((int)comp[4],max);
				if(!queried_edge_map.containsKey(t)){
					queries++;
					double precision = true_pos*1.0/g_edges;
					double recall = true_pos*1.0/(true_pos+false_pos);
					if(true_pos!=0)	
						this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


					queried_edge_map.put(t1, output[1]);
					queried_edge_map.put(t, output[1]);
				}
				if(output[1]){
					ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
							//pair t = new pair(i,max); 
							//System.out.println("added a wrong node"+edge_prob.get(t)+" "+current.size()+" "+max+" "+i+" "+num_g+" "+red+" "+prob_curr+" "+prob_wanted);
						}
					}
					//System.out.println(true_pos+" "+false_pos);

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;

					break;

				}
			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(true);
		//System.out.println("done with everything it is");
	}
	public void nodeOrderingOldWithExp(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);

		do
		{
			//Get the elements of the window...
			int max=-1;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				max=u;
				break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_component_lst(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
				//System.out.println("probability is "+Math.log(prob_wanted)*1.0/Math.log(0.07)+" "+current.size());
				//if(prob_wanted < Math.pow(r_t_g, current.size()))
				//prob_wanted = Math.pow(r_t_g, current.size())+0.00001;

				double pr=1.0, pg=1.0;

				Collections.shuffle(current);
				for(int q : current){
					{
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							if(oraclenoise){
								prob_curr  *= (max_r_to_g);
								pg *= (1 - max_g_to_r);
								pr *= (max_r_to_g);
							}else{
								prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}
						}else{
							if(oraclenoise){
								pg *=max_g_to_r;
								pr *= 1 - (max_r_to_g);
							}else{
								pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-get_r_to_g(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);	
							}	
						}

						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}

			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(true);
		//System.out.println("done with everything it is");
	}

	public void nodeOrderingOldWithAdpExp(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, ArrayList<Node> graph_nodes, double g_edges){

		Set<Integer> processed_nodes = new HashSet<Integer>();
		int window = 1;//graph.num_nodes();
		//System.out.println("Starting Phase #1 with window =  "+window);

		do
		{
			//Get the elements of the window...
			int max=-1;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				max=u;
				break;
			}

			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}
			//System.out.println("reached here");

			ArrayList<double[]> comp_list = get_component_lst(max,edge_prob);
			//Get the list of components in decreasing order of benefit

			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();


				double prob_curr = 1.0;
				double prob_wanted =  1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
				//if(prob_wanted < Math.pow(r_t_g, current.size()))
				//prob_wanted = Math.pow(r_t_g, current.size())+0.00001;

				double pr=1.0, pg=1.0;

				Collections.shuffle(current);
				boolean first = true;
				for(int q : current){
					{
						pair t = new pair(q,max);
						pair t1 = new pair(max,q);
						//System.out.println("curr"+edge_prob.get(t)+" "+avg_similarity);
						boolean[] output =  query_edge_prob(oracle, gt, q, max);

						if(!queried_edge_map.containsKey(t)){
							queries++;
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));


							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
						}

						if(output[1]){
							if(oraclenoise){
								prob_curr  *= (max_r_to_g);
								pg *= (1 - max_g_to_r);
								pr *= (max_r_to_g);
							}else{
								prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}
						}else{
							if(oraclenoise){
								pg *=max_g_to_r;
								pr *= 1 - (max_r_to_g);
							}else{
								pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-get_r_to_g(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);	
							}	
						}
						double sim  = edge_prob.get(t);
						if(sim>=0.5 && first && output[1]){
							prob_wanted = 0.999;
							break;	
						}else if(sim < 0.5 && first && !output[1]){
							break;
						}else{
							prob_wanted = 1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
						}

						first = false;


						if(pr*1.0/(pr+pg) > this.confidence)
							break;

						if(prob_curr<=prob_wanted)
							break;

					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}

					current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}

			}

			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);

			if(processed_nodes.size()==graph.num_nodes())
				break;
			//System.out.println("here it is "+num_green+" "+queries);
		}while(true);
		//System.out.println("done with everything it is");
	}



	public int[] process( HashMap<Integer, Integer> gt   , PrintStream out,
			Graph graph,TreeMap  <Integer, Double > expected_sorted, int g_limit, Map      <Integer, List<double[]>> adj_weighted, double g_edges ) throws Exception {



		//System.out.println("Starting to run with total green is "+g_edges);
		this.N = graph.num_nodes();

		//double g_to_r = 0.0;
		Map<pair, Double> edge_prob = new HashMap<pair, Double>();
		int node_id = 0;



		while(node_id<graph.num_nodes()){
			for (double[] edge1 : adj_weighted.get(node_id)) {   
				pair temp= new pair((int)edge1[0],(int)edge1[1]);
				edge_prob.put(temp, edge1[2]);
				temp= new pair((int)edge1[1],(int)edge1[0]);
				edge_prob.put(temp, edge1[2]);
				if(edge1[1] > edge1[0])
					prob_list.add(edge1);
			}
			node_id++;
		}


		Collections.sort(prob_list, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[2]; double s2 = o2[2];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});

		//System.out.println("Edges have been made");

		//System.out.println("total green is "+g_edges);



		//Set the empty ones to 0
		for(int node_id1=0;node_id1<graph.num_nodes();node_id1++){
			for(int node_id2=0;node_id2<graph.num_nodes();node_id2++){
				pair t = new pair(node_id1,node_id2);
				pair t1 = new pair(node_id2,node_id1);
				if(edge_prob.containsKey(t))
					continue;
				edge_prob.put(t1, 0.0);
				edge_prob.put(t, 0.0);
			}
		}

		//System.out.println("Edges made and similarities have been set");




		//THIS IS IMPORTANT TO INITIALISE THE GREEN AND RED QUERIED EDGE SET
		ArrayList<Node> graph_nodes =new ArrayList<Node>();
		for(int it=0;it<graph.num_nodes();it++){
			Node tmp = new Node();
			graph_nodes.add(tmp);
		}


		if(oraclenoise)
			add_noise(oraclenoiseval,  graph,   oracle, gt);

		if(pipeline == 1){

			NodeNodeExpOrdering( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
			//this.ouput_print.println("done here");
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);

			//this.ouput_print.println("done merge");
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

			//this.ouput_print.println("done regular");
			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}

			int singlenotdone = 0;
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					singlenotdone++;
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);
				}
			}
			//System.out.println(singlenotdone+" single left out");
			EdgeEdgeExpOrdering(gt,edge_prob,graph_nodes,(int)g_edges,0.1,10.0);
			//System.out.println("this is sss");
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if(pipeline==2){

			//System.out.println("Starting Phase #1");
			nodeOrderingExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);	      		

			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);

				}
			}


			EdgeExpOrdering(gt,edge_prob,graph_nodes,(int)g_edges,0.1,10.0);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			//this.ouput_print.println("edge over edge now");
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

		}else if (pipeline==3){
			//System.out.println("Starting Phase #1");
			nodeOrdering( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);	      		
			//this.ouput_print.println("done node");
			Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
			for(int i=0;i<set_clusters.size();i++){
				for(int a:set_clusters.get(i).get_component()){
					clus_loc.put(a, i);
				}
			}
			for(int i=0;i<graph.num_nodes();i++){
				if(clus_loc.containsKey(i))
					continue;
				else{
					ArrayList<Integer> nodes1 = new ArrayList<Integer>();
					nodes1.add(i);
					component curr_comp1 = new component(nodes1);
					set_clusters.add(curr_comp1);
					clus_loc.put(i, set_clusters.size()-1);

				}
			}
			edgeOrdering(gt,edge_prob,graph_nodes,(int)g_edges,0.1,10.0);
			//this.ouput_print.println("edge over edge now");
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			//this.ouput_print.println("edge over 2edge now");
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);

		}else if(pipeline==4){
			nodeOrderingOld( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
		}else if(pipeline==5){
			nodeOrderingOldWithExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else if(pipeline==6){
			nodeOrderingOldWithAdpExp( expected_sorted,  graph,   edge_prob,  gt,  graph_nodes,  g_edges);
			mergeClusters(gt,edge_prob,graph_nodes,(int)g_edges);
			regularize( edge_prob, gt,  graph_nodes,  (int)g_edges);
		}else{
			edgeOrdering(gt,edge_prob,graph_nodes,(int)g_edges,0.1,10.0);
		}


		this.ouput_print.close();
		return new int[]{0,0};       
	}

	public static void main(String[] args) throws Exception{
		if(args.length < 2){
			System.out.println("Help: java fig6adaptive <folder> <pipeline>");
			System.exit(0);
		}
	
		for(int iter = 1;iter<=10;iter++){
			fig6adaptive no  = new fig6adaptive();
			no.answers = new HashMap<pair, Integer>();
			no.curr_ans = new HashMap<pair, Integer>();
			no.folder = args[0];
			no.pipeline = Integer.parseInt(args[1]);
			try {
				HashMap<Integer, Integer> gt = new HashMap<Integer,Integer>();

				String gold = "../Data/"+no.folder+"/gold.txt";
				Scanner scanner = new Scanner(new File(gold));
				{

					while(scanner.hasNextLine()){
						String[] line=scanner.nextLine().split(" ");

						int a1 = Integer.parseInt(line[0]);
						int a2 = Integer.parseInt(line[1]);
						gt.put(a1,a2);
					}
				}


				String graph_file     = "../Data/"+no.folder+"/graph.txt";
				Graph graph;
				PrintStream out;

				out = new PrintStream("../output/"+no.folder+"/output.txt");

				Map <Integer, List<double[]>> adj_weighted=new HashMap<Integer, List<double[]>>();;

				scanner = new Scanner(new File(graph_file));
				graph = new Graph(scanner.nextInt());
				double g_edges = scanner.nextInt();
				int i=0;
				for (;i<graph.num_nodes();i++) {
					adj_weighted.put(i, new ArrayList<double[]>());
				}

				while(scanner.hasNextLine()){
					int u = scanner.nextInt();        		
					if(u==-1)
						break;
					int v = scanner.nextInt();
					double prob = scanner.nextFloat();
					if(no.noiseEdgeProb)
						prob = no.get_noise_val(u,v,gt,prob);
					double[] edge = {u,v,prob};
					adj_weighted.get(u).add(edge);
					adj_weighted.get(v).add(edge);
				}





				String answer = "../Data/"+no.folder+"/answers.txt";
				try {
					scanner = new Scanner(new File(answer));
					while(scanner.hasNextLine()){
						String[] line=scanner.nextLine().split(" ");
						int a1 = Integer.parseInt(line[0]);
						int a2 = Integer.parseInt(line[1]);
						int a3 = Integer.parseInt(line[2]);
						pair t =new pair(a1,a2);
						pair t1 =new pair(a2,a1);
						no.answers.put(t,a3);
						no.answers.put(t1,a3);
					}
				}
				catch(FileNotFoundException ex) {
					System.out.println("Exception in Answers file");               
				}

				no.ouput_print = new PrintStream ("../output/"+no.folder+"/output_fscore_"+Integer.toString(iter));

				//System.out.println("Read all files, Number of nodes = "+adj_weighted.size());

				HashMap<Integer, Double> expected = new HashMap<Integer, Double>();
				for (int u =0;u<graph.num_nodes() ;u++) {
					double sum = 0.0;
					for (double[] edge: adj_weighted.get(u)) {
						double s  = edge[2];
						sum      += s;
					}
					expected.put(u, sum);
				}
				TreeMap<Integer, Double > expected_sorted;
				ValueComparator bvc  = new ValueComparator(expected, null);
				expected_sorted = new TreeMap<Integer, Double>(bvc);
				expected_sorted.putAll(expected);

				int g_limit = 300000;

				//double r_to_g = 0.0;//0117287098419;;
				//double g_to_r=0.0;//124721603563;//0.089;//
				no.max_r_to_g =0.0/0.9;//0.09523809523809523/0.9;//0.00290023201856/0.9;;//0.09523809523809523/0.9;//0.09523809523809523/0.9;;//0.00290023201856/0.9;//0.0;//0.09523809523809523/0.9;
				max_g_to_r =0.1/0.3;//0.222222222222222/0.9;//0.222222222222222/0.9;//0.222222222222222/0.7 ;//0.1/0.3;//0.222222222222222/0.9;

				no.process( gt, out,graph,expected_sorted,g_limit , adj_weighted,  g_edges ) ;
				//System.out.println("Program complete --exiting-- ");
			}
			catch(FileNotFoundException ex) {
				System.out.println("Exception in code");            // Always must return something

			}
		}
	}	
}

