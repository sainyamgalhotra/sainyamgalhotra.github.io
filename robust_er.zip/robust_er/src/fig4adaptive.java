/**
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;


/**
 * 
 */

class ValueComparator implements Comparator<Integer> {

    Map<Integer, Double> base;
    HashMap<Integer, Double> tiebreak;
   static Random generator = new Random(1992);

    
    public ValueComparator(Map<Integer, Double> base, HashMap<Integer, Double> tiebreak) {
        this.base = base;
        this.tiebreak = tiebreak;
    }

    // Note: this comparator imposes orderings that are inconsistent with equals.    
    public int compare(Integer a, Integer b) {
        if (base.get(a) > base.get(b)) {
            return -1;
        } else if (base.get(a) < base.get(b))  {
            return  1;
        } else {
        	Random rand = new Random(1992);

        	float rand1 = rand.nextFloat();
            if (rand1 >= 0.5) {
                return -1;
            } else  {
                return  1;
            }
        }
        // returning 0 would merge keys
    }
}


public class fig4adaptive {
	
	
	String folder;
	boolean iSCC=false;
	
	int queries=0;
	
	//Fixed seed to get the same answer in each run
	static Random generator = new Random(1992);
	
	int Nnodes=0;
	HashMap<pair,Boolean> oracle = new HashMap<pair,Boolean>();
	ArrayList<component> set_clusters = new ArrayList<component>();
	Map<pair, Boolean> queried_edge_map = new HashMap<pair, Boolean>();
	int true_pos=0;
	int false_pos=0;
	Map<pair, Double> edge_prob_SCC = new HashMap<pair, Double>();
	Set<Integer> singleton_nodes = new HashSet<Integer>();
	Set<Integer> changed = new HashSet<Integer>();
	int max_query=0;
	boolean print_over =false;
	double theta = 0.3;
	
	int tau=0;
	double beta=1;
	PrintStream ouput_print;
	PrintStream ouput_print_scc;
	Map<pair, Integer> answers;
	Map<pair, Integer> curr_ans;
	double confidence=0.95;
	
	
	public double get_r_to_g(double sim){
		if(sim==1.0)
			sim= 0.99;
		double captchas_lst[] = {0.0,0,0,0,0,0,0,0.0, 0.0,0.0,0.0};
		
		double gym_lst[] = {0.0036,0.0,0.0116,0.0,0.038,0.0,0.0734,0.0, 0.1,0.0};
		
		double landmarks_lst[] = {0.0,0.0,0.0,0.0,0.0,0.00034,0.0024,0.00317,0.0014,0.00277,0.0};
		
		if(folder.equals("captchas"))
			return captchas_lst[(int)sim*10];
		else if(folder.equals("gym"))
			return gym_lst[(int)sim*10];
		else
			return landmarks_lst[(int)sim*10];
	}
	
	public double get_g_to_r(double sim){
		if(sim==1.0)
			sim= 0.99;
		
		double captchas_lst[] = {0.0,0,0,0,0,0,0.2,0.119, 0.100,0.104};
		double gym_lst[] = {0.22,0.0,0.4242,0.0,0.1944,0.0,0.10606,0.0, 0.0769,0.0273};
		
		double landmarks_lst[] = {0.0,0.1818,0.22,0.2229,0.2709,0.3039,0.2519,0.14626,0.0604,0.02597};
		
		if(folder.equals("captchas"))
			return captchas_lst[(int)sim*10];
		else if(folder.equals("gym"))
			return gym_lst[(int)sim*10];
		else
			return landmarks_lst[(int)sim*10];
	}
	
	public void updateEdgeProbSCC(pair t1, pair t2, double prob, boolean output){
		if(output){
			edge_prob_SCC.put(t1, (1 - get_g_to_r(prob)));//(1-prob)*max_g_to_r));
			edge_prob_SCC.put(t2, (1 - get_g_to_r(prob)));//(1-prob)*max_g_to_r));			
		}else{
			edge_prob_SCC.put(t1, get_r_to_g(prob));//(prob)*max_r_to_g);
			edge_prob_SCC.put(t2, get_r_to_g(prob));//(prob)*max_r_to_g);
		}
		
	}
	public void mergeClusters(Graph graph, HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob, int g_edges){
		
		Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		
		int num_clust_queried = 0;
		int logn = (int) ((int)Math.log(Nnodes)/Math.log(2));
		
		 while(true){
			 
			if(num_clust_queried >= (logn*(logn-1))/2)
				break;
			
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0;
					double benefit = 0.0;
					int num_q=0;
					
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(fresh_queried_edge_map.containsKey(t)){
								num_q++;
								if(fresh_queried_edge_map.get(t)){
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}	
							}
							benefit+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;
					
					double[] entry = {benefit,i,j,pos,neg,pr,pg, benefit/(a.size()*b.size()), num_q};
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				if(num_clust_queried >= (logn*(logn-1))/2)
					break;
				

				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);
				
				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();
				//this.ouput_print_scc.println("trying for "+logn+ " "+a.size()+" "+b.size()+" "+num_clust_queried);		
				
					num_clust_queried++;
					double prob_curr = 1.0;
					int size = Math.min(a.size(), b.size());
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);
					prob_wanted = Math.pow(prob_wanted, size);
					double pr=entry[5],pg=entry[6];
					
					if(pr*1.0/(pr+pg) > this.confidence)
						continue;
					if(entry[8] == a.size() * b.size())
						continue;
					
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
					Collections.shuffle(pairlist,newgen);
					
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);
						pair t1 = new pair(querypair[1], querypair[0]);

						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							get_SCC( gt,  graph, (int) g_edges);
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							updateEdgeProbSCC(t,t1,edge_prob.get(t),output[1]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							
						}
						if(!fresh_queried_edge_map.containsKey(t)){
							if(output[1]){
								prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}else{
								pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= (1-get_r_to_g(edge_prob.get(t)));//(edge_prob.get(t)*max_r_to_g);
							}	
							fresh_queried_edge_map.put(t, output[1]);
							fresh_queried_edge_map.put(t1, output[1]);
						}
						
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}
					
					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						//if(entry[3]>100)
						//System.out.println("merged"+entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]);
						break;
					}
				}


		}
		double precision = true_pos*1.0/g_edges;
		double recall = true_pos*1.0/(true_pos+false_pos);
		this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));
	}
	public void regularize(Graph graph, Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt , int g_edges){

		
		while(true){
			boolean changed_anycluster = false;
			ArrayList<int[]> sizelist = new ArrayList<int[]>();
			for(int i=0;i<set_clusters.size();i++){
				int[] tp = {i,set_clusters.get(i).get_component().size()};
				sizelist.add(tp);
			}
			Collections.sort(sizelist, new Comparator<int[]>() {
				public int compare(int[] o1, int[] o2) {
					int s1 = o1[1]; int s2 = o2[1];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			
			for(int[] clust : sizelist){
				int i=clust[0];
				//for(int i=0;i<set_clusters.size();i++){
				ArrayList<Integer> curr_comp =set_clusters.get(i).get_component();
				if(curr_comp.size()==1)
					continue;
				
				ArrayList<Integer> deleted = new ArrayList<Integer>();
				double wanted = 1.0/Math.pow(Math.exp(1)*(curr_comp.size()), this.beta);
				deleted.clear();
				
				ArrayList<double[]> confidenceList = new ArrayList<double[]>(); 
				
				for(int a : curr_comp){
					
					double prob = 1;
					double sim = 0;
					double pr=1.0,pg=1.0;
					for(int b : curr_comp){
						if(a==b)
							continue;
						pair t = new pair(a,b);
						if(queried_edge_map.containsKey(t)){
							if(queried_edge_map.get(t)){
								prob  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}else{
								pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
								pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							}	
						}
						sim+=edge_prob.get(t);
					}
					sim = sim/(curr_comp.size()-1);
					double[] node = {prob,a,pr,pg};
					confidenceList.add(node);
				}
				Collections.sort(confidenceList, new Comparator<double[]>() {
					public int compare(double[] o1, double[] o2) {
						double s1 = o1[0]; double s2 = o2[0];
						if (s1 != s2)
							return (s1 > s2 ? -1 : 1);
						else
							return 0;
					}
				});

				
				for(double[] node : confidenceList){
					double prob = node[0];
					int a = (int) node[1];
					double pr = node[2];
					double pg = node[3];
					
					if(prob > wanted ){
						ArrayList<Integer> tmp_comp = new ArrayList<Integer>();
						tmp_comp.addAll(curr_comp);
						Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
						Collections.shuffle(tmp_comp,newgen);
						
						for(int q:tmp_comp){
							if(q==a)
								continue;
							pair t  = new pair(a,q);
							if(queried_edge_map.containsKey(t))
								continue;
							boolean[] output =  query_edge_prob(oracle, gt, q, a);
							if(!queried_edge_map.containsKey(t)){
								queries++;
								get_SCC( gt,  graph, (int) g_edges);
								double precision = true_pos*1.0/g_edges;
								double recall = true_pos*1.0/(true_pos+false_pos);
								if(true_pos!=0)	
									this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

								pair t1 = new pair(a,q);
								updateEdgeProbSCC(t,t1,edge_prob.get(t),output[1]);
								queried_edge_map.put(t1, output[1]);
								queried_edge_map.put(t, output[1]);
								if(output[1]){
									prob  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}	
							}
							if(prob<=wanted)
								break;
							if( pr*1.0/(pr+pg) > this.confidence)
								break;
						}
						if(prob <= wanted )
							;
						else {
							deleted.add(a);
							for(int k:curr_comp){
								if( !deleted.contains(k) ){
									if(gt.get(a).equals(gt.get(k))){
										true_pos--;
									}
									else{
										false_pos--;
										//System.out.println("Improving precision");
									}	
								}
							}
							//System.out.println("Please remove "+a+" "+prob+" "+wanted+" "+los+" "+gain+" "+pr*1.0/(pr+pg)+" "+g+" "+r);
						}

					}
				}
				ArrayList<Integer> new_comp = new ArrayList<Integer>();
				if(deleted.size()>0)
					changed_anycluster = true;
				
				for(int n1: curr_comp){
					if(!deleted.contains(n1))
						new_comp.add(n1);	
				}
				component tmpcomp = new component(new_comp);

				this.set_clusters.set(i, tmpcomp);

			}
			if(!changed_anycluster)
				break;
		}
		
	}
	public void EdgeEdgeExpOrdering(Graph graph, HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob, int g_edges){
		
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					int num_q=0;
					double pg = 1.0, pr=1.0;
					double prob_curr = 1.0;
					double prob = 0.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}	
							}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q==a.size()*b.size())
						continue;
					
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(prob==0.0)
						continue;
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;
					
					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]+" "+entry[8]);
				
				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();
						
				{
					
					double prob_curr = entry[9];//1.0;
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];
					//System.out.println(" "+pr*1.0/(pr+pg));
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
					Collections.shuffle(pairlist,newgen);
					
					boolean first = true;
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							get_SCC( gt,  graph, (int) g_edges);
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							updateEdgeProbSCC(t,t1,edge_prob.get(t),output[1]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							
						if(output[1]){
							prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
						}else{
							pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);g);
						}	
						
						}
						if(entry[0]>=0.5 && first && output[1]){
							prob_wanted = 0.999;
							break;
						}else if(entry[0]<=0.5 && first && !output[1]){
							break;
						}
						first = false;
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}
					
					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						break;
					}
				}

			}

		}
	}

	public void EdgeExpOrdering(Graph graph, HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){
		
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					int num_q=0;
					double pg = 1.0, pr=1.0,prob_curr=1.0;
					double prob = 0.0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								num_q++;
								if(queried_edge_map.get(t)){
									prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}	
															}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					
					if(num_q==a.size()*b.size())
						continue;
					
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;
					
					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);
				
				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();
						
				{
					
					double prob_curr = entry[9];//1.0;
					double prob_wanted = 1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];
					
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
					Collections.shuffle(pairlist,newgen);
					
					//Collections.shuffle(pairlist);
					
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							get_SCC( gt,  graph, (int) g_edges);
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							updateEdgeProbSCC(t,t1,edge_prob.get(t),output[1]);
						if(output[1]){
							prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
						}else{
							pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
						}	
						
						
						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}

					}
					
					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						//this.ouput_print.println(i+" "+j+" "+entry[0]+"ssss");
						true_pos+=pos;
						false_pos+=neg;
						break;
					}
				}

			}

		}
	}

	public void edgeOrdering(Graph graph, HashMap<Integer, Integer> gt, Map<pair, Double> edge_prob,  ArrayList<Node> graph_nodes, int g_edges, double threshold, double prev_threshold){
		
		//Map<pair, Boolean> fresh_queried_edge_map = new HashMap<pair, Boolean>();
		while(true){
			List<double[]> probList = new ArrayList<double[]>();
			for(int i=0;i<set_clusters.size();i++){
				for(int j=i+1;j<set_clusters.size();j++){
					
					ArrayList<Integer> a = set_clusters.get(i).get_component();
					ArrayList<Integer> b = set_clusters.get(j).get_component();
					int pos=0,neg=0;
					double pg = 1.0, pr=1.0,prob_curr=1.0;
					double prob = 0.0;
					int num_q=0;
					for(int x:a){
						for(int y:b){
							pair t  = new pair(x,y);
							if(queried_edge_map.containsKey(t)){
								if(queried_edge_map.get(t)){
									prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
									pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}else{
									pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
									pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
								}	
															}
							prob+=edge_prob.get(t);
							if(gt.get(x).equals(gt.get(y)))
								pos++;
							else neg++;
						}
					}
					if(num_q>0)
						continue;
					if(num_q==a.size()*b.size())
						continue;
					if(pg<1)
						continue;
					if(pr<1)
						continue;
					prob = prob*1.0/(a.size()*b.size());
					if(pr*1.0/(pr+pg) > this.confidence){
						//System.out.println("moving because "+pr*1.0/(pr+pg)+" "+pos);
						continue;
					}
					if(a.size()==0)
						continue;
					if(b.size()==0)
						continue;
					
					double[] entry = {prob,i,j,pos,neg,pr,pg, prob/(a.size()*b.size()), num_q,prob_curr};
					//if (pos>neg)
					//System.out.println(prob+" "+i+" "+j+" "+pos+" "+neg+" "+pr+" "+pg);
					probList.add(entry);
				}
			}
			if(probList.size()==0)
				break;
			Collections.sort(probList, new Comparator<double[]>() {
				public int compare(double[] o1, double[] o2) {
					double s1 = o1[0]; double s2 = o2[0];
					if (s1 != s2)
						return (s1 > s2 ? -1 : 1);
					else
						return 0;
				}
			});

			for(double[]entry : probList){
				int i=(int)entry[1];
				int j=(int)entry[2];
				//if(entry[3]>100)
				//System.out.println(entry[0]+" "+" "+entry[1]+" "+entry[2]+" "+entry[3]+" "+entry[4]+" "+entry[5]+" "+entry[6]+" "+entry[7]);
				
				ArrayList<Integer> a = set_clusters.get((int)entry[1]).get_component();
				ArrayList<Integer> b = set_clusters.get((int)entry[2]).get_component();
						
				{
					
					double prob_curr = 1.0;
					double prob_wanted = 0.999;//1.0/Math.pow(Math.exp(1)*(a.size()+b.size()), this.beta);

					double pr=entry[5],pg=entry[6];
					//if(pr<1 || pg<1)
						//System.out.println("something is wrong ****************************");
					ArrayList<int[]> pairlist = new ArrayList<int[]>();
					for(int a1:a){
						for(int a2:b){
							int[] tmp  = {a1,a2};
							pairlist.add(tmp);
						}
					}
					Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
					Collections.shuffle(pairlist,newgen);
					
					//Collections.shuffle(pairlist);
					for(int[] querypair:pairlist){
						pair t = new pair(querypair[0],querypair[1]);


						boolean[] output =  query_edge_prob(oracle, gt, querypair[0], querypair[1]);
						if(!queried_edge_map.containsKey(t)){
							queries++;
							get_SCC( gt,  graph, (int) g_edges);
							double precision = true_pos*1.0/g_edges;
							double recall = true_pos*1.0/(true_pos+false_pos);
							if(true_pos!=0)	
								this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));

							pair t1 = new pair(querypair[1], querypair[0]);
							updateEdgeProbSCC(t,t1,edge_prob.get(t),output[1]);
							queried_edge_map.put(t1, output[1]);
							queried_edge_map.put(t, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
							//fresh_queried_edge_map.put(t1, output[1]);
						
						if(output[1]){
							prob_curr  *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
							pg *= (1-get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
						}else{
							pg *= (get_g_to_r(edge_prob.get(t)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
							pr *= 1-get_r_to_g(edge_prob.get(t));//(edge_prob.get(t)*max_r_to_g);
						}	
												
						}
						if(prob_curr<=prob_wanted ){
							break;
						}
						if(pr*1.0/(pr+pg)>this.confidence){
							break;
						}
						break;
					}
					
					if((prob_curr<= prob_wanted   )){// && tmp.size() < current.size()) || (num_g>= Math.ceil((tmp.size()*(1-g_to_r)/2)) && tmp.size() == current.size())){
						//System.out.println("Merging "+i+" "+j+" "+gr+" "+rd);
						int pos=0,neg=0;
						for(int x:a){
							for(int y:b){
								if(gt.get(x).equals(gt.get(y)))
									pos++;
								else neg++;
							}
						}


						a.addAll(b);
						component newtmp = new component(a);
						set_clusters.set(i, newtmp);
						ArrayList<Integer> clrlist = new ArrayList<Integer>();
						component clrtmp = new component(clrlist);
						set_clusters.set(j, clrtmp);
						true_pos+=pos;
						false_pos+=neg;
						break;
					}

				}

			}

		}
	}

	
	
	public void NodeNodeExpOrdering(TreeMap  <Integer, Double > expected_sorted, Graph graph,  Map<pair, Double> edge_prob, HashMap<Integer, Integer> gt, double g_edges){
		
		//Initialize the processed set
		Set<Integer> processed_nodes = new HashSet<Integer>();
		
		int window = 1;//graph.num_nodes();
		System.out.println("Starting Phase #1");
		int num_green = 0;		
		
		//While loop until processed set equals V
		while(num_green*1.0/queries >= theta || queries <=5 ){
			
			//Get the node with maximum expected cluster size
			int max=-1;
			double max_benefit=-1;
			int w = window;
			for (Entry<Integer, Double> currNode : expected_sorted.entrySet()) {
				int     u  = currNode.getKey() ;
				if(processed_nodes.contains(u))
					continue;
				double benefit = get_benefit(u, edge_prob);
				if(benefit > max_benefit){
					max_benefit = benefit;
					max =  u;
				}
				w--;
				if(w==0)
					break;
			}
			
			//If set clusters is empty then add this node to a new component
			if(set_clusters.size()==0){
				ArrayList<Integer> nodes = new ArrayList<Integer>();
				nodes.add(max);
				component curr_comp = new component(nodes);
				set_clusters.add(curr_comp);
				processed_nodes.add(max);	
				continue;
			}


			ArrayList<double[]> comp_list = get_benefit_component(max,edge_prob);
			//Get the list of components in decreasing order of benefit
			//The element of this list has benefit and cluster id 
			
			int num=0;
			boolean added = false;
			for(double[] comp : comp_list){

				ArrayList<Integer> current = set_clusters.get((int)comp[1]).get_component();

				//this.ouput_print.println("prob "+comp[0]*1.0/current.size()+" "+comp[1]+" "+max);
				double sim = comp[0]*1.0/current.size();
				
				if(comp[0]<=theta || num > tau + ((Math.log(graph.num_nodes())/Math.log(2))))
					break;
				
				//Shuffle the nodes to select a random node to query
				Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
				Collections.shuffle(current,newgen);
				
				
				double prob_curr = 1.0;
				double prob_wanted = 0.999999;//Math.pow(r_to_g,num_wanted);

				double pr =1.0, pg=1.0;
				boolean first = true;
				for(int q : current){
					//Querying max with q
					pair queryPair = new pair(q,max);
					boolean[] output =  query_edge_prob(oracle, gt, q, max);
					
					//Update the query count if this query has not been asked in the past
					if(!queried_edge_map.containsKey(queryPair)){
						queries++;
						pair queryPair1 = new pair(max,q);
						
						//Update the edge probability with respect to SCC
						updateEdgeProbSCC(queryPair,queryPair1,edge_prob.get(queryPair),output[1]);
						queried_edge_map.put(queryPair1, output[1]);
						queried_edge_map.put(queryPair, output[1]);
						
						//Print the scc based precision recall in the file
						get_SCC( gt,  graph, (int) g_edges);
						
						double precision = true_pos*1.0/g_edges;
						double recall = true_pos*1.0/(true_pos+false_pos);
						if(true_pos!=0)	
							this.ouput_print.println(queries+" "+true_pos+" "+false_pos+" "+precision +" "+recall+" "+2*precision*recall/(precision+recall));
					}

					if(output[1]){
						num_green++;
						prob_curr  *= get_r_to_g(edge_prob.get(queryPair));//(edge_prob.get(t)*max_r_to_g);
						pg *= (1-get_g_to_r(edge_prob.get(queryPair)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
						pr *= get_r_to_g(edge_prob.get(queryPair));//(edge_prob.get(t)*max_r_to_g);
					}else{
						pg *= (get_g_to_r(edge_prob.get(queryPair)));//(1 - (1-edge_prob.get(t))*max_g_to_r);
						pr *= 1 - get_r_to_g(edge_prob.get(queryPair));//(edge_prob.get(t)*max_r_to_g);
					}
						
					if(sim>=0.5 && first && output[1]){
						prob_wanted = 0.999;
						break;	
					}else if(sim < 0.5 && first && !output[1]){
						break;
					}else{
						prob_wanted = 1.0/Math.pow(Math.exp(1)*(current.size()+1), this.beta);
					}
					
					first = false;
					
					if(pr*1.0/(pr+pg) > this.confidence){
						break;
					}
					if(prob_curr<=prob_wanted){
						break;
					}
				}
				if(prob_curr<=prob_wanted){
					for(int i:current){
						if(gt.get(i).equals(gt.get(max)))
							true_pos++;
						else{
							false_pos++;
						}
					}
					if(!current.contains(max))
						current.add(max);
					component tmpcomp = new component(current);
					set_clusters.set((int)comp[1], tmpcomp);					
					added = true;
					break;
				}
				num++;
			}
			
			//Add a singleton cluster
			if(added ==false){
				ArrayList<Integer> curr_comp =new ArrayList<Integer> ();
				curr_comp.add(max);
				component tmpcomp = new component(curr_comp);
				set_clusters.add(tmpcomp);				
			}
			processed_nodes.add(max);
			
			
			if(processed_nodes.size()==graph.num_nodes())
				break;

		}
	}
	
	
	
	
	public boolean[] query_edge_prob(HashMap<pair,Boolean>  oracle, HashMap<Integer, Integer> gt, int u, int v){
		boolean ret[] = {false, false};
		pair tmp = new pair(u,v);

		if(this.answers.containsKey(tmp)){

			int tmps = this.answers.get(tmp);
			ret[1] =  (tmps==1);

		}else{
			//System.out.println("SOMETHING IS WRONG HERE**************************"+u+" "+v);
			ret[1] = gt.get(u).equals(gt.get(v));
		}

		//ret[1]=false;
		//Ground truth
		if (gt.get(u).equals(gt.get(v))){
			ret[0]=true;
		}

		return ret;
	}
	public double merge_prob( Map<pair, Double> edge_prob, ArrayList<Integer> comp1, ArrayList<Integer> comp2){
		double prob = 1;
		double prob_neg = 1;
		
		for(int i:comp1){
			for(int j:comp2){
				
				pair t  = new pair(i,j);
				//if(edge_prob.get(t)==0)
				//	continue;
				//System.out.println("Edge is "+i+" "+j+" "+edge_prob.get(t));
				prob *= (edge_prob.get(t));
				prob_neg *= (1 - edge_prob.get(t));
			}
		}
		//System.out.println(prob+" mmm"+prob_neg);
		return (prob*1.0/(prob+prob_neg) - 0.01);
		
	}
	
	public static List<Integer> pickNRandom(List<Integer> lst, int n, Map<pair, Double> edge_prob, int fl) {
		List<Integer> copy = new LinkedList<Integer>(lst);
		double thisSeed=(generator.nextDouble()*Integer.MAX_VALUE);
		Random newgen = new Random((int)thisSeed);
		//System.out.println("seed is "+thisSeed);
		
		Collections.shuffle(copy,newgen);
		
		List<Integer> copy_new = new LinkedList<Integer>();

		if(copy_new.size()<n){
			copy_new = copy.subList(0,n);
		}

		return copy_new;


	}
	public ArrayList<component> compute_SCC(Graph graph){
		ArrayList<component> tmp_set = new ArrayList<component>();
		for(int i=0;i<graph.num_nodes();i++){
			ArrayList<Integer> curr = new ArrayList<Integer>();
			curr.add(i);
			component tmp = new component(curr);
			tmp_set.add(tmp);
		}
		//Formed a set of singleton nodes
		
		while(true){
			double max_prob=-1;
			int c1=-1,c2=-1;
			for(int i=0;i<tmp_set.size();i++){
				for(int j=i+1;j<tmp_set.size();j++){
					double tmp_prob =merge_prob(edge_prob_SCC,tmp_set.get(i).get_component(),tmp_set.get(j).get_component());
					if(tmp_prob>max_prob){
						max_prob = tmp_prob;
						c1 = i;
						c2 = j;
						
					}
				}
			}
			if(max_prob<=0.5)
				break;
			
			ArrayList<Integer> new_comp = new ArrayList<Integer>();
			component e  = new component(new_comp);
			new_comp.addAll(tmp_set.get(c1).get_component());
			new_comp.addAll(tmp_set.get(c2).get_component());
			//System.out.println(tmp_set.size()+" "+c1+" "+c2);
			tmp_set.remove(c2);
			tmp_set.remove(c1);
			tmp_set.add(e);
			//System.out.println(tmp_set.size()+" "+c1+" "+c2);
		}
		
		
		
		return tmp_set;
		
		
	}
	
	public ArrayList<component> compute_iSCC(Graph graph){
		ArrayList<component> tmp_set = new ArrayList<component>();
		ArrayList<Integer> done = new ArrayList<Integer>();
		for(component t : set_clusters){
			if(t.get_component().size() > 1){
				component t1 = new component(t.get_component());
				tmp_set.add(t1);
				done.addAll(t.get_component());
			}
		}
		
		for(int i=0;i<graph.num_nodes();i++){
			if(done.contains(i))
				continue;
			
			ArrayList<Integer> curr = new ArrayList<Integer>();
			curr.add(i);
			component tmp = new component(curr);
			tmp_set.add(tmp);
		}
		//Formed a set of singleton nodes
		
		while(true){
			double max_prob=-1;
			int c1=-1,c2=-1;
			for(int i=0;i<tmp_set.size();i++){
				for(int j=i+1;j<tmp_set.size();j++){
					double tmp_prob =merge_prob(edge_prob_SCC,tmp_set.get(i).get_component(),tmp_set.get(j).get_component());
					if(tmp_prob>max_prob){
						max_prob = tmp_prob;
						c1 = i;
						c2 = j;
						
					}
				}
			}
			if(max_prob<=0.5)
				break;
			
			ArrayList<Integer> new_comp = new ArrayList<Integer>();
			component e  = new component(new_comp);
			new_comp.addAll(tmp_set.get(c1).get_component());
			new_comp.addAll(tmp_set.get(c2).get_component());
			//System.out.println(tmp_set.size()+" "+c1+" "+c2);
			tmp_set.remove(c2);
			tmp_set.remove(c1);
			tmp_set.add(e);
			//System.out.println(tmp_set.size()+" "+c1+" "+c2);
		}
		
		
		
		return tmp_set;
		
		
	}
	
	public void get_SCC(HashMap<Integer, Integer> gt, Graph graph, int g_edges){
		ArrayList<component> set_of_clusters;
		if(iSCC)
			set_of_clusters  = compute_iSCC(graph);
		else
			set_of_clusters  = compute_SCC(graph);
			
		int tp=0;
		int fp= 0;
		for(component comp : set_of_clusters){
			ArrayList<Integer> vert = comp.get_component();
			for(int i1:vert){
				for(int j:vert){
					if(i1!=j){
						if(gt.get(i1).equals(gt.get(j)))
							tp++;
						else
							fp++;
							
					}
				}
			}
			
		}
		double prec = tp*1.0/(tp+fp);
		//System.out.println("SCC output is "+tp/2+" "+fp/2);
		//System.out.println("Queries is "+queries);
		//System.out.println("Precision is "+prec);
		double recall = (tp/2)*1.0/g_edges;
		double fscor = 2*prec*recall/(prec+recall);
		//System.out.println(queries+"Precision "+prec+" "+recall+" "+fscor);
		this.ouput_print_scc.println(queries+" "+recall+" "+prec+" "+fscor);
	}
	
	double get_benefit(int u,  Map<pair, Double> edge_prob){

		int iter = 0;
		double max_ben = 0;
		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			for(int n : nodes){
				//if(u==n)
				//System.out.println(u+" "+n+" "+nodes.size());;
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
			}
			if(prob > max_ben){
				max_ben = prob;
			}
			iter++;
		}

		return max_ben;
	}
	public ArrayList<double[]> get_benefit_component(int u,  Map<pair, Double> edge_prob){
		ArrayList<double[]> comp_lst = new ArrayList<double[]>();


		int iter = 0;
		
		while(iter<set_clusters.size()){
			component tmp = set_clusters.get(iter);
			ArrayList<Integer> nodes = tmp.get_component();
			double prob = 0;
			double max = 0.0;
			double min = 1.0;
			for(int n : nodes){
				pair ed = new pair(u,n);
				prob+=edge_prob.get(ed);
				if(edge_prob.get(ed)>max)
					max = edge_prob.get(ed);
				if(edge_prob.get(ed)<min)
					min = edge_prob.get(ed);
			}
			double[] entry = {prob,iter, max,min};
			
			comp_lst.add(entry);
			iter++;
		}




		Collections.sort(comp_lst, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[0]; double s2 = o2[0];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});
		return comp_lst;
	}
	
	public int[] process( HashMap<Integer, Integer> gt   , PrintStream out,
			Graph graph,TreeMap  <Integer, Double > expected_sorted,
			 int g_limit, Map      <Integer, List<double[]>> adj_weighted, double g_edges) throws Exception {


		queries = 0;
		//System.out.println("Total green edges in the dataset are"+g_edges);
		
		//Initial edge probabilities in this map
		Map<pair, Double> edge_prob = new HashMap<pair, Double>();
		
		int node_id = 0;
		ArrayList<double[]> prob_list = new ArrayList<double[]>();
		
		//Keeping two maps of edge probability
		while(node_id<graph.num_nodes()){
			for (double[] edge1 : adj_weighted.get(node_id)) {   
				pair temp= new pair((int)edge1[0],(int)edge1[1]);
				edge_prob.put(temp, edge1[2]);
				edge_prob_SCC.put(temp, edge1[2]);
				temp= new pair((int)edge1[1],(int)edge1[0]);
				edge_prob.put(temp, edge1[2]);
				edge_prob_SCC.put(temp, edge1[2]);
				if(edge1[1] > edge1[0])
					prob_list.add(edge1);
			}
			node_id++;
		}

		//Sorted list of probability of the edges
		Collections.sort(prob_list, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[2]; double s2 = o2[2];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});

		//System.out.println("Edges have been made");

		//Set the empty ones to 0 
		for(int node_id1=0;node_id1<graph.num_nodes();node_id1++){
			for(int node_id2=0;node_id2<graph.num_nodes();node_id2++){
				pair t = new pair(node_id1,node_id2);
				pair t1 = new pair(node_id2,node_id1);
				if(edge_prob.containsKey(t))
					continue;
				edge_prob.put(t1, 0.0);
				edge_prob.put(t, 0.0);
			}
		}

		
		//System.out.println("Edges made and similarities have been set");
		
		Nnodes= graph.num_nodes();
		
		
		NodeNodeExpOrdering( expected_sorted,  graph,   edge_prob,  gt,  g_edges);
	    
		//Boost Fscore
		mergeClusters(graph, gt,edge_prob,(int)g_edges);
	    	regularize( graph, edge_prob, gt,  (int)g_edges);
	    
	    	//Get the cluster ids of all the nodes
	    	Map<Integer,Integer> clus_loc = new HashMap<Integer,Integer>();
	    	for(int i=0;i<set_clusters.size();i++){
	    		for(int a:set_clusters.get(i).get_component()){
				clus_loc.put(a, i);
			}
	    	}
	    		
	    	
	    	//Add the nodes which are singleton nodes or not processed
	    	int singlenotdone = 0;
	    	for(int i=0;i<graph.num_nodes();i++){
	    		if(clus_loc.containsKey(i))
	    			continue;
	    		else{
	    			singlenotdone++;
	    			ArrayList<Integer> nodes1 = new ArrayList<Integer>();
	   			nodes1.add(i);
	    			component curr_comp1 = new component(nodes1);
	    			set_clusters.add(curr_comp1);
	    			clus_loc.put(i, set_clusters.size()-1);
			}
	    	}
	    	//System.out.println(singlenotdone+" single left out");
	    		
	    	EdgeEdgeExpOrdering(graph, gt,edge_prob,(int)g_edges);
	    	
	    	mergeClusters(graph, gt,edge_prob,(int)g_edges);
	    	regularize( graph, edge_prob, gt,  (int)g_edges);
	    	
		this.ouput_print.close();
		return new int[]{0,0};       
	}

	public static void main(String[] args) throws Exception{
		if(args.length < 2){
			System.out.println("Help: java fig4adaptive <folder> <iSCC>");
			System.exit(0);
		}
		for(int iter = 1;iter<=10;iter++){
			System.out.println("Running Iteration "+iter);
			fig4adaptive no  = new fig4adaptive();
			no.folder = args[0];//gym,captchas
			if(args[1].equals("true"))
				no.iSCC=true;
			else
				no.iSCC=false;
			try {
				
				//Ground truth in this map
				HashMap<Integer, Integer> gt = new HashMap<Integer,Integer>();

				//Read the edge probabilities from graph file
				String graph_file = "../Data/"+no.folder+"/graph.txt";
				
				Graph graph;
				
				PrintStream out;
				out = new PrintStream("output.txt");

				Map <Integer, List<double[]>> adj_weighted = new HashMap<Integer, List<double[]>>();;
				Scanner scanner = new Scanner(new File(graph_file));
				graph = new Graph(scanner.nextInt());
				double g_edges = scanner.nextInt();
				int i=0;
				for (;i<graph.num_nodes();i++) {
					adj_weighted.put(i, new ArrayList<double[]>());
				}

				while(scanner.hasNextLine()){
					int u = scanner.nextInt();        		
					if(u==-1)
						break;
					int v = scanner.nextInt();
					double prob = scanner.nextFloat();
					double[] edge = {u,v,prob};
					adj_weighted.get(u).add(edge);
					adj_weighted.get(v).add(edge);
				}


				//Groundtruth clustering
				String gold = "../Data/"+no.folder+"/gold.txt";
				try {
					scanner = new Scanner(new File(gold));
					while(scanner.hasNextLine()){
						String[] line=scanner.nextLine().split(" ");
						i=0;
						int a1 = Integer.parseInt(line[0]);
						int a2 = Integer.parseInt(line[1]);
						gt.put(a1,a2);
						i++;
					}
				}
				catch(FileNotFoundException ex) {
					System.out.println("Exception in gold standard file");               
				}

				
				no.answers = new HashMap<pair, Integer>();
				no.curr_ans = new HashMap<pair, Integer>();
				
				//Answers from Crowd for real dataset
				String answer = "../Data/"+no.folder+"/answers.txt";
				try {
					scanner = new Scanner(new File(answer));
					while(scanner.hasNextLine()){
						String[] line=scanner.nextLine().split(" ");
						int a1 = Integer.parseInt(line[0]);
						int a2 = Integer.parseInt(line[1]);
						int a3 = Integer.parseInt(line[2]);
						pair t =new pair(a1,a2);
						pair t1 =new pair(a2,a1);
						no.answers.put(t,a3);
						no.answers.put(t1,a3);
					}
				}
				catch(FileNotFoundException ex) {
					System.out.println("Exception in Answers file");               
				}

				no.ouput_print = new PrintStream ("../output/"+no.folder+"/output_fscore_"+Integer.toString(iter));
				no.ouput_print_scc = new PrintStream ("../output/"+no.folder+"/output_fscore_scc_"+Integer.toString(iter));

				//System.out.println("Read all files, Number of nodes = "+adj_weighted.size());

				//Expected cluster size
				HashMap<Integer, Double> expected = new HashMap<Integer, Double>();
				for (int u =0;u<graph.num_nodes() ;u++) {
					double sum = 0.0;
					for (double[] edge: adj_weighted.get(u)) {
						double s  = edge[2];
						sum      += s;
					}
					expected.put(u, sum);
				}
				TreeMap<Integer, Double > expected_sorted;
				ValueComparator bvc  = new ValueComparator(expected, null);
				expected_sorted = new TreeMap<Integer, Double>(bvc);
				expected_sorted.putAll(expected);

				int g_limit = 300000;

				
				no.process( gt, out, graph, expected_sorted, g_limit , adj_weighted,  g_edges ) ;
				System.out.println("Program complete --exiting-- ");
			}
			catch(FileNotFoundException ex) {
				System.out.println("Exception in code");            // Always must return something

			}
		}
	}	
}

