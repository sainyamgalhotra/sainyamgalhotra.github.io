import java.util.ArrayList;

public class pair_component {
	public ArrayList<Integer> x,y;

	public pair_component (  ArrayList<Integer> x,  ArrayList<Integer> y) {
        this.x = x;
        this.y = y;
    }
	
	public boolean equals(Object o) {
        if (this == o) return true;
       // if (!(o instanceof pair)) return false;
        pair_component key = (pair_component) o;
        return (x == key.x && y == key.y)||(x == key.y && y == key.x);
    }
	public int hashCode() {
        int result = x.toString().hashCode();
        result = 31 * result + y.toString().hashCode();
        return result;
    }

}
