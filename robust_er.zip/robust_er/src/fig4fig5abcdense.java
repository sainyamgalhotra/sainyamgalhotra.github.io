/**
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;


public class fig4fig5abcdense {

	double pH =0.0680913375738;// 0.00351985438777;//0.1;//0.0680913375738;
	//Captchas 0.00351985438777
	//Gym 0.0680913375738
	//Landmarks 0.0936354608649

	double r_to_g = 0.1;//Used for syntheitc
	double g_to_r = 0.1;//Used for syntheitc
	boolean initial_evidence = false;
	boolean synthetic = false;


	static Random generator = new Random(1992);

	int queries=0;
	HashMap<pair,Boolean> oracle = new HashMap<pair,Boolean>();
	ArrayList<component> set_clusters = new ArrayList<component>();
	Map<pair, Boolean> queried_edge_map = new HashMap<pair, Boolean>();
	int true_pos=0;
	int false_pos=0;
	int overflowed=0;
	PrintStream ouput_print;
	Map<pair, List<Integer>> answers;
	Map<pair, Integer> curr_ans;


	public HashMap<pair,List<Integer>> print_edges(HashMap<Integer, Integer> gt, Graph graph, PrintStream out, double r_to_g, double g_to_r){

		HashMap<pair,List<Integer>> edge = new HashMap<pair,List<Integer>>();
		int num_ques = 5;
		int n1 = 0,n2 = 0;
		try{
			PrintStream edge_prob_true, edge_prob_false;

			edge_prob_true = new PrintStream ("edge_prob"+(r_to_g)+"_"+(g_to_r)+"_true");
			edge_prob_false = new PrintStream ("edge_prob"+(r_to_g)+"_"+(g_to_r)+"_false");

			while(n1<graph.num_nodes()){
				n2=n1+1;

				while(n2<graph.num_nodes()){
					pair tmp1 = new pair(n1,n2);
					pair tmp2 = new pair(n2,n1);
					if (gt.get(n1).equals(gt.get(n2))){
						List<Integer> tmp = new ArrayList<Integer>();
						for(int i=0;i<num_ques;i++){
							double rand = generator.nextDouble();
							if( rand >= g_to_r){
								tmp.add(1);
								edge_prob_true.println(n1+" "+n2);
							}
							else{
								tmp.add(0);
								edge_prob_false.println(n1+" "+n2);
							}
						}

						edge.put(tmp1, tmp);
						edge.put(tmp2, tmp);
					}else{

						List<Integer> tmp = new ArrayList<Integer>();
						for(int i=0;i<num_ques;i++){
							double rand = generator.nextDouble();
							if( rand <= r_to_g){
								tmp.add(1);
								edge_prob_true.println(n1+" "+n2);
							}
							else{
								tmp.add(0);
								edge_prob_false.println(n1+" "+n2);
							}

						}
						edge.put(tmp1, tmp);
						edge.put(tmp2, tmp);


					}
					n2++;
				}
				n1++;
			}
			edge_prob_true.close();
			edge_prob_false.close();

		} catch (Exception e) {
			System.out.println("Exception raised");
		}
		//System.out.println("Edges made");
		return edge;
	}


	public boolean[] query_edge_prob(HashMap<pair,Boolean>  oracle, HashMap<Integer, Integer> gt, int u, int v){
		boolean ret[] = {false, false};

		pair tmp = new pair(u,v);
		pair tmp1 = new pair(v,u);
		if(answers.containsKey(tmp)){
			List<Integer> ans = this.answers.get(tmp);
			int tmps = ans.get(this.curr_ans.get(tmp));
			{
				int value = (this.curr_ans.get(tmp)+1)%5;

				this.curr_ans.put(tmp1, value);
				this.curr_ans.put(tmp, value);

				ret[1] = (tmps==1);

			}

		}

		if (gt.get(u).equals(gt.get(v))){
			ret[0]=true;
		}

		return ret;
	}

	public double merge_prob( Map<pair, Double> edge_prob, ArrayList<Integer> comp1, ArrayList<Integer> comp2){
		double prob = 1;
		double prob_neg = 1;
		for(int i:comp1){
			for(int j:comp2){

				pair t  = new pair(i,j);
				if(edge_prob.get(t)==0)
					continue;
				prob *= (edge_prob.get(t));
				prob_neg *= (1 - edge_prob.get(t));
			}
		}
		return (prob*1.0/(prob+prob_neg) );

	}
	public ArrayList<component> compute_SCC(Map<pair, Double> edge_prob,Graph graph){
		ArrayList<component> tmp_set = new ArrayList<component>();
		for(int i=0;i<graph.num_nodes();i++){
			ArrayList<Integer> curr = new ArrayList<Integer>();
			curr.add(i);
			component tmp = new component(curr);
			tmp_set.add(tmp);
		}
		//Formed a set of singleton nodes

		while(true){
			double max_prob=-1;
			int c1=-1,c2=-1;
			for(int i=0;i<tmp_set.size();i++){
				for(int j=i+1;j<tmp_set.size();j++){
					double tmp_prob =merge_prob(edge_prob,tmp_set.get(i).get_component(),tmp_set.get(j).get_component());
					if(tmp_prob>max_prob){
						max_prob = tmp_prob;
						c1 = i;
						c2 = j;

					}
				}
			}
			//System.out.println(max_prob);
			if(max_prob<=0.5)
				break;

			ArrayList<Integer> new_comp = new ArrayList<Integer>();
			component e  = new component(new_comp);
			new_comp.addAll(tmp_set.get(c1).get_component());
			new_comp.addAll(tmp_set.get(c2).get_component());
			//System.out.println(tmp_set.size()+" "+c1+" "+c2);
			tmp_set.remove(c2);
			tmp_set.remove(c1);
			tmp_set.add(e);
			//System.out.println(tmp_set.size()+" "+c1+" "+c2);
		}



		return tmp_set;


	}
	public double get_rho(ArrayList<Integer> c1, ArrayList<Integer> c2,Graph graph, Map<pair, Double> edge_prob){
		double PY1 = 1.0;
		double PY1p = 1.0;
		double PY2 = 1.0;
		double PY2p = 1.0;
		double PY = 1.0;
		double PYp = 1.0;
		double PN = 1.0;
		double PNp = 1.0;
		for(int i=0;i<graph.num_nodes();i++){
			if(c1.contains(i) || c2.contains(i))
				continue;
			for(int x1:c1){
				pair p1 = new pair(x1,i);
				if(edge_prob.get(p1)>=0.5){
					PY1 *= edge_prob.get(p1);
					PY1p *=(1-edge_prob.get(p1));
				}
			}

			for(int x2:c2){
				pair p1 = new pair(x2,i);
				if(edge_prob.get(p1)>=0.5){
					PY2 *= edge_prob.get(p1);
					PY2p *=(1-edge_prob.get(p1));
				}
			}

		}



		for(int x1:c1){
			for(int x2:c2){
				pair p1 = new pair(x1,x2);
				if(edge_prob.get(p1)>=0.5){
					PY *= edge_prob.get(p1);
					PYp *=(1-edge_prob.get(p1));
				}
				else if(edge_prob.get(p1)<0.5){
					PN *= (1 - edge_prob.get(p1));
					PNp *=(edge_prob.get(p1));
				}
			}
		}

		double return_prob=1.0;
		if(PY == 1 && PY1==1 && PY2==1)
			return 0.0;

		return_prob *= (PY1p * PY2p/(PY1*PY2) )*(Math.min(PYp/PY, PNp/PN)); 

		return return_prob;
	}
	public double get_max_prob(ArrayList<Integer>c1, ArrayList<Integer> c2, Map<pair, Double> edge_prob){
		double max = -1;
		//Collections.shuffle(c1);
		//Collections.shuffle(c2);
		for(int x:c1){
			for(int y:c2){
				pair p =new pair(x,y);
				if(edge_prob.get(p)>max){
					max = edge_prob.get(p);
				}
			}
		}
		return max;
	}
	public pair  Dense(Map<pair, Double> edge_prob,Graph graph, Map<pair, Double> edge_prob_queried){

		HashMap<pair_component, Double> candidates= new HashMap<pair_component, Double>();
		double max_rho = -1;
		ArrayList<Integer> c1 = new ArrayList<Integer>();
		ArrayList<Integer> c2 = new ArrayList<Integer>();
		for(int i=0;i<graph.num_nodes();i++){
			ArrayList<Integer> comp1 = new ArrayList<Integer>();
			comp1.add(i);
			for(int j=i+1;j<graph.num_nodes();j++){
				ArrayList<Integer> comp2 = new ArrayList<Integer>();
				comp2.add(j);
				double rho = get_rho(comp1,comp2,graph, edge_prob_queried);
				if(rho > max_rho){
					max_rho = rho;

					c1.clear();
					c2.clear();
					c1.addAll(comp1);
					c2.addAll(comp2);
				}
				comp2.clear();
				//Get the rho value between these two nodes 
			}
			comp1.clear();
		}
		if(max_rho>-1){

			pair_component pair1 = new pair_component(c1,c2);
			candidates.put(pair1,max_rho);
		}


		ArrayList<component> record_set  = new ArrayList<component>();
		for(int i=0;i<graph.num_nodes();i++){
			ArrayList<Integer> c = new ArrayList<Integer>();
			c.add(i);
			component tmp = new component(c);
			//System.out.println("Size of c is"+c.size());
			record_set.add(tmp);
		}
		//System.out.println("Sizes of record set is "+record_set.size());

		while(true){
			//System.out.println(record_set.size());
			double max_prob = -1;
			int maxc1=-1,maxc2=-1;
			for(int i=0;i<record_set.size();i++){
				for(int j=i+1;j<record_set.size();j++){
					double prob = get_max_prob(record_set.get(i).get_component(), record_set.get(j).get_component(), edge_prob);
					if( prob > max_prob){
						max_prob = prob; 
						maxc1 = i;
						maxc2 = j;

					}
				}
			}
			ArrayList<Integer> new_comp = new ArrayList<Integer>();
			new_comp.addAll(record_set.get(maxc1).get_component());
			new_comp.addAll(record_set.get(maxc2).get_component());
			component merged = new component(new_comp);
			record_set.remove(maxc2);
			record_set.remove(maxc1);


			double max_rho_merged=-1;
			int ind = -1;
			for(int i=0;i<record_set.size();i++){
				double rho = get_rho(record_set.get(i).get_component(),new_comp,graph, edge_prob_queried);
				if(rho > max_rho_merged){
					max_rho_merged = rho;
					ind = i;
				}
			}
			if(max_rho_merged >=0){
				//System.out.println("Here isze is "+new_comp.size()+" "+record_set.get(ind).get_component().size());
				pair_component pair2 = new pair_component(new_comp,record_set.get(ind).get_component());
				candidates.put(pair2,max_rho_merged);
			}
			record_set.add(merged);
			if(record_set.size()==1)
				break;
		}

		/* double max = -1;
		 ArrayList<Integer> c11 = new ArrayList<Integer>(), c22 = new ArrayList<Integer>();
		 for(pair_component tmp:candidates.keySet()){
			 if(candidates.get(tmp) > max){
				 c11 = tmp.x;
				 c22 =  tmp.y;
			 }
		 }


		 List<Integer> q1 =pickNRandom(c11,2);
		 List<Integer> q2 =pickNRandom(c11,2);
		 pair ques = new pair(q1.get(0),q2.get(0));
		 */
		ArrayList<double[]> sort_helper = new ArrayList<double[]>();

		ArrayList<pair_component> help = new ArrayList<pair_component>();
		int iter=0;
		for (Entry<pair_component, Double> tmp: candidates.entrySet()) {
			double[] entry = {(double)iter, tmp.getValue()};
			help.add(tmp.getKey());
			sort_helper.add(entry);
			iter+=1;
		}
		Collections.sort(sort_helper, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[1]; double s2 = o2[1];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});


		pair question = new pair(-1,-1);
		for(double[] entry :sort_helper){
			pair_component curr = help.get((int)entry[0]);
			ArrayList<Integer> comp1 = curr.x;	
			ArrayList<Integer> comp2 = curr.y;
			Random newgen = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
			Collections.shuffle(comp1,newgen);

			Random newgen1 = new Random((int)(generator.nextDouble()*Integer.MAX_VALUE));
			Collections.shuffle(comp2,newgen1);
			pair t= new pair(curr.x.get(0),curr.y.get(0));
			//if(queried_edge_map.containsKey(t))
			//continue;
			if(this.curr_ans.get(t)==4)
				continue;
			question = new pair(comp1.get(0),comp2.get(0));
			break;

		}
		return question;


	}
	public pair find_pair(ArrayList<Integer> c1, ArrayList<Integer> c2, Map<pair, Double> edge_prob){
		double max = -1;
		double min = 1.0;
		int minx = -1,miny=-1;
		int maxx = -1,maxy=-1;
		//Collections.shuffle(c1);
		//Collections.shuffle(c2);
		for(int x:c1){
			for(int y:c2){
				pair tmp = new pair(x,y);
				double prob = edge_prob.get(tmp);
				if(prob >= 0.5 && prob< min){
					min = prob;
					minx = x;
					miny = y;
				}
				if(prob < 0.5 && prob > max){
					max = prob;
					maxx = x;
					maxy = y;
				}
			}
		}

		if((0.5 - max)  > (min - 0.5) && min<1){
			pair question = new pair(minx,miny);
			return question;
		}
		else{
			pair question = new pair(maxx,maxy);
			return question;
		}

	}
	public ArrayList<pair> bDense( HashMap<pair_component, Double> candidates,  Map<pair, Double> edge_prob, Map<pair, Double> edge_prob_queried ){
		ArrayList<pair> questions = new ArrayList<pair>();
		ArrayList<double[]> sort_helper = new ArrayList<double[]>();

		ArrayList<pair_component> help = new ArrayList<pair_component>();
		//help.addAll(candidates.keySet());

		int iter=0;
		for(Entry<pair_component, Double> tmp: candidates.entrySet()){
			double[] entry = {(double)iter, tmp.getValue()};
			help.add(tmp.getKey());
			sort_helper.add(entry);
			iter+=1;
		}

		Collections.sort(sort_helper, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[1]; double s2 = o2[1];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});
		Set<Integer> involved_recs = new HashSet<Integer>();



		for(double[] entry :sort_helper){
			pair_component curr = help.get((int)entry[0]);
			ArrayList<Integer> comp1 = curr.x;
			ArrayList<Integer> comp2 = curr.y;

			boolean present =false;
			for (int a:comp1){
				if(involved_recs.contains(a)){
					present  = true;
					break;
				}
			}
			for (int a:comp2){
				if(involved_recs.contains(a)){
					present  = true;
					//System.out.println("Already covered2 "+comp2.size());
					break;
				}
			}
			if(present)
				continue;
			pair q = find_pair(comp1,comp2, edge_prob);
			if(q.x==-1 || q.y==-1)
				continue;
			questions.add(q);
			//System.out.println("Covering now "+comp1.size()+" "+comp2.size());
			involved_recs.addAll(comp1);
			involved_recs.addAll(comp2);

		}

		return questions;
	}
	public int[] process( HashMap<Integer, Integer> gt   , PrintStream out,
			Graph graph,TreeMap  <Integer, Double > expected_sorted,
			int window, int g_limit, Map      <Integer, List<double[]>> adj_weighted, double g_edges, List<double[]> parallel_edges,  int setting) throws Exception {
		//System.out.println("total green is "+g_edges);


		Map<pair, Double> edge_prob = new HashMap<pair, Double>();
		Map<pair, Double> edge_prob_queried = new HashMap<pair, Double>();
		int node_id = 0;
		if(synthetic){
			this.answers.clear();
			this.answers = print_edges(gt,graph,out,pH,pH);
		}
		ArrayList<double[]> prob_list = new ArrayList<double[]>(); 

		while(node_id<graph.num_nodes()){
			for (double[] edge1 : adj_weighted.get(node_id)) {   
				pair temp= new pair((int)edge1[0],(int)edge1[1]);
				edge_prob.put(temp, edge1[2]);
				edge_prob_queried.put(temp,0.0);
				temp= new pair((int)edge1[1],(int)edge1[0]);
				edge_prob.put(temp, edge1[2]);
				prob_list.add(edge1);
				edge_prob_queried.put(temp,0.0);
			}
			node_id++;
		}

		Collections.sort(prob_list, new Comparator<double[]>() {
			public int compare(double[] o1, double[] o2) {
				double s1 = o1[2]; double s2 = o2[2];
				if (s1 != s2)
					return (s1 > s2 ? -1 : 1);
				else
					return 0;
			}
		});

		ArrayList<component> set_of_clusters; 
		if(!initial_evidence)
			set_of_clusters  = compute_SCC(edge_prob_queried, graph);
		else
			set_of_clusters  = compute_SCC(edge_prob, graph);

		int tp=0,fp=0;
		for(component comp : set_of_clusters){
			ArrayList<Integer> vert = comp.get_component();
			//System.out.println(vert.size());
			for(int i:vert){
				for(int j:vert){
					if(i!=j){
						if(gt.get(i).equals(gt.get(j)))
							tp++;
						else
							fp++;

					}
				}
			}	
		}

		double prec = tp*1.0/(tp+fp);
		//System.out.println("SCC output is "+tp/2+" "+fp/2);
		//System.out.println("Queries is "+queries);
		//System.out.println("Precision is "+prec);
		double recall = (tp/2)*1.0/g_edges;
		double fscor = 2*prec*recall/(prec+recall);
		//System.out.println("Precision "+prec+" "+recall+" "+fscor);
		this.ouput_print.println(queries+" "+prec+" "+recall+" "+fscor);







		int num_batch = 3000;
		queries = 0;
		for(int i=0;i<num_batch;i++){
			if(queries>2500)
				break;
			double start = System.nanoTime();
			pair question = Dense(edge_prob, graph, edge_prob);//= new HashMap<pair_component, Double>();
			ArrayList<pair> questions  = new ArrayList<pair>();
			questions.add(question);
			//ArrayList<pair> questions  = bDense(candidates, edge_prob, edge_prob);
			//System.out.println("Number of questions is "+questions.size()+" batch_number "+i);
			for(pair q : questions){
				if(q.x==-1 || q.y==-1)
					continue;
				if( !synthetic && this.curr_ans.get(q)==4)
					queries++;
				boolean[] output =  query_edge_prob(oracle, gt, q.x, q.y);
				pair tmp = new pair(q.y,q.x);
				if(!synthetic && !queried_edge_map.containsKey(q))
				{
					queries++;

					queried_edge_map.put(tmp, output[1]);
					queried_edge_map.put(q, output[1]);
				}else if(synthetic){
					queries++;

					queried_edge_map.put(tmp, output[1]);
					queried_edge_map.put(q, output[1]);
				}
				double pg = 1, pr = 1;
				for(int k=0;k<this.curr_ans.get(tmp);k++){
					int o = this.answers.get(tmp).get(k);
					if(o==1){
						pg*= (1 - pH);
						pr*= (pH);
					}else{
						pg*= (pH);
						pr*= (1-pH);
					}
				}
				double prob = pg*1.0/(pr+pg);
				//if(output[1])
				{

					edge_prob.put(q, prob);
					edge_prob.put(tmp, prob);
					edge_prob_queried.put(q,prob);
					edge_prob_queried.put(tmp,prob);
					//System.out.println("FDFFFFFFffdhsjafhdsjgfhjdsgfjhdsghjfdsghjfgsdhjfgdshjfgahgsdjhfgdshjghjghjghjg");
				}
				/*else{
					edge_prob.put(q, prob);
					edge_prob.put(tmp, prob);
					edge_prob_queried.put(q,prob);
					edge_prob_queried.put(q,prob);

				}*/
			}
			//System.out.println("Queries is "+queries);
			double end = System.nanoTime();
			if(queries%10!=0)
				continue;

			if(!initial_evidence)
				set_of_clusters  = compute_SCC(edge_prob_queried, graph);
			else
				set_of_clusters  = compute_SCC(edge_prob, graph);
			tp=0;
			fp=0;
			for(component comp : set_of_clusters){
				ArrayList<Integer> vert = comp.get_component();
				for(int i1:vert){
					for(int j:vert){
						if(i1!=j){
							if(gt.get(i1).equals(gt.get(j)))
								tp++;
							else
								fp++;

						}
					}
				}

			}
			prec = tp*1.0/(tp+fp);
			//System.out.println("SCC output is "+tp/2+" "+fp/2);
			//System.out.println("Queries is "+queries);
			//System.out.println("Precision is "+prec);
			recall = (tp/2)*1.0/g_edges;
			fscor = 2*prec*recall/(prec+recall);
			//System.out.println("Precision "+prec+" "+recall+" "+fscor);
			this.ouput_print.println(queries+" "+prec+" "+recall+" "+fscor+" "+(end-start)*1.0/1000000);

		}

		//System.out.println(this.overflowed+" overflow");
		this.ouput_print.close();


		return new int[]{0,0};       
	}

	public static void main(String[] args) throws Exception{
		if(args.length < 2){
                        System.out.println("Help: java figure4Dense <folder> <initial Evidence> <synthetic> <synthetic probability>");
                        System.exit(0);
                }
		String folder = args[0];
		for(int iter = 1;iter<=10;iter++){
			try {

				HashMap<Integer, Integer> gt = new HashMap<Integer,Integer>();


				String graph_file     = "../Data/"+folder+"/graph.txt";
				Graph graph;
				PrintStream out;

				out = new PrintStream("output.txt");
				fig4fig5abcdense no  = new fig4fig5abcdense();
				 if(folder.equals("gym"))
                                        no.pH = 0.0680913375738;
                                else if (folder.equals("captchas"))
                                        no.pH = 0.00351985438777;
                                else if (folder.equals("landmarks"))
                                        no.pH = 0.0936354608649;

                                if(args[1].equals("true"))
                                        no.initial_evidence =  true;

                                if (args[2].equals("true")){
                                        no.synthetic = true;
                                        no.r_to_g = Float.parseFloat(args[3]);
                                        no.g_to_r = Float.parseFloat(args[3]);
                                }

				Map      <Integer, List<double[]>> adj_weighted=new HashMap<Integer, List<double[]>>();;
				no.curr_ans = new HashMap<pair, Integer>();
				Scanner scanner = new Scanner(new File(graph_file));
				graph = new Graph(scanner.nextInt());
				double g_edges = scanner.nextInt();
				int i=0;
				for (;i<graph.num_nodes();i++) {
					adj_weighted.put(i, new ArrayList<double[]>());
				}

				while(scanner.hasNextLine()){
					int u = scanner.nextInt();

					if(u==-1)
						break;
					int v = scanner.nextInt();
					double prob = scanner.nextFloat();
					double[] edge = {u,v,prob};
					//System.out.println(u+" "+v+" "+prob);
					//System.out.println(u+" "+v+" "+prob);;
					adj_weighted.get(u).add(edge);
					adj_weighted.get(v).add(edge);
					pair t1 = new pair(u,v);
					pair t2 = new pair(v,u);
					no.curr_ans.put(t1,0);
					no.curr_ans.put(t2,0);

				}


				no.ouput_print = new PrintStream ("../output/"+folder+"/output_fscore_"+Integer.toString(iter));
				String gold = "../Data/"+folder+"/gold.txt";
				try {
					scanner = new Scanner(new File(gold));
					while(scanner.hasNextLine()){
						String[] line=scanner.nextLine().split(" ");
						i=0;
						// while(i<line.length)
						{
							int a1 = Integer.parseInt(line[0]);
							int a2 = Integer.parseInt(line[1]);
							//System.out.println(a1+" "+a2);

							gt.put(a1,a2);
							i++;
						}
					}


					/*
        	while(scanner.hasNextLine()){
        		String[] line=scanner.nextLine().split(",");
        		 i=1;
        		while(i<line.length){
        			int a1 = Integer.parseInt(line[i]);
        			int a2 = Integer.parseInt(line[1]);
           		 	System.out.println(a1+" "+a2);

        			gt.put(a1,a2);
        			i++;

        		}


        	}*/
				}
				catch(FileNotFoundException ex) {
					;//System.out.println("xjfajdlkfjsdksdjfkljsdkjfsdjkl");               
				}

				//nfnjkdshfjkdshjk;
				no.answers = new HashMap<pair, List<Integer>>();

				String answer = "../Data/"+folder+"/answers_inconsistent.txt";
				try {
					scanner = new Scanner(new File(answer));
					while(scanner.hasNextLine()){
						String[] line=scanner.nextLine().split(" ");
						if(line.length==1)
							continue;
						int a1 = Integer.parseInt(line[0]);
						int a2 = Integer.parseInt(line[1]);
						List<Integer> l1 = new ArrayList<Integer>();
						List<Integer> l2 = new ArrayList<Integer>();
						for(int k=2;k<line.length;k++){
							int curr = Integer.parseInt(line[k]);
							l1.add(curr);
							l2.add(curr);
						}

						pair t1 =  new pair(a1,a2);
						pair t2 =  new pair(a2,a1);
						no.answers.put(t1, l1);
						no.answers.put(t2, l2);


					}

				}
				catch(FileNotFoundException ex) {
					System.out.println("Answer file absent");               
				}




				//System.out.println("Done here "+adj_weighted.size());

				HashMap<Integer, Double> expected = new HashMap<Integer, Double>();
				for (int u =0;u<graph.num_nodes() ;u++) {
					double sum = 0.0;
					for (double[] edge: adj_weighted.get(u)){
						double s  = edge[2];
						//if (s >= this.lim) {
						sum      += s;
						//	sum_square +=(s*s);
						//}
					}
					expected.put(u, sum);

				}
				TreeMap<Integer, Double       > expected_sorted;
				ValueComparator bvc  = new ValueComparator(expected, null);
				expected_sorted = new TreeMap<Integer, Double>(bvc);
				expected_sorted.putAll(expected);
				int g_limit = 300000;

				ArrayList<double[]> parallel_edges = new ArrayList<double[]>();


				no.process( gt, out,graph,expected_sorted,1,g_limit , adj_weighted,  g_edges, parallel_edges, 0 ) ;
			}
			catch(FileNotFoundException ex) {
				//System.out.println("FSD");            // Always must return something

			}
		}
	}	
}

